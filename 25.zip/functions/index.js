const functions = require('firebase-functions');
const https     = require('https');

/**
 * Proxy para a Anthropic API — resolve o bloqueio CORS do browser.
 * Deploy: firebase deploy --only functions
 * Uso no frontend: fetch('/api/claude', { method:'POST', body: JSON.stringify({...}) })
 */
exports.claude = functions
  .runWith({ timeoutSeconds: 30, memory: '256MB' })
  .https.onRequest((req, res) => {

    // CORS — permite apenas o próprio domínio Firebase Hosting
    const origin = req.headers.origin || '';
    res.set('Access-Control-Allow-Origin', origin);
    res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.set('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.status(204).send('');
      return;
    }

    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Method not allowed' });
      return;
    }

    // Lê a API key das variáveis de ambiente do Firebase
    // Configurar com:  firebase functions:config:set anthropic.key="sk-ant-..."
    const apiKey = (functions.config().anthropic || {}).key || '';
    if (!apiKey) {
      res.status(500).json({ error: 'API key não configurada. Corre: firebase functions:config:set anthropic.key="sk-ant-..."' });
      return;
    }

    const body = JSON.stringify(req.body);

    const options = {
      hostname: 'api.anthropic.com',
      path:     '/v1/messages',
      method:   'POST',
      headers: {
        'Content-Type':      'application/json',
        'x-api-key':         apiKey,
        'anthropic-version': '2023-06-01',
        'Content-Length':    Buffer.byteLength(body),
      },
    };

    const proxyReq = https.request(options, (proxyRes) => {
      let data = '';
      proxyRes.on('data', chunk => data += chunk);
      proxyRes.on('end', () => {
        res.status(proxyRes.statusCode).set('Content-Type', 'application/json').send(data);
      });
    });

    proxyReq.on('error', (err) => {
      console.error('[claude proxy]', err);
      res.status(502).json({ error: err.message });
    });

    proxyReq.write(body);
    proxyReq.end();
  });
