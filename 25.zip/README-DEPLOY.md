# GPX Analyzer — Guia de Deploy Firebase

## Pré-requisitos
- Node.js instalado
- Conta Firebase (gratuita em firebase.google.com)

---

## PASSO 1 — Cria o projecto Firebase

1. Vai a **console.firebase.google.com**
2. Clica **"Add project"**
3. Nome: `gpx-analyzer` (ou o que quiseres)
4. Desactiva Google Analytics (opcional)
5. **Create project**

---

## PASSO 2 — Activa os serviços necessários

### Firestore Database
1. No menu lateral → **Firestore Database**
2. **Create database**
3. Escolhe **Start in production mode**
4. Região: `europe-west1` (mais próximo de Portugal)

### Authentication (opcional — para contas de utilizador)
1. No menu lateral → **Authentication**
2. **Get started**
3. Activa **Email/Password** e/ou **Google**

### Hosting
1. No menu lateral → **Hosting**
2. **Get started** (pode saltar o tutorial)

---

## PASSO 3 — Preenche o firebase-config.js

1. No console → **Project Settings** (ícone ⚙️)
2. Scroll até **"Your apps"**
3. Clica **</>** (Web app) → regista com nome `gpx-web`
4. Copia os valores e substitui em **`js/firebase-config.js`**:

```javascript
const firebaseConfig = {
  apiKey:            "AIzaSy...",
  authDomain:        "gpx-analyzer-xxxxx.firebaseapp.com",
  projectId:         "gpx-analyzer-xxxxx",
  storageBucket:     "gpx-analyzer-xxxxx.appspot.com",
  messagingSenderId: "123456789",
  appId:             "1:123456789:web:abc123",
};
```

---

## PASSO 4 — Instala o Firebase CLI

```bash
npm install -g firebase-tools
```

---

## PASSO 5 — Login e init

```bash
firebase login
firebase use --add
```
Escolhe o teu projecto quando perguntado.

---

## PASSO 6 — Deploy completo (hosting + rules + indexes)

```bash
firebase deploy
```

Isto faz deploy de:
- ✅ Ficheiros estáticos (Hosting)
- ✅ Regras de segurança (Firestore Rules)
- ✅ Índices Firestore

**Só hosting (mais rápido):**
```bash
firebase deploy --only hosting
```

**Só rules:**
```bash
firebase deploy --only firestore:rules
```

---

## PASSO 7 — Verifica o deploy

Após o deploy, o terminal mostra:
```
✔  Deploy complete!
Hosting URL: https://gpx-analyzer-xxxxx.web.app
```

Abre o URL e testa carregar um GPX.

---

## Estrutura de dados Firestore

```
/activities/{activityId}
  ├── name, sport, date
  ├── distanceKm, elevGain, avgSpeedKmh
  ├── userId (se autenticado) | sessionId (se anónimo)
  ├── compactTrack: [...] (rota compactada)
  └── /chartData/main
        ├── elevation: [...]
        ├── speed: [...]
        └── splits: [...]

/users/{userId}/activities/{activityId}
  └── índice leve (para listagem rápida)
```

---

## Plano gratuito Firebase (Spark)

| Recurso | Limite gratuito |
|---------|----------------|
| Hosting | 10 GB / mês |
| Firestore leituras | 50.000 / dia |
| Firestore escritas | 20.000 / dia |
| Firestore armazenamento | 1 GB |

Para uso pessoal é mais do que suficiente.

---

## Resolução de problemas

**"Missing or insufficient permissions"**
→ As Firestore Rules não foram deployed. Corre: `firebase deploy --only firestore:rules`

**Página em branco após deploy**
→ Verifica que `firebase.json` tem `"public": "."` e não `"public": "public"`

**"index.html not found"**
→ Confirma que estás dentro da pasta do projecto ao correr `firebase deploy`

**Gráficos não aparecem**
→ Abre a consola do browser (F12) e verifica erros de CORS ou CDN

---

## URL do projecto
Após deploy estará em:
`https://SEU-PROJETO.web.app`
`https://SEU-PROJETO.firebaseapp.com`
