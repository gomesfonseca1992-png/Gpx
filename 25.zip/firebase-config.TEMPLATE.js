/**
 * firebase-config.js — TEMPLATE
 * ════════════════════════════════════════════════════════
 * 1. Vai ao Firebase Console → Project Settings → Your apps
 * 2. Cria uma Web App (ícone </>) se ainda não tens
 * 3. Copia os valores do "Firebase SDK snippet → Config"
 * 4. Cola aqui e guarda como firebase-config.js
 * ════════════════════════════════════════════════════════
 */

const firebaseConfig = {
  apiKey:            "AIzaSy...",                     // ← colar aqui
  authDomain:        "SEU-PROJETO.firebaseapp.com",   // ← colar aqui
  projectId:         "SEU-PROJETO",                   // ← colar aqui
  storageBucket:     "SEU-PROJETO.appspot.com",       // ← colar aqui
  messagingSenderId: "000000000000",                  // ← colar aqui
  appId:             "1:000000000000:web:abc123",     // ← colar aqui
};

// Inicializa Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

// Instâncias globais
const db      = firebase.firestore();
const auth    = firebase.auth();
const storage = firebase.storage();

// Persistência offline (bom para mobile)
db.enablePersistence({ synchronizeTabs: true }).catch(err => {
  if (err.code !== 'failed-precondition' && err.code !== 'unimplemented') {
    console.warn('[Firebase] Persistência:', err.code);
  }
});
