# PMC AI Analysis — Setup

## O que foi adicionado

- `functions/index.js` — proxy Firebase Cloud Function para a Anthropic API (resolve CORS)
- `functions/package.json` — dependências da function
- `firebase.json` — atualizado com `functions` e rewrite `/api/claude`
- `history.html` — card de análise AI abaixo do gráfico Ramp Rate

---

## Deploy em 3 passos

### 1. Configura a API Key da Anthropic

```bash
firebase functions:config:set anthropic.key="sk-ant-SUA_CHAVE_AQUI"
```

Obtém a chave em: https://console.anthropic.com/settings/keys

### 2. Instala as dependências da Function

```bash
cd functions
npm install
cd ..
```

### 3. Deploy completo

```bash
firebase deploy
```

Ou só a function (mais rápido):

```bash
firebase deploy --only functions,hosting
```

---

## Testar localmente

```bash
firebase emulators:start
```

Nota: no emulador local a function precisa da variável de ambiente:
```bash
export ANTHROPIC_KEY="sk-ant-..."
```
E alterar temporariamente em `functions/index.js`:
```js
const apiKey = process.env.ANTHROPIC_KEY || (functions.config().anthropic || {}).key || '';
```

---

## Como funciona

1. O browser faz `POST /api/claude` (mesmo domínio → sem CORS)
2. Firebase Hosting redireciona para a Cloud Function `claude`
3. A function faz o pedido real à `api.anthropic.com` com a API key
4. Devolve a resposta ao browser

A API key fica segura no servidor — nunca exposta no frontend.
