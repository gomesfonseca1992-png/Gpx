/**
 * Stats Calculator — calcula todas as métricas de uma atividade GPX
 * Fase 1 — GPX Analyzer Platform
 *
 * Input:  { metadata, trackPoints } do GPXParser
 * Output: objeto stats completo para guardar no Firestore
 */

// ─── TRIMP → Esforço/Recuperação — fonte única de verdade ─────────────────────
// FIX: extraido de calcHRZones + calcRecFromMetrics para evitar duplicacao
// Calibrado para ciclismo de resistencia (Morton et al. 1990 + empirico)
const TRIMP_BANDS = [
  { min:   0, max:  80, label:'Leve',            color:'#94a3b8', icon:'😌', recMin: 12, recMax:  24 },
  { min:  80, max: 160, label:'Moderado',         color:'#38bdf8', icon:'🙂', recMin: 24, recMax:  36 },
  { min: 160, max: 250, label:'Bom treino',       color:'#22c55e', icon:'💪', recMin: 36, recMax:  48 },
  { min: 250, max: 350, label:'Intenso',          color:'#f97316', icon:'🔥', recMin: 48, recMax:  60 },
  { min: 350, max: 450, label:'Muito intenso',    color:'#ef4444', icon:'⚡', recMin: 60, recMax:  72 },
  { min: 450, max: 550, label:'Extremo',          color:'#a855f7', icon:'🚨', recMin: 72, recMax:  84 },
  { min: 550, max: 650, label:'Extremo Moderado', color:'#c026d3', icon:'💀', recMin: 84, recMax:  96 },
  { min: 650, max: 800, label:'Extremo Hard',     color:'#e11d48', icon:'☠️', recMin: 96, recMax: 108 },
  { min: 800, max: 950, label:'Extremo Super',    color:'#ff0050', icon:'🆘', recMin:108, recMax: 120 },
];

const GPXStats = (() => {

  // ─── Formata segundos → "1h 23min 45s" ──────────────────────────────────────
  function formatDuration(seconds) {
    if (!seconds || seconds <= 0) return '--';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return `${h}h ${m.toString().padStart(2,'0')}min`;
    if (m > 0) return `${m}min ${s.toString().padStart(2,'0')}s`;
    return `${s}s`;
  }

  // ─── Pace: segundos por km → "4:32 /km" ─────────────────────────────────────
  function formatPace(secPerKm) {
    if (!secPerKm || secPerKm <= 0 || secPerKm > 3600) return '--';
    const m = Math.floor(secPerKm / 60);
    const s = Math.floor(secPerKm % 60);
    return `${m}:${s.toString().padStart(2,'0')} /km`;
  }

  // ─── Calcula desnível ganho/perdido com threshold anti-ruído ─────────────────
  // FIX: threshold aumentado de 0.4 para 2.0m — elimina ruido GPS iGPSport
  // (threshold 0.4m acumulava ruido e inflacionava o desnivel 15-25% em treinos planos)
  function calcElevation(trackPoints, threshold = 2.0) {
    let gain = 0, loss = 0, maxEle = -Infinity, minEle = Infinity;
    let pending = 0;

    const pts = trackPoints.filter(p => p.ele !== null);
    if (pts.length < 2) return { gain: 0, loss: 0, maxEle: null, minEle: null };

    for (let i = 1; i < pts.length; i++) {
      const diff = pts[i].ele - pts[i-1].ele;
      pending += diff;
      if (Math.abs(pending) >= threshold) {
        if (pending > 0) gain += pending;
        else             loss += Math.abs(pending);
        pending = 0;
      }
      if (pts[i].ele > maxEle) maxEle = pts[i].ele;
      if (pts[i].ele < minEle) minEle = pts[i].ele;
    }
    // Início
    if (pts[0].ele > maxEle) maxEle = pts[0].ele;
    if (pts[0].ele < minEle) minEle = pts[0].ele;

    return {
      gain: Math.round(gain),
      loss: Math.round(loss),
      maxEle: Math.round(maxEle * 10) / 10,
      minEle: Math.round(minEle * 10) / 10,
    };
  }

  // ─── Velocidades: média, máxima, percentis ───────────────────────────────────
  function calcSpeeds(trackPoints) {
    const speeds = trackPoints
      .map(p => p.speed)
      .filter(s => s !== null && s > 0.5); // ignora paradas e ruído

    if (speeds.length === 0) return { avg: null, max: null, p95: null };

    const sorted = [...speeds].sort((a, b) => a - b);
    const max    = sorted[sorted.length - 1];
    const p95idx = Math.floor(sorted.length * 0.95);
    const p95    = sorted[p95idx]; // 95th percentile (mais representativo que max absoluto)
    const avg    = speeds.reduce((s, v) => s + v, 0) / speeds.length;

    return {
      avg:  Math.round(avg  * 10) / 10,
      max:  Math.round(max  * 10) / 10,
      p95:  Math.round(p95  * 10) / 10,
    };
  }

  // ─── Tempo em movimento vs tempo total ───────────────────────────────────────
  function calcTimes(trackPoints) {
    if (!trackPoints[0]?.time || !trackPoints[trackPoints.length - 1]?.time) {
      return { total: null, moving: null, stopped: null };
    }

    const t0  = new Date(trackPoints[0].time);
    const tN  = new Date(trackPoints[trackPoints.length - 1].time);
    const total = Math.round((tN - t0) / 1000); // segundos

    // Tempo em movimento: soma intervalos onde speed > 2 km/h (threshold iGPSport/Strava)
    // Testado contra GPX real: threshold=2 → match de 135s vs iGPSport 2h22:44
    let moving = 0;
    for (let i = 1; i < trackPoints.length; i++) {
      const p    = trackPoints[i];
      const prev = trackPoints[i - 1];
      if (!p.time || !prev.time) continue;
      const dt = (new Date(p.time) - new Date(prev.time)) / 1000;
      if (dt > 0 && dt < 600 && (p.speed === null || p.speed > 2)) {
        moving += dt;
      }
    }

    moving = Math.round(moving);
    return {
      total,
      moving,
      stopped: total - moving,
    };
  }

  // ─── Segmentos por km (splits) ───────────────────────────────────────────────
  function calcSplits(trackPoints) {
    const splits = [];
    let currentKm   = 1;
    let kmStartDist = 0;
    let kmStartTime = trackPoints[0]?.time ? new Date(trackPoints[0].time) : null;

    for (let i = 1; i < trackPoints.length; i++) {
      const p = trackPoints[i];
      const distKm = p.distFromStart / 1000;

      if (distKm >= currentKm) {
        const endTime = p.time ? new Date(p.time) : null;
        const duration = (kmStartTime && endTime)
          ? Math.round((endTime - kmStartTime) / 1000)
          : null;

        splits.push({
          km:       currentKm,
          pace:     duration ? formatPace(duration)         : null,
          paceRaw:  duration,
          avgSpeed: duration ? Math.round((1000 / duration) * 3.6 * 10) / 10 : null,
        });

        kmStartDist = p.distFromStart;
        kmStartTime = endTime;
        currentKm++;
      }
    }

    return splits;
  }

  // ─── Pontos de perfil para gráficos (altitude + velocidade) ─────────────────
  // Reduz a no máximo `maxPoints` amostras para não sobrecarregar o Firestore
  function buildChartData(trackPoints, maxPoints = 500) {
    const total = trackPoints.length;
    const step  = total <= maxPoints ? 1 : Math.floor(total / maxPoints);

    const elevation = [];
    const speed     = [];
    const hr        = [];
    const cadence   = [];
    const power     = [];
    const temperature = [];

    for (let i = 0; i < total; i += step) {
      const p    = trackPoints[i];
      const dist = Math.round(p.distFromStart / 10) / 100;

      if (p.ele   !== null) elevation.push({ d: dist, e: Math.round(p.ele) });
      if (p.speed !== null) speed.push({ d: dist, s: p.speed });
      if (p.hr    !== null && p.hr)      hr.push({ d: dist, v: p.hr });
      if (p.cadence!== null && p.cadence) cadence.push({ d: dist, v: p.cadence });
      if (p.power !== null && p.power)   power.push({ d: dist, v: p.power });
      if (p.temp  !== null && p.temp !== undefined) temperature.push({ d: dist, v: p.temp });
    }

    return { elevation, speed, hr, cadence, power, temperature };
  }

  // ─── Função principal: calcula tudo ─────────────────────────────────────────
  function calculate(parsed) {
    const { metadata, trackPoints } = parsed;

    if (!trackPoints || trackPoints.length === 0) {
      throw new Error('Sem trackpoints para calcular estatísticas.');
    }

    const distanceM  = trackPoints[trackPoints.length - 1].distFromStart;
    const distanceKm = Math.round(distanceM / 10) / 100;

    const elev      = calcElevation(trackPoints);
    // ── FIT fidelidade: se o dispositivo reportou total_ascent/descent, usar ──
    // O valor oficial do dispositivo é mais preciso que o recálculo ponto-a-ponto
    // (o dispositivo usa GNSS com barômetro e filtros proprietários)
    if (metadata.fitTotalAscent  != null) elev.gain = metadata.fitTotalAscent;
    if (metadata.fitTotalDescent != null) elev.loss = metadata.fitTotalDescent;
    const speeds    = calcSpeeds(trackPoints);
    const times     = calcTimes(trackPoints);
    const splits    = calcSplits(trackPoints);
    const chartData = buildChartData(trackPoints);

    // Pace médio (baseado em tempo em movimento)
    const paceSecPerKm = (times.moving && distanceKm > 0)
      ? times.moving / distanceKm
      : null;

    // Grade dificuldade simples
    const difficulty = calcDifficulty(distanceKm, elev.gain);

    // ─── HR, cadência, potência ──────────────────────────────────────────
    const hrVals  = trackPoints.map(p=>p.hr).filter(v=>v!=null&&v>0);
    const cadVals = trackPoints.map(p=>p.cadence).filter(v=>v!=null&&v>0);
    const pwrVals = trackPoints.map(p=>p.power).filter(v=>v!=null&&v>0);
    const tmpVals = trackPoints.map(p=>p.temp).filter(v=>v!=null&&v>-40&&v<80);

    const avgHR  = hrVals.length  ? Math.round(hrVals.reduce((a,b)=>a+b,0)/hrVals.length)   : null;
    const maxHR  = hrVals.length  ? Math.max(...hrVals)   : null;
    const avgCad = cadVals.length ? Math.round(cadVals.reduce((a,b)=>a+b,0)/cadVals.length) : null;
    const maxCad = cadVals.length ? Math.max(...cadVals) : null;
    const avgPwr = pwrVals.length ? Math.round(pwrVals.reduce((a,b)=>a+b,0)/pwrVals.length) : null;
    const maxPwr = pwrVals.length ? Math.max(...pwrVals) : null;
    const avgTemp = tmpVals.length ? Math.round(tmpVals.reduce((a,b)=>a+b,0)/tmpVals.length*10)/10 : null;
    const minTemp = tmpVals.length ? Math.round(Math.min(...tmpVals)*10)/10 : null;
    const maxTemp = tmpVals.length ? Math.round(Math.max(...tmpVals)*10)/10 : null;

    // ─── Zonas de treino ──────────────────────────────────────────────────
    const hrZones  = calcHRZones(trackPoints, parsed.userSettings?.fcMax || null, parsed.userSettings?.fcRest || null);
    const pwrZones = calcPowerZones(trackPoints, parsed.userSettings?.ftp || null, parsed.userSettings?.weight || null);
    const cadZones = calcCadenceZones(trackPoints, metadata.sport);

    // ─── Calorias ─────────────────────────────────────────────────────────
    const calories = calcCalories(
      trackPoints, times, distanceKm,
      avgHR, avgPwr,
      parsed.userSettings || null
    );

    // ─── Subidas ──────────────────────────────────────────────────────────
    const climbs = detectClimbs(trackPoints);

    return {
      name:   metadata.name,
      sport:  metadata.sport,
      date:   metadata.time,
      difficulty,
      distanceKm,
      distanceM: Math.round(distanceM),
      durationTotal:   times.total,
      durationMoving:  times.moving,
      durationStopped: times.stopped,
      durationFormatted: formatDuration(times.moving || times.total),
      avgSpeedKmh: speeds.avg,
      maxSpeedKmh: speeds.max,
      p95SpeedKmh: speeds.p95,
      avgPace:    formatPace(paceSecPerKm),
      avgPaceRaw: paceSecPerKm ? Math.round(paceSecPerKm) : null,
      elevGain:   elev.gain,
      elevLoss:   elev.loss,
      maxElevation: elev.maxEle,
      minElevation: elev.minEle,
      elevRange:  elev.maxEle !== null ? Math.round(elev.maxEle - elev.minEle) : null,
      avgHR, maxHR,
      avgCadence: avgCad,
      maxCadence: maxCad,
      avgPower: avgPwr,
      maxPower: maxPwr,
      hasHR:      hrVals.length > 0,
      hasCadence: cadVals.length > 0,
      hasPower:   pwrVals.length > 0,
      hasTemp:    tmpVals.length > 0,
      avgTemp, minTemp, maxTemp,
      hrZones,
      pwrZones,
      cadZones,
      calories,
      climbs,
      chartData,
      splits,
      pointCount: trackPoints.length,
      decoupling: calcDecoupling(trackPoints),
    };
  }

  // ─── Deteção automática de segmentos de subida ──────────────────────────────
  // Critérios: gradiente médio ≥ 2%, distância ≥ 200m, ganho ≥ 10m
  // Retorna array de subidas com: distância, ganho, gradiente avg/max, VAM, categoria
  function detectClimbs(trackPoints, opts = {}) {
    const minGrad    = opts.minGrad    || 2.0;   // % mínimo
    const minDist    = opts.minDist    || 200;    // metros
    const minGain    = opts.minGain    || 10;     // metros
    const windowSize = opts.windowSize || 100;    // metros para calcular gradiente local
    const lookAhead  = opts.lookAhead  || 200;    // metros para decidir se subida continua

    const pts = trackPoints.filter(p => p.ele !== null && p.distFromStart !== undefined);
    if (pts.length < 10) return [];

    const climbs = [];
    let i = 0;

    while (i < pts.length - 1) {
      // Calcula gradiente da janela atual
      let j = i + 1;
      while (j < pts.length && pts[j].distFromStart - pts[i].distFromStart < windowSize) j++;
      if (j >= pts.length) break;

      const segDist = pts[j].distFromStart - pts[i].distFromStart;
      const segGain = pts[j].ele - pts[i].ele;
      const grad    = segDist > 0 ? (segGain / segDist) * 100 : 0;

      if (grad >= minGrad) {
        // Início de subida — estende até gradiente cair
        const startIdx = i;
        let   peakIdx  = i;
        let   peakEle  = pts[i].ele;
        let   k = j;

        while (k < pts.length - 1) {
          // Verifica próximos 200m
          let l = k + 1;
          while (l < pts.length && pts[l].distFromStart - pts[k].distFromStart < lookAhead) l++;
          if (l >= pts.length) { k = l; break; }

          const d2 = pts[l].distFromStart - pts[k].distFromStart;
          const g2 = pts[l].ele - pts[k].ele;
          const gr2 = d2 > 0 ? (g2 / d2) * 100 : 0;

          if (gr2 < -1.5) break; // descida real → fim da subida
          if (pts[k].ele > peakEle) { peakEle = pts[k].ele; peakIdx = k; }
          k++;
        }

        const endIdx  = peakIdx;
        const cDist   = pts[endIdx].distFromStart - pts[startIdx].distFromStart;
        const cGain   = pts[endIdx].ele - pts[startIdx].ele;
        const cGrad   = cDist > 0 ? (cGain / cDist) * 100 : 0;

        if (cDist >= minDist && cGain >= minGain) {
          // Gradiente máximo (janela 50m)
          let maxGrad = 0;
          for (let m = startIdx; m < endIdx - 1; m++) {
            let n = m + 1;
            while (n < endIdx && pts[n].distFromStart - pts[m].distFromStart < 50) n++;
            if (n >= endIdx) break;
            const wd = pts[n].distFromStart - pts[m].distFromStart;
            const wg = pts[n].ele - pts[m].ele;
            if (wd > 0) maxGrad = Math.max(maxGrad, (wg / wd) * 100);
          }

          // VAM (velocidade ascensional m/h) via timestamps
          let vam = null;
          if (pts[startIdx].time && pts[endIdx].time) {
            const t0 = new Date(pts[startIdx].time);
            const t1 = new Date(pts[endIdx].time);
            const secs = (t1 - t0) / 1000;
            if (secs > 0) vam = Math.round(cGain / secs * 3600);
          }

          // Velocidade média na subida
          let avgSpeedClimb = null;
          if (pts[startIdx].time && pts[endIdx].time) {
            const secs = (new Date(pts[endIdx].time) - new Date(pts[startIdx].time)) / 1000;
            if (secs > 0) avgSpeedClimb = Math.round((cDist / secs) * 3.6 * 10) / 10;
          }

          // Categoria (modelo Strava/Komoot — score = gain × avg_grad / 10)
          const score = (cGain * Math.abs(cGrad)) / 10;
          const cat = score > 160 ? 'HC'
                    : score > 80  ? '1ª'
                    : score > 50  ? '2ª'
                    : score > 30  ? '3ª'
                    :               '4ª';

          const catColor = cat === 'HC' ? '#ef4444'
                         : cat === '1ª' ? '#f97316'
                         : cat === '2ª' ? '#f59e0b'
                         : cat === '3ª' ? '#22c55e'
                         :                '#38bdf8';

          climbs.push({
            id:         climbs.length + 1,
            startDist:  Math.round(pts[startIdx].distFromStart / 10) / 100, // km
            endDist:    Math.round(pts[endIdx].distFromStart   / 10) / 100,
            lengthKm:   Math.round(cDist / 10) / 100,
            gainM:      Math.round(cGain),
            avgGrad:    Math.round(cGrad * 10) / 10,
            maxGrad:    Math.round(maxGrad * 10) / 10,
            maxEleM:    Math.round(peakEle),
            startEleM:  Math.round(pts[startIdx].ele),
            vam,
            avgSpeedKmh: avgSpeedClimb,
            score:      Math.round(score),
            category:   cat,
            catColor,
          });
        }

        i = endIdx + 1;
      } else {
        i++;
      }
    }

    // Ordena por distância de início
    return climbs.sort((a, b) => a.startDist - b.startDist);
  }

  // ─── Calorias — Keytel (FC), Potência (W) ou MET (fallback) ─────────────────
  // userProfile: { weight: kg, age: anos, gender: 'M'|'F', height: cm }
  function calcCalories(trackPoints, times, distanceKm, avgHR, avgPower, userProfile) {
    const weight = userProfile?.weight || 75;   // default seguro
    const age    = userProfile?.age    || 30;
    const gender = userProfile?.gender || 'M';
    const height = userProfile?.height || 175;
    const movingMin = (times.moving || times.total || 0) / 60;
    const movingH   = movingMin / 60;

    if (movingMin <= 0) return null;

    let kcalExercise = 0;

    // ── Método 1: Potência (mais preciso — eficiência mecânica ~25%) ──────────
    if (avgPower && avgPower > 0) {
      const movingSec = movingMin * 60;
      kcalExercise = (avgPower * movingSec) / (4184 * 0.25);
    }
    // ── Método 2: Keytel HR-based (padrão Garmin/Strava) ─────────────────────
    else if (avgHR && avgHR > 0) {
      if (gender === 'M') {
        kcalExercise = ((-55.0969 + 0.6309*avgHR + 0.1988*weight + 0.2017*age) / 4.184) * movingMin;
      } else {
        kcalExercise = ((-20.4022 + 0.4472*avgHR - 0.1263*weight + 0.074*age) / 4.184) * movingMin;
      }
    }
    // ── Método 3: MET-based (fallback sem HR nem potência) ────────────────────
    else if (distanceKm > 0) {
      const avgSpeedKmh = distanceKm / Math.max(movingH, 0.1);
      const met = avgSpeedKmh < 12 ? 5.8
                : avgSpeedKmh < 16 ? 8.0
                : avgSpeedKmh < 20 ? 10.0
                : avgSpeedKmh < 25 ? 12.0
                : 15.8;
      kcalExercise = met * weight * movingH;
    }

    if (kcalExercise <= 0) return null;

    // ── BMR durante atividade (Harris-Benedict) ───────────────────────────────
    let bmrDay;
    if (gender === 'M') {
      bmrDay = 88.362 + 13.397*weight + 4.799*height - 5.677*age;
    } else {
      bmrDay = 447.593 + 9.247*weight + 3.098*height - 4.330*age;
    }
    const bmrDuring = bmrDay / 24 * movingH;

    const total = Math.round(kcalExercise + bmrDuring);

    // Fonte do cálculo (para mostrar na UI)
    const method = avgPower ? 'potência' : avgHR ? 'FC' : 'velocidade';

    return { total, kcalExercise: Math.round(kcalExercise), bmr: Math.round(bmrDuring), method };
  }

  // ─── Zonas FC + TRIMP completo + Análise de Esforço ─────────────────────────
  // fcRest padrão = 50 bpm (nunca usa min do GPX — é FC durante esforço, não repouso)
  function calcHRZones(trackPoints, fcMax, fcRest, gender) {
    const hrVals = trackPoints.map(p => p.hr).filter(v => v != null && v > 0);
    if (hrVals.length === 0) return null;

    const detectedMax = Math.max(...hrVals);
    const usedFcMax   = fcMax  || Math.round(detectedMax * 1.05);
    const usedFcRest  = fcRest || 50;

    const ZONES = [
      { id:1, label:'Z1', name:'Recuperação',   min:0,    max:0.60, color:'#94a3b8' },
      { id:2, label:'Z2', name:'Base Aeróbica', min:0.60, max:0.70, color:'#38bdf8' },
      { id:3, label:'Z3', name:'Aeróbico',      min:0.70, max:0.80, color:'#22c55e' },
      { id:4, label:'Z4', name:'Limiar',        min:0.80, max:0.90, color:'#f97316' },
      { id:5, label:'Z5', name:'VO₂ Máx',       min:0.90, max:1.00, color:'#ef4444' },
    ];

    // Tempo real em cada zona (segundos)
    const zoneSecs = Array(5).fill(0);
    // Verifica se temos timestamps para cálculo de tempo real
    const hasTime = trackPoints.some(p => p.time != null);
    const DEFAULT_DT = 1; // fallback: 1 segundo por ponto quando sem time
    for (let i = 1; i < trackPoints.length; i++) {
      const p = trackPoints[i], prev = trackPoints[i-1];
      if (!p.hr) continue;
      let dt = DEFAULT_DT;
      if (hasTime && p.time && prev.time) {
        dt = (new Date(p.time) - new Date(prev.time)) / 1000;
        if (dt <= 0 || dt > 300) continue;
      }
      const hrPct = p.hr / usedFcMax;
      for (let z = 0; z < 5; z++) {
        const hi = z === 4 ? 99 : ZONES[z+1].min;
        if (hrPct >= ZONES[z].min && hrPct < hi) { zoneSecs[z] += dt; break; }
      }
    }

    const totalSecs = zoneSecs.reduce((a,b) => a+b, 0);
    const zones = ZONES.map((z, idx) => {
      const lo = Math.round(z.min * usedFcMax);
      const hi = idx === 4 ? usedFcMax : Math.round(ZONES[idx+1].min * usedFcMax);
      const secs = zoneSecs[idx];
      const pct  = totalSecs > 0 ? Math.round((secs/totalSecs)*100) : 0;
      const mins = Math.floor(secs/60);
      const timeLabel = mins >= 60
        ? `${Math.floor(mins/60)}h${String(mins%60).padStart(2,'0')}min`
        : `${mins}min`;
      return { ...z, bpmLow:lo, bpmHigh:hi, secs, pct, timeLabel, range:`${lo}–${hi}` };
    });

    // TRIMP Bannister — coeficiente b por género (Morton et al. 1990)
    // b=1.92 masculino, b=1.67 feminino
    const _gender = gender || (typeof localStorage !== 'undefined' && localStorage.getItem('gpx_gender')) || 'M';
    const _trimpB = _gender === 'F' ? 1.67 : 1.92;
    let trimp = 0;
    const zoneTrimp = Array(5).fill(0);
    for (let i = 1; i < trackPoints.length; i++) {
      const p = trackPoints[i], prev = trackPoints[i-1];
      if (!p.hr) continue;
      let dtMin = DEFAULT_DT / 60;
      if (hasTime && p.time && prev.time) {
        dtMin = (new Date(p.time) - new Date(prev.time)) / 60000;
        if (dtMin <= 0 || dtMin > 5) continue;
      }
      const hrRatio = (p.hr - usedFcRest) / (usedFcMax - usedFcRest);
      if (hrRatio <= 0) continue;
      const contrib = dtMin * hrRatio * Math.exp(_trimpB * hrRatio); // Banister original: sem fator 0.64
      trimp += contrib;
      const hrPct = p.hr / usedFcMax;
      for (let z = 0; z < 5; z++) {
        const hi = z === 4 ? 99 : ZONES[z+1].min;
        if (hrPct >= ZONES[z].min && hrPct < hi) { zoneTrimp[z] += contrib; break; }
      }
    }
    trimp = Math.round(trimp);

    // FIX: usa TRIMP_BANDS — constante partilhada, fonte unica de verdade
    const _band = TRIMP_BANDS.find(function(b){ return trimp < b.max; }) || TRIMP_BANDS[TRIMP_BANDS.length-1];
    // Interpolação linear: t=0 no início da faixa, t=1 no fim
    const _t   = Math.min(1, Math.max(0, (trimp - _band.min) / (_band.max - _band.min)));
    const _rec = Math.round(_band.recMin + _t * (_band.recMax - _band.recMin));
    const effortLevel = { label:_band.label, color:_band.color, icon:_band.icon, rec:_rec };

    // Perfil aeróbico/anaeróbico
    const aerobicSecs   = zoneSecs[0]+zoneSecs[1]+zoneSecs[2];
    const anaerobicSecs = zoneSecs[3]+zoneSecs[4];
    const aerobicPct    = totalSecs > 0 ? Math.round((aerobicSecs/totalSecs)*100)   : 0;
    const anaerobicPct  = totalSecs > 0 ? Math.round((anaerobicSecs/totalSecs)*100) : 0;
    const trainType = aerobicPct > 85 ? 'Base Aeróbica'
                    : aerobicPct > 70 ? 'Resistência'
                    : aerobicPct > 55 ? 'Limiar'
                    :                   'Alta Intensidade';

    const dominant = zones.reduce((a,b) => a.secs > b.secs ? a : b);

    return {
      fcMax: usedFcMax, fcRest: usedFcRest,
      zones,
      zoneTrimp: ZONES.map((z, idx) => ({
        label: z.label, name: z.name, color: z.color,
        trimp: Math.round(zoneTrimp[idx] * 10) / 10,
        bpmLow: Math.round(z.min * usedFcMax),
        bpmHigh: idx===4 ? usedFcMax : Math.round(ZONES[idx+1].min * usedFcMax),
      })),
      dominant, trimp, effortLevel,
      aerobicPct, anaerobicPct, trainType,
      recoveryHours: effortLevel.rec,
    };
  }

  // ─── Calcular recuperação a partir de métricas agregadas (sem trackPoints) ───
  // Usado pelo histórico para ser consistente com a análise ao vivo
  // FIX: aceita parametro gender; le localStorage como fallback (consistente com calcHRZones)
  function calcRecFromMetrics(hrAvg, hrMax, durationSecs, fcRest, gender) {
    if (!hrAvg || !durationSecs) return null;
    var _fcRest  = fcRest || 50;
    var _fcMax   = hrMax  || hrAvg * 1.12;
    var _hrRatio = Math.max(0, Math.min(1, (hrAvg - _fcRest) / (_fcMax - _fcRest)));
    // FIX: usar coeficiente b por genero (Morton et al. 1990) — igual ao calcHRZones
    var _g = gender || (typeof localStorage !== 'undefined' && localStorage.getItem('gpx_gender')) || 'M';
    var _b = _g === 'F' ? 1.67 : 1.92;
    var _trimp   = Math.round((durationSecs / 60) * _hrRatio * Math.exp(_b * _hrRatio));
    // FIX: usa TRIMP_BANDS — constante partilhada, fonte unica de verdade
    var _band = TRIMP_BANDS.find(function(b){ return _trimp < b.max; }) || TRIMP_BANDS[TRIMP_BANDS.length - 1];
    var _t    = Math.min(1, Math.max(0, (_trimp - _band.min) / (_band.max - _band.min)));
    var _rec  = Math.round(_band.recMin + _t * (_band.recMax - _band.recMin));
    return { trimp: _trimp, rec: _rec, label: _band.label, color: _band.color, icon: _band.icon };
  }
  function calcPowerZones(trackPoints, ftp, weightKg) {
    const pwrPts = trackPoints.filter(p => p.power != null && p.power >= 0);
    if (pwrPts.length === 0) return null;
    const pwrVals = pwrPts.map(p => p.power);
    const weight  = weightKg || 75;

    // ── NP com janela temporal de 30s ──────────────────────────────────────────
    // FIX: algoritmo O(n) com dois ponteiros — era O(n^2), bloqueava UI em treinos longos
    const np30s = [];
    const hasTime30 = pwrPts.some(p => p.time != null);
    if (hasTime30) {
      // Sliding window temporal: dois ponteiros left/right
      let left = 0, windowSum = 0;
      for (let right = 0; right < pwrPts.length; right++) {
        windowSum += pwrPts[right].power;
        // Remove pontos fora da janela de 30s
        while (left < right && pwrPts[right].time && pwrPts[left].time) {
          const dt = (new Date(pwrPts[right].time).getTime() - new Date(pwrPts[left].time).getTime()) / 1000;
          if (dt <= 30) break;
          windowSum -= pwrPts[left].power;
          left++;
        }
        const count = right - left + 1;
        if (count > 0) np30s.push(Math.pow(windowSum / count, 4));
      }
    } else {
      // Sem timestamps: sliding window de 30 pontos (fallback)
      let windowSum = 0;
      for (let i = 0; i < pwrPts.length; i++) {
        windowSum += pwrPts[i].power;
        if (i >= 30) windowSum -= pwrPts[i - 30].power;
        const count = Math.min(i + 1, 30);
        np30s.push(Math.pow(windowSum / count, 4));
      }
    }
    const np = np30s.length > 0
      ? Math.round(Math.pow(np30s.reduce((a, b) => a + b, 0) / np30s.length, 0.25))
      : null;

    const avgPower = Math.round(pwrVals.reduce((a, b) => a + b, 0) / pwrVals.length);
    const maxPower = Math.max(...pwrVals);
    const intensityFactor = (np && ftp) ? Math.round((np / ftp) * 100) / 100 : null;
    const vi = (np && avgPower > 0) ? Math.round((np / avgPower) * 100) / 100 : null;

    let movingSecs = 0;
    for (let i = 1; i < pwrPts.length; i++) {
      if (!pwrPts[i].time || !pwrPts[i-1].time) { movingSecs++; continue; }
      const dt = (new Date(pwrPts[i].time) - new Date(pwrPts[i-1].time)) / 1000;
      if (dt > 0 && dt < 300) movingSecs += dt;
    }
    const tss = (np && intensityFactor && ftp)
      ? Math.round((movingSecs * np * intensityFactor) / (ftp * 3600) * 100)
      : null;

    // ── W/kg ──────────────────────────────────────────────────────────────────
    const wkg    = Math.round((avgPower / weight) * 100) / 100;
    const wkgMax = Math.round((maxPower  / weight) * 100) / 100;
    const wkgNP  = np ? Math.round((np / weight) * 100) / 100 : null;
    const WKG_CATS = [
      { min:0,   max:2.0, label:'Iniciante',  color:'#94a3b8' },
      { min:2.0, max:3.0, label:'Recreativo', color:'#38bdf8' },
      { min:3.0, max:3.5, label:'Sport',      color:'#22c55e' },
      { min:3.5, max:4.0, label:'Cat 4–5',    color:'#f59e0b' },
      { min:4.0, max:4.5, label:'Cat 3',      color:'#f97316' },
      { min:4.5, max:5.0, label:'Cat 1–2',    color:'#ef4444' },
      { min:5.0, max:99,  label:'Pro/Elite',  color:'#a855f7' },
    ];
    const wkgCat = WKG_CATS.find(c => wkg >= c.min && wkg < c.max) || WKG_CATS[0];

    // ── MMP Curve ─────────────────────────────────────────────────────────────
    const MMP_D = [5,10,15,30,60,120,300,360,600,720,1200,1800,3600];
    const MMP_L = ['5"','10"','15"','30"',"1'","2'","5'","6'","10'","12'","20'","30'",'1h'];
    const n = pwrVals.length;
    const mmpCurve = [];
    for (let di = 0; di < MMP_D.length; di++) {
      const w = MMP_D[di];
      if (w > n) break;
      let s = 0;
      for (let i = 0; i < w; i++) s += pwrVals[i];
      let best = s;
      for (let i = 1; i <= n - w; i++) {
        s = s - pwrVals[i-1] + pwrVals[i+w-1];
        if (s > best) best = s;
      }
      const mW = Math.round(best / w);
      mmpCurve.push({
        durSec: w, label: MMP_L[di],
        watts: mW,
        wkg:   Math.round((mW / weight) * 100) / 100,
        pctFtp: ftp ? Math.round((mW / ftp) * 100) : null,
      });
    }

    // ── Zonas Coggan 7 ────────────────────────────────────────────────────────
    const ZONES_PWR = [
      { id:1, label:'Z1', name:'Recuperação Ativa', min:0,    max:0.55, color:'#94a3b8' },
      { id:2, label:'Z2', name:'Resistência',       min:0.55, max:0.75, color:'#38bdf8' },
      { id:3, label:'Z3', name:'Tempo',             min:0.75, max:0.90, color:'#22c55e' },
      { id:4, label:'Z4', name:'Limiar Lactato',    min:0.90, max:1.05, color:'#f59e0b' },
      { id:5, label:'Z5', name:'VO₂ Máx',           min:1.05, max:1.20, color:'#f97316' },
      { id:6, label:'Z6', name:'Capacidade Anae.',  min:1.20, max:1.50, color:'#ef4444' },
      { id:7, label:'Z7', name:'Sprint Neuromusc.', min:1.50, max:99,   color:'#a855f7' },
    ];
    let zones = null;
    if (ftp) {
      const tot = pwrVals.length;
      zones = ZONES_PWR.map((z, idx) => {
        const lo = Math.round(z.min * ftp);
        const hi = z.id === 7 ? 99999 : Math.round(ZONES_PWR[idx+1].min * ftp);
        const pts = pwrVals.filter(w => w >= lo && w < hi).length;
        return { ...z, wLow:lo, wHigh: z.id===7?null:hi, points:pts, pct:Math.round((pts/tot)*100) };
      });
    }

    return { ftp, avgPower, maxPower, np, intensityFactor, vi, tss, wkg, wkgMax, wkgNP, wkgCat, mmpCurve, zones };
  }

  // ─── Dificuldade estimada ────────────────────────────────────────────────────
  // FIX: substituido Naismith (caminhada) por indice FIETS (padrao ciclismo)
  // FIETS = (desnivel_m^2 / 10) / dist_m  — referencia padrao cicloturismo europeu
  // Calibrado: 0.5=Facil, 1.2=Moderado, 5.0=Dificil — validado em 10 percursos reais
  function calcDifficulty(distKm, elevGain) {
    const gain  = elevGain || 0;
    const distM = (distKm || 1) * 1000;
    const fiets = (gain * gain / 10) / distM;
    if (fiets < 0.5) return { label: 'Fácil',    level: 1, color: '#22c55e' };
    if (fiets < 1.2) return { label: 'Moderado', level: 2, color: '#f59e0b' };
    if (fiets < 5.0) return { label: 'Difícil',  level: 3, color: '#f97316' };
    return             { label: 'Extremo',   level: 4, color: '#ef4444' };
  }

  // ─── Compara duas atividades ─────────────────────────────────────────────────
  function compare(statsA, statsB) {
    const diff = (a, b) => (a !== null && b !== null) ? Math.round((a - b) * 100) / 100 : null;
    const pct  = (a, b) => (a && b) ? Math.round(((a - b) / b) * 1000) / 10 : null;

    return {
      distance:  { diff: diff(statsA.distanceKm, statsB.distanceKm),    pct: pct(statsA.distanceKm, statsB.distanceKm) },
      duration:  { diff: diff(statsA.durationMoving, statsB.durationMoving), pct: pct(statsA.durationMoving, statsB.durationMoving) },
      avgSpeed:  { diff: diff(statsA.avgSpeedKmh, statsB.avgSpeedKmh),   pct: pct(statsA.avgSpeedKmh, statsB.avgSpeedKmh) },
      elevGain:  { diff: diff(statsA.elevGain, statsB.elevGain),         pct: pct(statsA.elevGain, statsB.elevGain) },
      maxSpeed:  { diff: diff(statsA.maxSpeedKmh, statsB.maxSpeedKmh),   pct: pct(statsA.maxSpeedKmh, statsB.maxSpeedKmh) },
    };
  }

  // ─── Zonas de Cadência ────────────────────────────────────────────────────────
  // Zonas baseadas em rpm para ciclismo (Coggan) e corrida (passos/min)
  function calcCadenceZones(trackPoints, sport) {
    const cadVals = trackPoints.map(p => p.cadence).filter(v => v != null && v > 0);
    if (cadVals.length === 0) return null;

    const isCycling = (sport === 'cycling');

    // Zonas de cadência para ciclismo (rpm) — baseadas em Coggan/Friel
    const ZONES_CYCLING = [
      { id:1, label:'Z1', name:'Muito lenta',   min:0,   max:60,  color:'#94a3b8', desc:'Muita força, baixa eficiência' },
      { id:2, label:'Z2', name:'Lenta',          min:60,  max:75,  color:'#38bdf8', desc:'Arrancadas, subidas pesadas' },
      { id:3, label:'Z3', name:'Confortável',    min:75,  max:85,  color:'#22c55e', desc:'Cadência de resistência' },
      { id:4, label:'Z4', name:'Óptima',         min:85,  max:95,  color:'#f97316', desc:'Zona ideal — maior eficiência' },
      { id:5, label:'Z5', name:'Alta',           min:95,  max:110, color:'#ef4444', desc:'Sprint, planícies rápidas' },
      { id:6, label:'Z6', name:'Muito alta',     min:110, max:999, color:'#a855f7', desc:'Sprint explosivo' },
    ];

    // Zonas para corrida (passos por minuto)
    const ZONES_RUNNING = [
      { id:1, label:'Z1', name:'Muito lenta',  min:0,   max:150, color:'#94a3b8', desc:'Caminhada / Aquecimento' },
      { id:2, label:'Z2', name:'Lenta',         min:150, max:160, color:'#38bdf8', desc:'Corrida fácil' },
      { id:3, label:'Z3', name:'Aeróbica',      min:160, max:170, color:'#22c55e', desc:'Corrida de base' },
      { id:4, label:'Z4', name:'Óptima',        min:170, max:180, color:'#f97316', desc:'Zona ideal (Maffetone)' },
      { id:5, label:'Z5', name:'Rápida',        min:180, max:190, color:'#ef4444', desc:'Competição / Limiar' },
      { id:6, label:'Z6', name:'Sprint',        min:190, max:999, color:'#a855f7', desc:'Sprint máximo' },
    ];

    const ZONES = isCycling ? ZONES_CYCLING : ZONES_RUNNING;

    const avg    = Math.round(cadVals.reduce((a, b) => a + b, 0) / cadVals.length);
    const max    = Math.max(...cadVals);
    const min    = Math.min(...cadVals);
    const total  = cadVals.length;

    // Conta pontos por zona
    const zones = ZONES.map(z => {
      const pts = cadVals.filter(v => v >= z.min && v < z.max).length;
      return {
        ...z,
        points: pts,
        pct:    Math.round((pts / total) * 100),
        timeLabel: '',
        range: z.max >= 999 ? `>${z.min}` : `${z.min}–${z.max}`,
      };
    });

    // Tempo real por zona (usando timestamps; fallback=1s/ponto se sem time)
    let totalSecs = 0;
    const zoneSecs = Array(ZONES.length).fill(0);
    const hasCadTime = trackPoints.some(p => p.time != null && p.cadence != null);
    const CAD_DT = 1; // fallback
    for (let i = 1; i < trackPoints.length; i++) {
      const p = trackPoints[i], prev = trackPoints[i-1];
      if (!p.cadence) continue;
      let dt = CAD_DT;
      if (hasCadTime && p.time && prev.time) {
        dt = (new Date(p.time) - new Date(prev.time)) / 1000;
        if (dt <= 0 || dt > 300) continue;
      }
      totalSecs += dt;
      for (let z = 0; z < ZONES.length; z++) {
        if (p.cadence >= ZONES[z].min && p.cadence < ZONES[z].max) {
          zoneSecs[z] += dt; break;
        }
      }
    }

    zones.forEach((z, i) => {
      const secs = zoneSecs[i];
      const mins = Math.floor(secs / 60);
      z.secs     = Math.round(secs);
      z.timeLabel = mins >= 60
        ? `${Math.floor(mins/60)}h${String(mins%60).padStart(2,'0')}min`
        : `${mins}min`;
      if (totalSecs > 0) z.pct = Math.round((secs / totalSecs) * 100);
    });

    const dominant = zones.reduce((a, b) => a.secs > b.secs ? a : b);

    // Classificação da cadência — zona 4 é "Óptima" em ambos os modos (85-95 rpm / 170-180 spm)
    const optZone  = zones.find(z => z.id === 4);
    const isOptimal = optZone && optZone.pct >= 25;

    return {
      avg, max, min,
      isCycling,
      zones,
      dominant,
      isOptimal,
      unit: isCycling ? 'rpm' : 'passos/min',
    };
  }

  // ─── Decoupling Aeróbico ─────────────────────────────────────────────────────
  // Compara relação FC/Velocidade na 1ª vs 2ª metade da actividade
  // Referência: Friel (2012) "The Cyclist's Training Bible"
  // < 5% = aeróbico sólido  |  5-10% = aceitável  |  >10% = fadiga/base fraca
  function calcDecoupling(trackPoints) {
    const pts = trackPoints.filter(p => p.hr > 0 && p.speed > 2 && p.distFromStart != null);
    if (pts.length < 40) return null;
    const mid   = Math.floor(pts.length / 2);
    const half1 = pts.slice(0, mid);
    const half2 = pts.slice(mid);
    function ef(arr) {
      const avgHR  = arr.reduce((s,p) => s + p.hr,    0) / arr.length;
      const avgSpd = arr.reduce((s,p) => s + p.speed,  0) / arr.length;
      return avgSpd > 0 ? avgHR / avgSpd : null;
    }
    const ef1 = ef(half1), ef2 = ef(half2);
    if (!ef1 || !ef2 || ef1 === 0) return null;
    const dec = Math.round(((ef2 - ef1) / ef1) * 1000) / 10;
    const label = dec < 2 ? 'Excelente' : dec < 5 ? 'Bom' : dec < 10 ? 'Aceitável' : dec < 15 ? 'Elevado' : 'Crítico';
    const color = dec < 2 ? '#22c55e'   : dec < 5 ? '#38bdf8' : dec < 10 ? '#f59e0b' : dec < 15 ? '#f97316' : '#ef4444';
    const tip   = dec < 5  ? 'Base aeróbica sólida — ritmo bem gerido.'
                : dec < 10 ? 'Alguma fadiga cardiovascular na segunda metade. Normal em treinos longos.'
                :             'FC subiu muito em relação à velocidade. Saída demasiado rápida ou base aeróbica a precisar de trabalho.';
    return { decoupling: dec, label, color, tip, ef1: Math.round(ef1*100)/100, ef2: Math.round(ef2*100)/100 };
  }

  // ─── Converte TRIMP já calculado → { rec, label, color, icon } ─────────────
  // Útil quando o TRIMP já foi calculado e só se quer saber a recuperação
  // Evita duplicar a lógica de interpolação em outros ficheiros
  function calcRecFromTrimp(trimp) {
    if (!trimp) return null;
    var band = TRIMP_BANDS.find(function(b){ return trimp < b.max; }) || TRIMP_BANDS[TRIMP_BANDS.length-1];
    var t    = Math.min(1, Math.max(0, (trimp - band.min) / (band.max - band.min)));
    var rec  = Math.round(band.recMin + t * (band.recMax - band.recMin));
    return { rec: rec, label: band.label, color: band.color, icon: band.icon };
  }

  return { calculate, compare, formatDuration, formatPace, calcDifficulty, calcDecoupling, calcHRZones, calcPowerZones, calcCadenceZones, calcCalories, detectClimbs, calcRecFromMetrics, calcRecFromTrimp };
})();

if (typeof module !== 'undefined') module.exports = GPXStats;

// Expõe TRIMP_BANDS globalmente para history.html e outros scripts
if (typeof window !== 'undefined') window.TRIMP_BANDS = TRIMP_BANDS;
