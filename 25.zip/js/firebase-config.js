/**
 * Firebase Config — GPX Analyzer Platform
 * 
 * ⚠️  SUBSTITUI estes valores pelas tuas credenciais do Firebase Console
 *     Project Settings → Your apps → Firebase SDK snippet → Config
 */


const firebaseConfig = {
  apiKey: "AIzaSyCw2bwJ3S-Vt9twDHmLhmunLa37EzgEJWg",
  authDomain: "gpx-analyzer-f9e5e.firebaseapp.com",
  projectId: "gpx-analyzer-f9e5e",
  storageBucket: "gpx-analyzer-f9e5e.firebasestorage.app",
  messagingSenderId: "974446565997",
  appId: "1:974446565997:web:ad54362ab3378f9eaabd64"
};

// Verifica se as credenciais foram preenchidas
const hasPlaceholders = Object.values(firebaseConfig).some(v =>
  typeof v === 'string' && v.startsWith('YOUR_')
);

if (hasPlaceholders) {
  console.error(
    '[Firebase] ❌ firebase-config.js ainda tem placeholders!' +
    '\nVai a: Firebase Console → Project Settings → Your apps → Config' +
    '\ne substitui os valores em js/firebase-config.js'
  );
  // Mostra aviso visual na página
  document.addEventListener('DOMContentLoaded', () => {
    const skel = document.getElementById('skeletonLayout');
    if (skel) skel.style.display = 'none';
    const main = document.getElementById('mainContent');
    if (main) {
      main.style.cssText = 'display:flex;align-items:center;justify-content:center;min-height:60vh;';
      main.innerHTML = `
        <div style="text-align:center;padding:40px 24px;max-width:500px;">
          <div style="font-size:3rem;margin-bottom:12px;">🔑</div>
          <h2 style="font-family:'Rajdhani',sans-serif;color:#e2e8f0;margin-bottom:8px;">
            Firebase não configurado
          </h2>
          <p style="color:#94a3b8;font-size:0.85rem;line-height:1.6;margin-bottom:16px;">
            O ficheiro <code style="background:#1e293b;padding:2px 6px;border-radius:4px;">
            js/firebase-config.js</code> ainda tem valores de exemplo.<br>
            Substitui pelos valores reais do teu projecto Firebase.
          </p>
          <div style="padding:12px 16px;background:rgba(249,115,22,0.1);border:1px solid rgba(249,115,22,0.3);
            border-radius:8px;font-size:0.8rem;color:#f97316;text-align:left;margin-bottom:20px;">
            <strong>Como corrigir:</strong><br>
            1. Firebase Console → ⚙️ Project Settings<br>
            2. Your apps → &lt;/&gt; Web app<br>
            3. Copia o <code>firebaseConfig</code> e cola em <code>js/firebase-config.js</code><br>
            4. Faz deploy novamente: <code>firebase deploy</code>
          </div>
          <a href="https://console.firebase.google.com" target="_blank"
            style="padding:10px 20px;background:#f97316;color:#000;
            border-radius:8px;text-decoration:none;font-weight:700;">
            Abrir Firebase Console
          </a>
        </div>`;
    }
  });
} else if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

// Instâncias globais (acessíveis em todos os módulos)
const db      = firebase.firestore();
const auth    = firebase.auth();
const storage = firebase.storage();

// Ativa persistência offline (útil em mobile)
db.enablePersistence({ synchronizeTabs: true }).catch(err => {
  if (err.code === 'failed-precondition') {
    console.warn('[Firebase] Persistência desativada: múltiplas abas abertas.');
  } else if (err.code === 'unimplemented') {
    console.warn('[Firebase] Persistência não suportada neste browser.');
  }
});
