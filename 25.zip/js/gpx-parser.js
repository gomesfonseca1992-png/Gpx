/**
 * gpx-parser.js v3 — GPX + FIT
 * Fix: namespaces Garmin (localName), suporte .fit binary
 */

const GPXParser = (() => {

  // ─── Haversine ────────────────────────────────────────────────────────
  function haversineDistance(lat1,lon1,lat2,lon2){
    const R=6371000,tr=d=>d*Math.PI/180;
    const dLat=tr(lat2-lat1),dLon=tr(lon2-lon1);
    const a=Math.sin(dLat/2)**2+Math.cos(tr(lat1))*Math.cos(tr(lat2))*Math.sin(dLon/2)**2;
    return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
  }

  // ─── Detecta desporto ─────────────────────────────────────────────────
  function detectSport(xmlDoc){
    const t=(xmlDoc.querySelector('trk > type')?.textContent||'').toLowerCase();
    if(t.includes('cycl')||t.includes('bik')||t==='1'||t==='2') return 'cycling';
    if(t.includes('run')||t==='9')  return 'running';
    if(t.includes('hik')||t==='17') return 'hiking';
    if(t.includes('walk')||t==='11')return 'walking';
    return 'unknown';
  }

  // ─── Extensões GPX — usa localName para ignorar namespaces ───────────
  function _parseExtensions(trkpt){
    const ext=trkpt.querySelector('extensions');
    if(!ext) return {hr:null,cadence:null,power:null,temp:null};
    function getByLocal(parent,...names){
      const all=parent.getElementsByTagName('*');
      for(let i=0;i<all.length;i++){
        const local=all[i].localName||all[i].tagName;
        if(names.includes(local)){
          const v=parseFloat(all[i].textContent);
          if(!isNaN(v)&&v>0) return Math.round(v);
        }
      }
      return null;
    }
    return {
      hr:      getByLocal(ext,'hr','HeartRateBpm','heartrate','heart_rate'),
      cadence: getByLocal(ext,'cad','cadence','Cadence','RunCadence','cycling_cadence'),
      power:   getByLocal(ext,'power','Power','Watts','watts','pwr'),
      temp:    getByLocal(ext,'atemp','temp','temperature','AirTemp'),
    };
  }

  // ─── Converte pontos crus em trackPoints com distância e velocidade ───
  function _buildTrackPoints(rawPoints){
    let cumDist=0;
    return rawPoints.map((p,i)=>{
      let distFromPrev=0,speed=null;
      if(i>0){
        const prev=rawPoints[i-1];
        let d=haversineDistance(prev.lat,prev.lon,p.lat,p.lon);
        // Clamp outliers: descarta saltos GPS impossíveis (>120km/h equiv.)
        if(p.time&&prev.time){
          const dt=(p.time-prev.time)/1000;
          if(dt>0 && d/dt > 33.3){ // 33.3 m/s ≈ 120 km/h
            d = 0; // ignora salto de GPS no cômputo da distância
          }
        } else if(d > 200){
          // sem timestamps válidos: salto >200m entre pontos consecutivos é suspeito
          d = 0;
        }
        distFromPrev=d;
        cumDist+=distFromPrev;
        if(p.time&&prev.time){
          const dt=(p.time-prev.time)/1000;
          if(dt>0&&dt<600){
            speed=Math.min((distFromPrev/dt)*3.6,90);
            speed=Math.round(speed*10)/10;
          }
        }
      }
      return {
        lat:p.lat, lon:p.lon, ele:p.ele??null,
        time:p.time?p.time.toISOString():null,
        distFromStart:Math.round(cumDist),
        distFromPrev:Math.round(distFromPrev),
        speed,
        hr:p.hr??null, cadence:p.cadence??null,
        power:p.power??null, temp:p.temp??null,
      };
    });
  }

  // ════════════════════════════════════════════════════════
  //  GPX PARSER
  // ════════════════════════════════════════════════════════
  function parse(gpxText){
    const parser=new DOMParser();
    const xmlDoc=parser.parseFromString(gpxText,'application/xml');
    const errEl=xmlDoc.querySelector('parsererror');
    if(errEl) throw new Error('GPX inválido: '+errEl.textContent.slice(0,120));

    const nameEl=xmlDoc.querySelector('trk > name')||xmlDoc.querySelector('metadata > name');
    const timeEl=xmlDoc.querySelector('metadata > time');
    const sport=detectSport(xmlDoc);
    const trkpts=xmlDoc.querySelectorAll('trkpt');
    if(trkpts.length===0) throw new Error('Nenhum trackpoint encontrado no GPX.');

    const rawPoints=[];
    trkpts.forEach(pt=>{
      const lat=parseFloat(pt.getAttribute('lat'));
      const lon=parseFloat(pt.getAttribute('lon'));
      if(isNaN(lat)||isNaN(lon)) return;
      const eleEl=pt.querySelector('ele');
      const tEl=pt.querySelector('time');
      const ext=_parseExtensions(pt);
      rawPoints.push({lat,lon,ele:eleEl?parseFloat(eleEl.textContent):null,time:tEl?new Date(tEl.textContent):null,...ext});
    });

    if(rawPoints.length===0) throw new Error('Coordenadas inválidas no GPX.');

    const trackPoints=_buildTrackPoints(rawPoints);
    const waypoints=[...xmlDoc.querySelectorAll('wpt')].map(w=>({
      lat:parseFloat(w.getAttribute('lat')),lon:parseFloat(w.getAttribute('lon')),
      name:w.querySelector('name')?.textContent||'',
    }));

    const hasHR     =trackPoints.some(p=>p.hr!==null);
    const hasCadence=trackPoints.some(p=>p.cadence!==null);
    const hasPower  =trackPoints.some(p=>p.power!==null);

    return {
      metadata:{name:nameEl?.textContent||'Atividade sem nome',
        time:timeEl?.textContent||rawPoints[0]?.time?.toISOString()||null,
        sport,hasHR,hasCadence,hasPower,sourceFormat:'gpx'},
      trackPoints, waypoints, _raw:{pointCount:trackPoints.length},
    };
  }

  // ════════════════════════════════════════════════════════
  //  FIT BINARY PARSER
  // ════════════════════════════════════════════════════════
  function parseFit(buffer){
    const data=new Uint8Array(buffer);
    const view=new DataView(buffer);

    // Validação
    if(data.length<12){
      throw new Error(`Ficheiro FIT corrompido ou incompleto (${data.length} bytes). Exporta novamente do dispositivo.`);
    }

    // Magic bytes
    const magic=String.fromCharCode(data[8],data[9],data[10],data[11]);
    const magic2=data.length>4?String.fromCharCode(data[1],data[2],data[3],data[4]):'';
    if(magic!=='.FIT'&&magic2!=='.FIT'){
      const xmlStart=String.fromCharCode(...data.slice(0,Math.min(10,data.length)));
      if(xmlStart.includes('<')||xmlStart.toLowerCase().includes('<?xml')){
        throw new Error('Este ficheiro é um GPX renomeado para .fit. Muda a extensão para .gpx.');
      }
      throw new Error(`Ficheiro FIT inválido (header: "${magic}"). Exporta o ficheiro directamente do dispositivo.`);
    }

    const headerSize=data[0]||14;
    const FIT_EPOCH=Date.UTC(1989,11,31,0,0,0);
    function fitTimestamp(ts){ return new Date(FIT_EPOCH+ts*1000); }
    function semicToDeg(sc){ return sc*(180/Math.pow(2,31)); }

    const definitions={};
    const records=[];
    // Valores oficiais do dispositivo (Session message gMsg=132)
    const fitSession={totalAscent:null,totalDescent:null};
    let sport='unknown';
    let activityName='';

    let pos=headerSize;
    const dataEnd=Math.min(headerSize+view.getUint32(4,true), data.length);

    while(pos<dataEnd&&pos<data.length){
      if(pos<0||pos>=data.length) break;
      const rh=data[pos]; pos++;

      // ── Compressed timestamp record (bit 7 set) ───────────────────────
      if(rh&0x80){
        // Bits [6:5] = local message number (2 bits → 0-3)
        const cLocalNum=(rh>>5)&0x03;
        const cDef=definitions[cLocalNum];
        if(cDef){
          let sz=0; cDef.fields.forEach(f=>{sz+=f.size;});
          if(pos+sz<=data.length) pos+=sz; else break;
        }
        // Se não há def, apenas continua (1 byte já consumido)
        continue;
      }

      const isDef=(rh&0x40)!==0;
      const localNum=rh&0x0F;

      if(isDef){
        // Definition message
        if(pos+4>=data.length) break;
        pos++; // reserved byte
        const arch=data[pos++];
        const LE=(arch===0);
        const gMsg=LE?view.getUint16(pos,true):view.getUint16(pos,false);
        pos+=2;
        const nFields=data[pos++];
        if(nFields>128||pos+nFields*3>data.length){ break; } // sanity
        const fields=[];
        for(let f=0;f<nFields;f++){
          if(pos+3>data.length) break;
          fields.push({defNum:data[pos],size:data[pos+1],baseType:data[pos+2]});
          pos+=3;
        }
        // Developer fields (bit 5 set in header)
        if(rh&0x20){
          if(pos>=data.length) break;
          const dv=data[pos++];
          if(pos+dv*3>data.length) break;
          pos+=dv*3;
        }
        definitions[localNum]={arch,gMsg,fields,LE};
      } else {
        // Data message
        const def=definitions[localNum];
        if(!def){
          // Sem definição: avançar 1 byte para tentar recuperar alinhamento
          // NÃO fazer continue sem avançar (causa loop infinito)
          pos++;
          continue;
        }
        // Calcular tamanho total desta mensagem para bounds check
        let msgSize=0; def.fields.forEach(f=>{msgSize+=f.size;});
        if(pos+msgSize>data.length){ break; } // mensagem truncada
        const {gMsg,fields,LE}=def;

        if(gMsg===20){ // Record
          const rec={};
          fields.forEach(f=>{
            let val=null;
            try{
              const bt=f.baseType&0x7F;
              // lat(0) e lon(1) são SEMPRE sint32 no protocolo FIT
              // Lemos como sint32 independentemente do baseType declarado
              if(f.defNum===0||f.defNum===1){
                // Coordenadas: sempre sint32
                val=f.size===4?(LE?view.getInt32(pos,true):view.getInt32(pos,false)):null;
              } else if(f.size===4&&(bt===0x86||bt===0x06)){
                val=LE?view.getUint32(pos,true):view.getUint32(pos,false);
              } else if(f.size===4&&(bt===0x85||bt===0x05)){
                val=LE?view.getInt32(pos,true):view.getInt32(pos,false);
              } else if(f.size===4){
                // fallback 4 bytes: tenta sint32 (mais comum no FIT)
                val=LE?view.getInt32(pos,true):view.getInt32(pos,false);
              } else if(f.size===2&&(bt===0x84||bt===0x04)){
                val=LE?view.getUint16(pos,true):view.getUint16(pos,false);
              } else if(f.size===2&&(bt===0x83||bt===0x03)){
                val=LE?view.getInt16(pos,true):view.getInt16(pos,false);
              } else if(f.size===2){
                val=LE?view.getUint16(pos,true):view.getUint16(pos,false);
              } else if(f.size===1){
                // uint8 por defeito; apenas temperatura (defNum=13) é sint8
                val=data[pos];
                if(f.defNum===13&&val>127) val=val-256;
              }
            }catch(e){}
            pos+=f.size;
            switch(f.defNum){
              case 253:rec.timestamp=val;break;
              case 0:  rec.lat_sc=val;break;
              case 1:  rec.lon_sc=val;break;
              case 2:  rec.alt_mm=val;break;
              case 3:  rec.heart_rate=val;break;
              case 4:  rec.cadence=val;break;
              case 7:  rec.power=val;break;
              case 6:  rec.speed_mm=val;break;
              case 13: rec.temp=val;break;
              case 52: rec.cad_frac=val;break;
            }
          });

          // Sentinel FIT: 0x7FFFFFFF = valor inválido para sint32
          const INVALID_SC=0x7FFFFFFF;
          if(rec.lat_sc!=null&&rec.lon_sc!=null&&
             rec.lat_sc!==INVALID_SC&&rec.lon_sc!==INVALID_SC&&
             rec.lat_sc!==-INVALID_SC&&rec.lon_sc!==-INVALID_SC){
            const lat=semicToDeg(rec.lat_sc);
            const lon=semicToDeg(rec.lon_sc);
            // Aceitar qualquer coordenada geograficamente válida
            if(lat>=-90&&lat<=90&&lon>=-180&&lon<=180){
              // FIT altitude: uint16, escala 5mm/LSB, offset -500m
              // Valor inválido: 0xFFFF (65535) para uint16
              const ele=rec.alt_mm!=null&&rec.alt_mm!==65535&&rec.alt_mm!==0x7FFFFFFF
                        ?(rec.alt_mm/5-500):null;
              const time=rec.timestamp?fitTimestamp(rec.timestamp):null;
              const hr=(rec.heart_rate>0&&rec.heart_rate<250&&rec.heart_rate!==0xFF)?rec.heart_rate:null;
              let cad=(rec.cadence!=null&&rec.cadence!==0xFF&&rec.cadence!==255)?rec.cadence:null;
              if(cad!=null&&rec.cad_frac!=null&&rec.cad_frac!==0xFF) cad=Math.round(cad+rec.cad_frac/128);
              if(cad!=null&&cad>200) cad=null; // sanity check
              const pwr=(rec.power>0&&rec.power<5000)?rec.power:null;
              const temp=(rec.temp!=null&&rec.temp>-50&&rec.temp<100)?rec.temp:null;
              records.push({lat,lon,ele,time,hr,cadence:cad,power:pwr,temp});
            }
          }
        } else {
          // Mensagem não-record — lê campos relevantes antes de avançar
          if(gMsg===12){ // Sport (gMsg=12 no protocolo FIT)
            const sportMap={0:'generic',1:'running',2:'cycling',5:'swimming',11:'walking',17:'hiking',255:'all'};
            const sportFields={};
            fields.forEach(f=>{
              let val=null;
              try{
                if(f.size===1) val=data[pos];
                else if(f.size===2) val=LE?view.getUint16(pos,true):view.getUint16(pos,false);
                // defNum=3 pode ser "name" no sport message (string)
                else if(f.defNum===3&&f.size>1&&f.size<=32){
                  let sn='';
                  for(let ci=0;ci<f.size;ci++){const c=data[pos+ci];if(c===0)break;if(c>=32&&c<=126)sn+=String.fromCharCode(c);}
                  if(sn.trim().length>1&&!activityName) activityName=sn.trim();
                }
              }catch(e){}
              if(f.defNum===0) sportFields.sport=val;
              if(f.defNum===1) sportFields.subSport=val;
              pos+=f.size;
            });
            const sName=sportMap[sportFields.sport]||null;
            if(sName&&sName!=='generic') sport=sName==='running'?'running':sName==='cycling'?'cycling':sName==='hiking'?'hiking':sName==='walking'?'walking':sport;
          } else if(gMsg===6){ // Lap — nome da sessão
            const lapFields={};
            fields.forEach(f=>{
              if(f.defNum===29&&f.size<=32){ // sport (no lap)
                try{
                  let chars='';
                  for(let ci=0;ci<f.size;ci++){ const c=data[pos+ci]; if(c===0)break; chars+=String.fromCharCode(c); }
                  if(chars) lapFields.name=chars;
                }catch(e){}
              }
              pos+=f.size;
            });
          } else if(gMsg===18||gMsg===132){ // Session — total_ascent(defNum=22) total_descent(defNum=23)
            fields.forEach(f=>{
              try{
                let val=null;
                if(f.size===2) val=LE?view.getUint16(pos,true):view.getUint16(pos,false);
                else if(f.size===4) val=LE?view.getUint32(pos,true):view.getUint32(pos,false);
                // defNum 22 = total_ascent (uint16, unidade: metros)
                // defNum 23 = total_descent (uint16, unidade: metros)
                if(f.defNum===22&&val!=null&&val!==0xFFFF&&val>0) fitSession.totalAscent=val;
                if(f.defNum===23&&val!=null&&val!==0xFFFF&&val>0) fitSession.totalDescent=val;
              }catch(e){}
              pos+=f.size;
            });
          } else if(gMsg===49||gMsg===26||gMsg===158||gMsg===233){ // Workout / nome da sessão
            fields.forEach(f=>{
              // defNum 8 = wkt_name (Workout), 254=timestamp — string fields têm size>4
              if(f.size>4&&f.size<=64&&(f.defNum===8||f.defNum===11||f.defNum===254)){
                try{
                  let name='';
                  for(let ci=0;ci<f.size;ci++){
                    const c=data[pos+ci];
                    if(c===0)break;
                    // Só aceitar ASCII imprimível (32-126)
                    if(c>=32&&c<=126) name+=String.fromCharCode(c);
                  }
                  if(name.trim().length>1) activityName=name.trim();
                }catch(e){}
              }
              pos+=f.size;
            });
          } else {
            fields.forEach(f=>{pos+=f.size;});
          }
        }
      }
    }

    if(records.length===0) throw new Error('Nenhum dado GPS encontrado no FIT. Verifica se o ficheiro tem actividade gravada.');

    const trackPoints=_buildTrackPoints(records);
    const hasHR     =trackPoints.some(p=>p.hr!==null);
    const hasCadence=trackPoints.some(p=>p.cadence!==null);
    const hasPower  =trackPoints.some(p=>p.power!==null);

    // Refina sport por velocidade
    if(sport==='unknown'&&trackPoints.length>0){
      const speeds=trackPoints.map(p=>p.speed).filter(Boolean);
      const avg=speeds.length?speeds.reduce((a,b)=>a+b)/speeds.length:0;
      if(avg>15) sport='cycling';
      else if(avg>7) sport='running';
      else sport='hiking';
    }

    // Limpar nome: remover caracteres não-ASCII e usar fallback se vazio/inválido
    const cleanName = (activityName||'')
      .replace(/[^ -~À-ɏ]/g, '') // só ASCII + Latin Extended
      .trim();

    return {
      metadata:{name:cleanName||'Atividade FIT',
        time:records[0]?.time?.toISOString()||null,
        sport,hasHR,hasCadence,hasPower,sourceFormat:'fit',
        fitTotalAscent:fitSession.totalAscent,
        fitTotalDescent:fitSession.totalDescent},
      trackPoints, waypoints:[], _raw:{pointCount:trackPoints.length},
    };
  }

  // ════════════════════════════════════════════════════════
  //  parseFile — aceita .gpx e .fit
  // ════════════════════════════════════════════════════════
  async function parseFile(file){
    const name=file.name.toLowerCase();
    if(name.endsWith('.gpx')){
      return new Promise((resolve,reject)=>{
        const reader=new FileReader();
        reader.onload=e=>{try{resolve(parse(e.target.result));}catch(err){reject(err);}};
        reader.onerror=()=>reject(new Error('Erro ao ler o ficheiro GPX.'));
        reader.readAsText(file);
      });
    } else if(name.endsWith('.fit')){
      return new Promise((resolve,reject)=>{
        const reader=new FileReader();
        reader.onload=e=>{try{resolve(parseFit(e.target.result));}catch(err){reject(err);}};
        reader.onerror=()=>reject(new Error('Erro ao ler o ficheiro FIT.'));
        reader.readAsArrayBuffer(file);
      });
    } else {
      throw new Error('Formato não suportado. Usa ficheiros .gpx ou .fit');
    }
  }

  return {parse,parseFit,parseFile,haversineDistance};
})();

if(typeof module!=='undefined') module.exports=GPXParser;
