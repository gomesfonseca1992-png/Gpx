/* =====================================================================
   GPX Analyzer — Registo do Service Worker + Prompt de Instalação PWA
   ===================================================================== */

(function () {
  'use strict';

  // ── Regista o Service Worker ─────────────────────────────────────────────
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js', { scope: '/' })
        .then(reg => {
          console.log('[PWA] Service Worker registado:', reg.scope);

          // Verifica atualização em segundo plano
          reg.addEventListener('updatefound', () => {
            const newWorker = reg.installing;
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                // Há atualização disponível — notifica o utilizador
                showUpdateBanner();
              }
            });
          });
        })
        .catch(err => console.warn('[PWA] SW erro:', err));
    });
  }

  // ── Banner de atualização disponível ─────────────────────────────────────
  function showUpdateBanner() {
    const banner = document.createElement('div');
    banner.id = 'pwa-update-banner';
    banner.innerHTML = `
      <span>🔄 Nova versão disponível!</span>
      <button id="pwa-update-btn" style="
        background:#f97316;color:#fff;border:none;
        padding:4px 14px;border-radius:8px;cursor:pointer;font-size:0.8rem;font-weight:600;">
        Atualizar
      </button>
      <button id="pwa-dismiss-btn" style="
        background:transparent;color:#94a3b8;border:none;
        padding:4px 8px;cursor:pointer;font-size:1rem;">
        ✕
      </button>`;
    banner.style.cssText = `
      position:fixed;bottom:1rem;left:50%;transform:translateX(-50%);
      background:#1e2430;border:1px solid #334155;border-radius:12px;
      padding:10px 16px;display:flex;align-items:center;gap:12px;
      font-size:0.875rem;color:#e2e8f0;z-index:9999;
      box-shadow:0 4px 24px rgba(0,0,0,0.4);
      animation:slideUp 0.3s ease;`;

    document.body.appendChild(banner);

    document.getElementById('pwa-update-btn').addEventListener('click', () => {
      window.location.reload();
    });
    document.getElementById('pwa-dismiss-btn').addEventListener('click', () => {
      banner.remove();
    });
  }

  // ── Prompt de instalação (botão "Adicionar ao ecrã inicial") ─────────────
  let deferredPrompt = null;

  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    showInstallButton();
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    hideInstallButton();
    console.log('[PWA] App instalada com sucesso!');
  });

  function showInstallButton() {
    // Só mostra se não está já em modo standalone
    if (window.matchMedia('(display-mode: standalone)').matches) return;
    if (document.getElementById('pwa-install-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'pwa-install-btn';
    btn.innerHTML = '📲 Instalar App';
    btn.style.cssText = `
      position:fixed;bottom:1rem;right:1rem;
      background:#f97316;color:#fff;border:none;
      padding:10px 18px;border-radius:12px;
      font-size:0.85rem;font-weight:600;cursor:pointer;
      box-shadow:0 4px 20px rgba(249,115,22,0.4);
      z-index:9998;animation:fadeIn 0.4s ease;
      display:flex;align-items:center;gap:8px;`;

    btn.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      deferredPrompt = null;
      if (outcome === 'accepted') btn.remove();
    });

    document.body.appendChild(btn);

    // Remove após 15 s se o utilizador não interagir
    setTimeout(() => btn.remove(), 15000);
  }

  function hideInstallButton() {
    const btn = document.getElementById('pwa-install-btn');
    if (btn) btn.remove();
  }

  // ── Animações do banner ───────────────────────────────────────────────────
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideUp  { from { opacity:0; transform:translateX(-50%) translateY(20px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }
    @keyframes fadeIn   { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
  `;
  document.head.appendChild(style);
})();
