/**
 * map.js v12
 * - Leaflet para o mapa principal (tab Visão Geral)
 * - MapLibre GL para o flyover 3D estilo Strava (pitch + bearing real)
 * - Canvas overlay para HUD e rota durante o flyover
 * - Sem conta, sem token pago
 */
const GPXMap = (() => {

  // ─── Mapa Leaflet ──────────────────────────────────────────────────
  let map=null, tileLayer=null, routeLayer=null, markerPos=null;
  let _trackPoints=null, _colorMode='speed', _currentTile='satellite';

  const TILES = {
    satellite:{ url:'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', sub:null, maxZoom:18 },
    dark:     { url:'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', sub:'abcd', maxZoom:19 },
    outdoor:  { url:'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', sub:'abc', maxZoom:17 },
    osm:      { url:'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', sub:'abc', maxZoom:19 },
  };

  // Cores
  const lp=(a,b,t)=>Math.round(a+(b-a)*t);
  const lc=(c1,c2,t)=>`rgb(${lp(c1[0],c2[0],t)},${lp(c1[1],c2[1],t)},${lp(c1[2],c2[2],t)})`;
  const SP=[[56,189,248],[34,197,94],[249,115,22],[239,68,68]];
  const EP=[[34,197,94],[245,158,11],[239,68,68]];
  const fp=(p,t)=>{t=Math.max(0,Math.min(1,t));const n=p.length-1,i=Math.floor(t*n),j=Math.min(i+1,n);return lc(p[i],p[j],(t*n)-i);};
  const sc=(v,mn,mx)=>(!v||mx===mn)?'#f97316':fp(SP,(v-mn)/(mx-mn));
  const ec=(v,mn,mx)=>(!v||mx===mn)?'#22c55e':fp(EP,(v-mn)/(mx-mn));

  function _applyTile(k){
    if(!map) return;
    const t=TILES[k]||TILES.satellite;
    try { if(tileLayer){map.removeLayer(tileLayer);tileLayer=null;} } catch(e){}
    const o={maxZoom:t.maxZoom,crossOrigin:true};if(t.sub)o.subdomains=t.sub;
    try {
      tileLayer=L.tileLayer(t.url,o).addTo(map);
      tileLayer.on('tileerror', ()=>{
        // Se tile falha, tenta dark como fallback
        if(k!=='dark'&&k!=='osm'){
          console.warn('Tile error, fallback to dark');
          _applyTile('dark');
        }
      });
    } catch(e){ console.warn('tile error:', e); }
    try { if(routeLayer)routeLayer.bringToFront(); } catch(e){}
  }

  function init(id){
    if(map){try{map.remove();}catch(e){}map=null;tileLayer=null;routeLayer=null;markerPos=null;}
    try {
      map=L.map(id,{zoomControl:true,attributionControl:true,preferCanvas:true});
      // Coordenadas padrão (Lisboa) para evitar tela preta antes de drawRoute
      map.setView([38.7,-9.1],10);
      _applyTile(_currentTile);
    } catch(e) { console.warn('Leaflet init:', e); }
    return map;
  }

  function setTileStyle(k){_currentTile=k;if(map)_applyTile(k);}

  function drawRoute(pts,mode='speed'){
    if(!map)return;
    if(routeLayer){map.removeLayer(routeLayer);routeLayer=null;}
    _trackPoints=pts;_colorMode=mode;
    if(!pts||pts.length<2)return;
    const spds=pts.map(p=>p.speed).filter(s=>s!=null);
    const eles=pts.map(p=>p.ele).filter(e=>e!=null);
    const mn=spds.length?Math.min(...spds):0,mx=spds.length?Math.max(...spds):1;
    const me=eles.length?Math.min(...eles):0,xe=eles.length?Math.max(...eles):1;
    const g=L.layerGroup();
    L.polyline(pts.map(p=>[p.lat,p.lon]),{color:'rgba(0,0,0,0.4)',weight:7,lineCap:'round',lineJoin:'round'}).addTo(g);
    for(let i=0;i<pts.length-1;i++){
      const p1=pts[i],p2=pts[i+1];
      let c='#f97316';
      if(mode==='speed'&&p1.speed!=null)c=sc(p1.speed,mn,mx);
      else if(mode==='elevation'&&p1.ele!=null)c=ec(p1.ele,me,xe);
      L.polyline([[p1.lat,p1.lon],[p2.lat,p2.lon]],{color:c,weight:4,lineCap:'round',lineJoin:'round'})
       .bindTooltip(`<b style="color:#f97316">${(p1.distFromStart/1000).toFixed(2)}km</b><br>⚡${p1.speed!=null?p1.speed.toFixed(1)+' km/h':'--'}`,{sticky:true,className:'gpx-tooltip'})
       .addTo(g);
    }
    routeLayer=g;g.addTo(map);
    const mk=bg=>L.divIcon({html:`<div style="width:20px;height:20px;border-radius:50%;background:${bg};border:3px solid #fff;box-shadow:0 0 8px ${bg}"></div>`,className:'',iconSize:[20,20],iconAnchor:[10,10]});
    L.marker([pts[0].lat,pts[0].lon],{icon:mk('#22c55e')}).bindTooltip('Início').addTo(g);
    L.marker([pts[pts.length-1].lat,pts[pts.length-1].lon],{icon:mk('#ef4444')}).bindTooltip('Fim').addTo(g);
    try {
      const bounds = L.latLngBounds(pts.map(p=>[p.lat,p.lon]));
      // Invalidar tamanho PRIMEIRO, depois ajustar bounds
      map.invalidateSize({animate:false});
      map.fitBounds(bounds,{padding:[30,30],maxZoom:16});
      // Segundo fitBounds após render para garantir que os tiles carregaram
      setTimeout(()=>{
        try{
          map.invalidateSize({animate:false});
          map.fitBounds(bounds,{padding:[30,30],maxZoom:16});
        }catch(e){}
      }, 250);
    } catch(e){ console.warn('fitBounds:', e); }
  }

  // Marcador pulsante
  const posIcon=L.divIcon({
    html:`<div style="position:relative;width:24px;height:24px;"><div style="position:absolute;inset:0;border-radius:50%;background:rgba(249,115,22,0.3);animation:gpxPulse 1.5s ease-in-out infinite;"></div><div style="position:absolute;top:5px;left:5px;width:14px;height:14px;border-radius:50%;background:#f97316;border:2.5px solid #fff;"></div></div>`,
    className:'',iconSize:[24,24],iconAnchor:[12,12],
  });
  if(!document.getElementById('_gpxPulseStyle')){
    const s=document.createElement('style');s.id='_gpxPulseStyle';
    s.textContent='@keyframes gpxPulse{0%,100%{transform:scale(1);opacity:0.6}50%{transform:scale(1.8);opacity:0}}';
    document.head.appendChild(s);
  }
  function updatePositionMarker(lat,lon){if(!map)return;if(!markerPos)markerPos=L.marker([lat,lon],{icon:posIcon,zIndexOffset:1000}).addTo(map);else markerPos.setLatLng([lat,lon]);}
  function removePositionMarker(){if(markerPos&&map){map.removeLayer(markerPos);markerPos=null;}}
  function setColorMode(pts,m){drawRoute(pts,m);}
  function invalidate(){
    if(!map) return;
    try { map.invalidateSize({animate:false}); } catch(e){}
    setTimeout(()=>{ try{map.invalidateSize({animate:false});}catch(e){} }, 200);
  }
  function fitRoute(pts){if(map&&pts)map.fitBounds(L.latLngBounds(pts.map(p=>[p.lat,p.lon])),{padding:[40,40]});}

  // ─── Bearing ──────────────────────────────────────────────────────
  function _bearing(la1,lo1,la2,lo2){
    const r=Math.PI/180,dL=(lo2-lo1)*r;
    const y=Math.sin(dL)*Math.cos(la2*r);
    const x=Math.cos(la1*r)*Math.sin(la2*r)-Math.sin(la1*r)*Math.cos(la2*r)*Math.cos(dL);
    return(Math.atan2(y,x)*180/Math.PI+360)%360;
  }

  // ═══════════════════════════════════════════════════════════════════
  //  FLYOVER 3D — MapLibre GL + fullscreen overlay estilo Strava
  //  Grava mapa + HUD juntos via canvas composto (MediaRecorder)
  // ═══════════════════════════════════════════════════════════════════
  let _flyActive=false,_flyPaused=false,_flyRAF=null,_flyRec=null,_flyChunks=[];
  let _flyMap=null,_flyOverlay=null,_flyFrame=0,_flyTotalF=0,_flySpeed=1;
  let _flyOutroStart=-1; // frame em que começa o encerramento
  let _flySlowingDown=false,_flySpeedBeforeOutro=1; // slowdown antes do outro
  let _flyCompCanvas=null,_flyCompCtx=null; // canvas composto para gravar

  const ML_STYLES = {
    satellite:{version:8,sources:{s:{type:'raster',tiles:[
      // ESRI World Imagery — funciona bem no desktop e mobile
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
    ],tileSize:256,attribution:'ESRI'}},layers:[{id:'bg',type:'raster',source:'s'}]},
    dark:{version:8,sources:{s:{type:'raster',tiles:[
      'https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',
      'https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',
    ],tileSize:256}},layers:[{id:'bg',type:'raster',source:'s'}]},
    outdoor:{version:8,sources:{s:{type:'raster',tiles:[
      'https://tile.opentopomap.org/{z}/{x}/{y}.png'
    ],tileSize:256}},layers:[{id:'bg',type:'raster',source:'s'}]},
  };

  function _createFlyMap(containerId,style){
    if(typeof maplibregl==='undefined'){
      console.warn('[Flyover] MapLibre GL não carregado');
      return null;
    }
    try{
      const m = new maplibregl.Map({
        container:containerId,
        style: ML_STYLES[style]||ML_STYLES.satellite,
        center:[0,0], zoom:14, pitch:65, bearing:0,
        antialias:true, attributionControl:false,
        fadeDuration:0,
        preserveDrawingBuffer:true,
      });
      return m;
    }catch(e){ console.warn('[Flyover] MapLibre init failed:',e); return null; }
  }

  // ── UI overlay fullscreen ────────────────────────────────────────────
  function _buildFlyoverUI(activity){
    const ov=document.createElement('div');
    ov.id='_flyOverlay';
    ov.style.cssText=`
      position:fixed;inset:0;z-index:99999;background:#000;
      display:flex;flex-direction:column;font-family:'Rajdhani',Inter,Arial,sans-serif;
    `;
    ov.innerHTML=`
      <!-- Mapa MapLibre fullscreen -->
      <div id="_flyMapDiv" style="position:absolute;inset:0;" onclick="_flyTapScreen()"></div>

      <!-- Canvas HUD sobreposto -->
      <canvas id="_flyHudCanvas" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none;"></canvas>

      <!-- Controles bottom bar com auto-hide -->
      <div id="_flyControls" style="
        position:absolute;bottom:0;left:0;right:0;z-index:10;
        background:rgba(0,0,0,0.75);backdrop-filter:blur(12px);
        padding:14px 20px 24px;display:flex;flex-direction:column;gap:10px;
        transition:opacity 0.35s,transform 0.35s;
      ">
        <!-- Barra de progresso clicável -->
        <div id="_flyProgBar"
          onclick="_flySeek(event)"
          ontouchstart="event.preventDefault();_flySeek(event)"
          ontouchmove="event.preventDefault();_flySeek(event)"
          style="width:100%;height:28px;background:transparent;border-radius:4px;cursor:pointer;position:relative;display:flex;align-items:center;touch-action:none;">
          <!-- Track de fundo -->
          <div style="position:absolute;left:0;right:0;top:50%;height:4px;transform:translateY(-50%);background:rgba(255,255,255,0.15);border-radius:4px;"></div>
          <!-- Fill laranja -->
          <div id="_flyProgFill" style="position:absolute;left:0;top:50%;height:4px;transform:translateY(-50%);border-radius:4px;background:linear-gradient(90deg,#f97316,#fb923c);width:0%;pointer-events:none;"></div>
          <!-- Thumb -->
          <div id="_flyProgDot" style="position:absolute;top:50%;width:16px;height:16px;border-radius:50%;background:#fff;transform:translate(-50%,-50%);left:0%;box-shadow:0 0 8px rgba(249,115,22,.8);pointer-events:none;border:2px solid #f97316;"></div>
        </div>
        <!-- Linha 1: sliders VEL + ZOOM -->
        <div style="display:flex;align-items:center;gap:10px;">
          <!-- Play/Pause -->
          <button id="_flyPauseBtn" onclick="_flyTogglePause()" style="
            width:38px;height:38px;border-radius:50%;border:none;cursor:pointer;
            background:rgba(255,255,255,0.15);color:#fff;font-size:1.1rem;
            display:flex;align-items:center;justify-content:center;flex-shrink:0;
          ">⏸</button>
          <!-- VEL label + slider -->
          <span style="color:rgba(255,255,255,0.38);font-size:0.68rem;flex-shrink:0;letter-spacing:.04em;">VEL</span>
          <input id="_flySpeedSlider" type="range" min="1" max="11" value="4" step="1"
            oninput="_flyChangeSpeed(this.value)"
            style="flex:1;accent-color:#f97316;height:4px;min-width:0;">
          <span id="_flySpeedLbl" style="color:#f97316;font-weight:700;font-size:0.82rem;min-width:30px;text-align:right;flex-shrink:0;">0.25×</span>
          <!-- ZOOM label + slider -->
          <span style="color:rgba(255,255,255,0.38);font-size:0.68rem;flex-shrink:0;letter-spacing:.04em;">ZOOM</span>
          <input id="_flyZoomSlider" type="range" min="11" max="18" value="14" step="0.5"
            oninput="_flyChangeZoom(this.value)"
            style="flex:1;accent-color:#38bdf8;height:4px;min-width:0;">
          <span id="_flyZoomLbl" style="color:#38bdf8;font-weight:700;font-size:0.82rem;min-width:22px;text-align:right;flex-shrink:0;">14</span>
        </div>
        <!-- Linha 2: botões de ação -->
        <div style="display:flex;align-items:center;justify-content:flex-end;gap:10px;">
          <!-- Gravar -->
          <button id="_flyRecBtn" onclick="_flyToggleRecord()" title="Gravar" style="
            height:36px;padding:0 14px;border-radius:18px;border:none;cursor:pointer;
            background:rgba(255,255,255,0.08);color:rgba(255,255,255,0.55);font-size:0.82rem;
            display:flex;align-items:center;gap:5px;flex-shrink:0;
          "><span style="font-size:0.9rem;">🔴</span> Gravar</button>
          <!-- Partilhar -->
          <button onclick="window._flyShare&&_flyShare()" title="Partilhar" style="
            height:36px;padding:0 14px;border-radius:18px;border:none;cursor:pointer;
            background:rgba(249,115,22,0.15);color:rgba(249,115,22,0.85);font-size:0.82rem;
            display:flex;align-items:center;gap:5px;flex-shrink:0;
          "><span style="font-size:0.9rem;">📤</span> Partilhar</button>
          <!-- Fechar -->
          <button onclick="_flyClose()" style="
            height:36px;width:36px;border-radius:50%;border:none;cursor:pointer;
            background:rgba(255,255,255,0.13);color:#fff;font-size:1rem;
            display:flex;align-items:center;justify-content:center;flex-shrink:0;
          ">✕</button>
        </div>
      </div>
    `;
    document.body.appendChild(ov);
    _flyOverlay=ov;
    return ov;
  }

  // Funções globais dos botões do flyover
  window._flyTogglePause=function(){
    _flyPaused=!_flyPaused;
    const btn=document.getElementById('_flyPauseBtn');
    if(btn) btn.textContent=_flyPaused?'▶':'⏸';
    if(!_flyPaused&&_flyActive) _flyRAF=requestAnimationFrame(_flyLoop);
  };
  window._flyChangeSpeed=function(v){
    const speeds=[0.05,0.1,0.15,0.25,0.5,0.75,1,1.5,2,3,5];
    _flySpeed=speeds[Math.min(parseInt(v)-1,speeds.length-1)];
    const lbl=document.getElementById('_flySpeedLbl');
    if(lbl) lbl.textContent=_flySpeed+'×';
  };

  window._flyChangeZoom=function(v){
    _flyZoom=parseFloat(v);
    const lbl=document.getElementById('_flyZoomLbl');
    if(lbl) lbl.textContent=parseFloat(v).toFixed(1).replace('.0','');
    if(_flyHasML&&_flyMap&&!(_flyOutroStart>=0)){
      _flyMap.easeTo({center:[_flySmLon,_flySmLat],zoom:_flyZoom,bearing:_flySmBear,pitch:55,duration:350});
    }
  };
  window._flySeek=function(e){
    const bar=document.getElementById('_flyProgBar');
    if(!bar||!_flyTotalF) return;
    const rect=bar.getBoundingClientRect();
    const clientX=e.touches?e.touches[0].clientX:e.clientX;
    const frac=Math.max(0,Math.min(1,(clientX-rect.left)/rect.width));
    const _seekRouteF = _flyRouteF > 0 ? _flyRouteF : _flyTotalF;
    _flyFrame=Math.floor(frac*_seekRouteF);

    // Reset timing: evita spike de dt no próximo frame após seek
    _flyLastT = 0;
    _flyTimeAcc = 0;

    // Reset estado outro/slowdown ao recuar para antes de 84%
    if(frac < 0.88){
      _flyOutroStart = -1;
      _flySlowingDown = false;
      _flySpeed = _flySpeedBeforeOutro || _flySpeed;
      const ctrl=document.getElementById('_flyControls');
      if(ctrl){ ctrl.style.opacity=''; ctrl.style.transform=''; }
    }

    // Atualiza UI imediatamente
    const fill=document.getElementById('_flyProgFill');
    const dot=document.getElementById('_flyProgDot');
    const pct=Math.round(frac*100);
    if(fill) fill.style.width=pct+'%';
    if(dot) dot.style.left=pct+'%';

    // Move câmara — jumpTo (snap imediato) evita easeTo pendente que causa travar
    if(_flyPts&&_flyHasML&&_flyMap){
      const ri=frac*(_flyPts.length-1);
      const i0=Math.floor(ri),i1=Math.min(i0+1,_flyPts.length-1),sub=ri-i0;
      const lat=_flyPts[i0].lat+(_flyPts[i1].lat-_flyPts[i0].lat)*sub;
      const lon=_flyPts[i0].lon+(_flyPts[i1].lon-_flyPts[i0].lon)*sub;
      _flyMap.jumpTo({center:[lon,lat],zoom:_flyZoom,bearing:_flySmBear,pitch:55});
      // Sincroniza câmara suavizada para evitar overshooting
      _flySmLat = lat; _flySmLon = lon;
      try{
        const trailCoords=_flyPts.slice(0,i0+1).map(p=>[p.lon,p.lat]);
        trailCoords.push([lon,lat]);
        const src=_flyMap.getSource('route-trail');
        if(src) src.setData({type:'Feature',geometry:{type:'LineString',coordinates:trailCoords}});
        const posSrc=_flyMap.getSource('pos-dot');
        if(posSrc) posSrc.setData({type:'Feature',geometry:{type:'Point',coordinates:[lon,lat]}});
      }catch(ex){}
    }

    // Retoma sempre (pausado ou a correr)
    if(_flyPaused){
      _flyPaused=false;
      const btn=document.getElementById('_flyPauseBtn');
      if(btn) btn.textContent='⏸';
    }
    // Cancela RAF anterior para não ter dois loops em paralelo
    if(_flyRAF){ cancelAnimationFrame(_flyRAF); _flyRAF=null; }
    _flyRAF=requestAnimationFrame(_flyLoop);
  };
  window._flyClose=function(){ stopFlyover(); };

  // ── Auto-hide dos controles ───────────────────────────────────────
  let _flyHideTimer=null;
  function _flyShowControls(){
    const el=document.getElementById('_flyControls');
    if(!el) return;
    el.style.opacity='1'; el.style.transform='translateY(0)';
    clearTimeout(_flyHideTimer);
    _flyHideTimer=setTimeout(_flyHideControls, 3500);
  }
  function _flyHideControls(){
    const el=document.getElementById('_flyControls');
    if(el){ el.style.opacity='0'; el.style.transform='translateY(100%)'; }
  }
  window._flyTapScreen=function(){
    const el=document.getElementById('_flyControls');
    if(!el) return;
    const hidden=el.style.opacity==='0'||el.style.transform==='translateY(100%)';
    if(hidden) _flyShowControls(); else _flyHideControls();
  };

  let _flyRecording=false;
  window._flyToggleRecord=function(){
    const btn=document.getElementById('_flyRecBtn');
    if(!_flyRecording){
      // Iniciar gravação
      _startRecording();
      _flyRecording=true;
      if(btn){ btn.style.color='#ef4444'; btn.style.background='rgba(239,68,68,0.15)'; btn.textContent='⏹'; }
    } else {
      _stopRecording();
      _flyRecording=false;
      if(btn){ btn.style.color='rgba(255,255,255,0.6)'; btn.style.background='rgba(255,255,255,0.1)'; btn.textContent='🔴'; }
    }
  };

  function _startRecording(){
    if(!_flyMap) return;
    _flyChunks=[];
    try{
      // Canvas fonte: composto (mapa+HUD) ou só HUD como fallback
      let stream;
      if(_flyCompCanvas){
        stream=_flyCompCanvas.captureStream(60);
      } else {
        const hc=document.getElementById('_flyHudCanvas');
        if(hc) stream=hc.captureStream(60);
      }
      if(!stream){ console.warn('[Rec] Sem stream'); return; }

      // Ordem de preferência: MP4 H.264 (iOS/Safari/desktop) → WebM VP9 → WebM H264 → WebM
      const MIME_PRIORITY=[
        'video/mp4;codecs=avc1.42E01E', // H.264 Baseline — máxima compatibilidade
        'video/mp4;codecs=avc1',
        'video/mp4',
        'video/webm;codecs=vp9',
        'video/webm;codecs=h264',
        'video/webm',
      ];
      const bestMime=MIME_PRIORITY.find(m=>{ try{ return MediaRecorder.isTypeSupported(m); }catch(e){ return false; } })||'video/webm';
      const isMP4=bestMime.startsWith('video/mp4');
      console.log('[Rec] codec:', bestMime);

      // Bitrate alto: 40Mbps para qualidade máxima (mobile aguenta bem)
      _flyRec=new MediaRecorder(stream,{
        mimeType:bestMime,
        videoBitsPerSecond:40_000_000,
      });
      _flyRec.ondataavailable=e=>{if(e.data&&e.data.size>0)_flyChunks.push(e.data);};
      _flyRec.onstop=()=>_flyDownload(isMP4?'mp4':'webm', bestMime);
      _flyRec.start(200); // chunk a cada 200ms
      if(window.showToast) showToast('🔴 A gravar…','info');
    }catch(e){
      console.warn('[Rec] Falha:',e);
      if(window.showToast) showToast('Gravação não suportada neste browser','error');
    }
  }

  function _stopRecording(){
    if(_flyRec&&_flyRec.state==='recording') _flyRec.stop();
    _flyRec=null;
  }

  function _flyDownload(ext='webm', mime='video/webm'){
    if(!_flyChunks.length) return;
    const actName=(_flyAct?.name||'flyover').replace(/[^a-zA-Z0-9]/g,'_').slice(0,40);
    const blob=new Blob(_flyChunks,{type:mime});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=url;
    a.download=`${actName}_flyover.${ext}`;
    document.body.appendChild(a); a.click();
    setTimeout(()=>{ URL.revokeObjectURL(url); a.remove(); },3000);
    _flyChunks=[];
    if(window.showToast) showToast('🎥 Vídeo guardado (.'+ext+')','success');
  }

  // ── Partilhar: gera link flyover.html?id=X + preview do frame ──────
  window._flyShare=async function(){
    const actId=new URLSearchParams(window.location.search).get('id')||_flyAct?.activityId||'';
    if(!actId){
      if(window.showToast) showToast('ID da atividade não encontrado','error');
      return;
    }

    // URL absoluta para flyover.html na raiz do mesmo host
    // Funciona em Firebase Hosting (gpx-analyzer-f9e5e.web.app/flyover.html?id=X)
    const flyUrl = window.location.origin + '/flyover.html?id=' + actId;
    const actName = _flyAct?.name || 'Atividade';

    // Capturar preview do frame atual (mapa + HUD)
    let previewUrl = null;
    try{
      const mapDiv = document.getElementById('_flyMapDiv');
      const mlCanvas = mapDiv?.querySelector('canvas');
      const hudCanvas = document.getElementById('_flyHudCanvas');
      const W = (mlCanvas||hudCanvas)?.width || 720;
      const H = (mlCanvas||hudCanvas)?.height || 1280;
      const out = document.createElement('canvas');
      out.width = W; out.height = H;
      const oc = out.getContext('2d');
      oc.fillStyle = '#000'; oc.fillRect(0,0,W,H);
      if(mlCanvas){ try{ oc.drawImage(mlCanvas,0,0,W,H); }catch(e){} }
      if(hudCanvas) oc.drawImage(hudCanvas,0,0,W,H);
      // Watermark
      const fw = Math.round(W*0.030);
      oc.save();
      oc.font = `700 ${fw}px "SF Pro Display",Arial,sans-serif`;
      oc.textAlign = 'left';
      oc.shadowColor = 'rgba(0,0,0,0.9)'; oc.shadowBlur = 8;
      oc.fillStyle = 'rgba(249,115,22,0.92)';
      oc.fillText('GPX Analyzer', Math.round(W*0.03), H - Math.round(H*0.022));
      oc.restore();
      previewUrl = out.toDataURL('image/jpeg', 0.80);
    }catch(e){ console.warn('[Share preview]', e); }

    _flyShowShareModal(flyUrl, actName, previewUrl);
  };

  function _flyShowShareModal(url, actName, previewUrl){
    document.getElementById('_flyShareModal')?.remove();
    const modal = document.createElement('div');
    modal.id = '_flyShareModal';
    modal.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:flex-end;justify-content:center;background:rgba(0,0,0,0.65);backdrop-filter:blur(8px);';

    const prevHtml = previewUrl
      ? `<div style="width:100%;border-radius:14px;overflow:hidden;margin-bottom:14px;position:relative;aspect-ratio:9/5.5;">
           <img src="${previewUrl}" style="width:100%;height:100%;object-fit:cover;display:block;">
           <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,0.65) 0%,transparent 55%);pointer-events:none;"></div>
           <div style="position:absolute;bottom:10px;left:14px;right:14px;display:flex;align-items:flex-end;justify-content:space-between;">
             <span style="font-family:'SF Pro Display',Arial,sans-serif;font-size:.88rem;font-weight:700;color:#fff;text-shadow:0 1px 6px rgba(0,0,0,0.9);">🏃 ${actName}</span>
             <span style="font-family:'SF Pro Display',Arial,sans-serif;font-size:.68rem;color:rgba(249,115,22,.9);font-weight:600;">GPX Analyzer</span>
           </div>
         </div>` : '';

    modal.innerHTML = `
      <style>
        @keyframes _fsmUp{from{transform:translateY(110%)}to{transform:translateY(0)}}
        #_fsPanel{
          width:100%;max-width:500px;
          background:#0d1420;border-radius:22px 22px 0 0;
          padding:20px 18px env(safe-area-inset-bottom,28px);
          animation:_fsmUp 0.26s cubic-bezier(.32,0,.18,1);
          box-shadow:0 -6px 60px rgba(0,0,0,0.85);
        }
        #_fsPanel h3{margin:0 0 3px;color:#fff;font-family:'SF Pro Display',Arial,sans-serif;font-size:.98rem;font-weight:700;}
        #_fsPanel .sub{margin:0 0 14px;color:rgba(255,255,255,.35);font-family:'SF Pro Display',Arial,sans-serif;font-size:.76rem;}
        #_fsURL{
          width:100%;box-sizing:border-box;
          background:#131e30;border:1px solid rgba(249,115,22,.28);border-radius:11px;
          padding:10px 13px;color:#f97316;
          font-family:monospace;font-size:.72rem;word-break:break-all;
          line-height:1.5;margin-bottom:12px;
        }
        ._fsBtn{
          width:100%;padding:14px;border:none;border-radius:14px;
          font-family:'SF Pro Display',Arial,sans-serif;
          font-size:.90rem;font-weight:700;cursor:pointer;
          margin-bottom:8px;
          display:flex;align-items:center;justify-content:center;gap:8px;
          transition:opacity .12s,transform .1s;
        }
        ._fsBtn:active{opacity:.72;transform:scale(.98);}
        ._fsP{background:#f97316;color:#fff;}
        ._fsS{background:#131e30;color:rgba(255,255,255,.72);border:1px solid rgba(255,255,255,.10);}
        ._fsC{background:transparent;color:rgba(255,255,255,.28);font-size:.80rem;margin-top:2px;}
      </style>
      <div id="_fsPanel">
        <h3>📤 Partilhar trilha em movimento</h3>
        <p class="sub">Quem abrir o link só vê o flyover — sem os teus dados de treino</p>
        ${prevHtml}
        <div id="_fsURL">${url}</div>
        <button class="_fsBtn _fsP" id="_fsCopy">📋 Copiar link</button>
        <button class="_fsBtn _fsS" id="_fsNative">🔗 Partilhar via…</button>
        <button class="_fsBtn _fsC" id="_fsClose">Fechar</button>
      </div>
    `;
    document.body.appendChild(modal);

    // Copiar link
    modal.querySelector('#_fsCopy').onclick = async () => {
      const btn = modal.querySelector('#_fsCopy');
      try{ await navigator.clipboard.writeText(url); }
      catch(e){
        const t=document.createElement('textarea');
        t.value=url; document.body.appendChild(t); t.select();
        document.execCommand('copy'); t.remove();
      }
      btn.innerHTML = '✅ Copiado!';
      setTimeout(()=>{ btn.innerHTML='📋 Copiar link'; }, 2500);
    };

    // Web Share API → WhatsApp fallback
    modal.querySelector('#_fsNative').onclick = async () => {
      const shareData = { title:'🏃 '+actName+' — GPX Analyzer', text:'Ver trilha em movimento:', url };
      if(navigator.share && navigator.canShare && navigator.canShare(shareData)){
        try{ await navigator.share(shareData); return; }
        catch(e){ if(e.name==='AbortError') return; }
      }
      window.open('https://wa.me/?text='+encodeURIComponent('🏃 '+actName+' - '+url),'_blank');
    };

    // Fechar
    const close = () => { modal.style.opacity='0'; setTimeout(()=>modal.remove(), 220); };
    modal.querySelector('#_fsClose').onclick = close;
    modal.onclick = e => { if(e.target===modal) close(); };
  }

  // Canvas composto: copia frame MapLibre + HUD canvas → canvas gravável
  function _compositeFrame(mapDiv,hudCanvas,W,H){
    if(!_flyCompCtx||!_flyCompCanvas) return;
    // Tenta capturar o canvas WebGL do MapLibre
    const mlCanvas=mapDiv?mapDiv.querySelector('canvas'):null;
    if(mlCanvas){
      try{ _flyCompCtx.drawImage(mlCanvas,0,0,W,H); }
      catch(e){ _flyCompCtx.fillStyle='#0a0e1a';_flyCompCtx.fillRect(0,0,W,H); }
    } else {
      _flyCompCtx.fillStyle='#0a0e1a';_flyCompCtx.fillRect(0,0,W,H);
    }
    // Sobrepõe HUD
    if(hudCanvas) _flyCompCtx.drawImage(hudCanvas,0,0,W,H);
  }

  // ── Main loop ───────────────────────────────────────────────────────
  let _flyLastT=0,_flySmBear=0,_flySmLat=0,_flySmLon=0,_flyPts=null,_flyZoom=14,_flyAct=null,_flyHasML=false;
  let _flyTimeAcc=0; // acumulador de tempo para avançar frames
  let _flyRouteF=0;  // frames correspondentes apenas à duração da rota (sem outro)

  function _flyLoop(ts){
    if(!_flyActive) return;
    if(_flyPaused){ _flyLastT=ts; _flyRAF=requestAnimationFrame(_flyLoop); return; }

    // dt real, capped a 80ms para evitar saltos após tab inativa
    const dtMs = _flyLastT===0 ? 16.67 : Math.min(ts - _flyLastT, 80);
    _flyLastT = ts;

    // Acumular tempo → avançar frames proporcionalmente à velocidade
    _flyTimeAcc += dtMs * _flySpeed;
    const MS_PER_FRAME = 1000 / 60;
    const toAdd = Math.floor(_flyTimeAcc / MS_PER_FRAME);
    if(toAdd > 0){ _flyTimeAcc -= toAdd * MS_PER_FRAME; _flyFrame += toAdd; }

    const pts=_flyPts;
    // frac mapeia sobre _flyRouteF (duração da rota), não _flyTotalF
    // Assim frac atinge 1.0 no fim da rota, e os frames extra servem o outro
    const routeF = _flyRouteF > 0 ? _flyRouteF : _flyTotalF;
    const frac=Math.min(_flyFrame/routeF,1);

    // Interpolação sub-frame — posição exata entre dois pontos
    const ri=frac*(pts.length-1),i0=Math.floor(ri),i1=Math.min(i0+1,pts.length-1),sub=ri-i0;
    const lat=pts[i0].lat+(pts[i1].lat-pts[i0].lat)*sub;
    const lon=pts[i0].lon+(pts[i1].lon-pts[i0].lon)*sub;

    // ── Câmera cinematográfica com constante de tempo exponencial ──
    // α = 1-exp(-dt/tau) garante suavidade independente do fps
    // tau alto = câmera "pesada" como em drones/filmes
    const tauPos  = 1800;  // ms — posição demora ~1800ms a chegar ao alvo
    const tauBear = 2800; // ms — rotação muito suave, quase em câmera lenta
    const aPos  = 1 - Math.exp(-dtMs / tauPos);
    const aBear = 1 - Math.exp(-dtMs / tauBear);
    _flySmLat += (lat  - _flySmLat) * aPos;
    _flySmLon += (lon  - _flySmLon) * aPos;

    if(i1>i0){
      const rawB=_bearing(pts[i0].lat,pts[i0].lon,pts[i1].lat,pts[i1].lon);
      let d=rawB-_flySmBear; if(d>180)d-=360; if(d<-180)d+=360;
      _flySmBear=(_flySmBear + d*aBear + 360)%360;
    }

    const _isOutro=(_flyOutroStart>=0);

    if(_flyHasML&&_flyMap){
      // ── Câmara MapLibre — duration=dtMs faz o motor interpolar
      // entre os nossos frames → visual ainda mais fluído
      if(!_isOutro){
        _flyMap.easeTo({
          center:[_flySmLon,_flySmLat],
          zoom: _flyZoom,
          bearing: _flySmBear,
          pitch: 55,
          duration: Math.max(dtMs * 1.5, 40),
          easing: t => t,
        });
      }

      // ── Rastro: para de atualizar no encerramento (poupa GPU) ────
      if(!_isOutro){
        try{
          const src=_flyMap.getSource('route-trail');
          if(src){
            const sc=_flyMap._segColor;
            const segs=[];
            const end=Math.min(i0,pts.length-2);
            const step=Math.max(1,Math.floor(pts.length/180)); // max 180 segs
            for(let j=0;j<=end;j+=step){
              const jn=Math.min(j+step,end);
              const midPt=pts[Math.floor((j+jn)/2)];
              segs.push({type:'Feature',properties:{color:sc(midPt)},
                geometry:{type:'LineString',coordinates:pts.slice(j,jn+1).map(p=>[p.lon,p.lat])}});
            }
            segs.push({type:'Feature',properties:{color:sc(pts[i0])},
              geometry:{type:'LineString',coordinates:[[pts[i0].lon,pts[i0].lat],[lon,lat]]}});
            src.setData({type:'FeatureCollection',features:segs});
          }
        }catch(e){}

        // ── Ponto atual ──────────────────────────────────────────────
        try{
          const posSrc=_flyMap.getSource('pos-dot');
          if(posSrc) posSrc.setData({type:'Feature',geometry:{type:'Point',coordinates:[lon,lat]}});
        }catch(e){}
      }
    }

    // Atualiza HUD canvas (HUD + minimap + ponto pulsante no canvas)
    const hudCanvas=document.getElementById('_flyHudCanvas');

    // ── Slowdown gradual + encerramento ────────────────────────────
    // Gatilho baseado em frac geográfico (posição real na rota),
    // não em contagem de frames — evita que o outro arranque antes
    // de terminar o percurso quando a rota é curta vs duração total.
    const OUTRO_FRAMES        = Math.round(120*4);  // 4s — última métrica a ~f=0.79, fade termina a f=1.0
    const SLOW_FRAC_TRIGGER   = 0.88; // começa a desacelerar a 88% da rota
    const OUTRO_FRAC_TRIGGER  = 1.00; // arranca o outro APENAS no fim da trilha

    // Inicia slowdown quando a rota chega a 88%
    if(frac >= SLOW_FRAC_TRIGGER && _flyOutroStart < 0 && !_flySlowingDown){
      _flySlowingDown = true;
      _flySpeedBeforeOutro = _flySpeed;
    }
    if(_flySlowingDown && _flyOutroStart < 0){
      // slowT: 0=início slowdown, 1=fim da trilha
      const slowT = Math.max(0, frac - SLOW_FRAC_TRIGGER) / (OUTRO_FRAC_TRIGGER - SLOW_FRAC_TRIGGER);
      const eased = 1 - Math.pow(1 - Math.min(1,slowT), 2);
      _flySpeed = Math.max(0.05, _flySpeedBeforeOutro * (1 - eased * 0.96));
    }

    // Arrancar outro APENAS quando frac chega a 1.0 (fim exacto da trilha)
    if(frac >= OUTRO_FRAC_TRIGGER && _flyOutroStart < 0){
      _flyOutroStart = _flyFrame;
      _flySlowingDown = false;
      _flySpeed = 0.05; // quase parado durante a cinemática final
      const ctrl=document.getElementById('_flyControls');
      if(ctrl){ ctrl.style.opacity='0'; ctrl.style.transform='translateY(100%)'; }
    }
    const outroFrac = _flyOutroStart>=0
      ? Math.min(1,((_flyFrame-_flyOutroStart)/OUTRO_FRAMES))
      : -1;

    if(hudCanvas){
      const ctx=hudCanvas.getContext('2d');
      const CW=hudCanvas.width, CH=hudCanvas.height;
      ctx.clearRect(0,0,CW,CH);
      const ptIdx=Math.min(Math.floor(frac*(pts.length-1)),pts.length-1);
      if(outroFrac >= 0){
        // Encerramento: HUD normal + overlay cinematográfico por cima
        _drawHUD(ctx,CW,CH,pts[ptIdx],frac,_flyAct,ts);
        _drawOutro(ctx,CW,CH,outroFrac,ts,_flyAct,pts);
      } else {
        _drawHUD(ctx,CW,CH,pts[ptIdx],frac,_flyAct,ts);
      }
    }

    // Atualiza barra progresso UI
    const pct=Math.round(frac*100);
    const fill=document.getElementById('_flyProgFill');
    const dot=document.getElementById('_flyProgDot');
    if(fill) fill.style.width=pct+'%';
    if(dot) dot.style.left=pct+'%';

    // Canvas composto para gravação (WebGL + HUD)
    if(_flyCompCanvas&&_flyCompCtx){
      const W2=_flyCompCanvas.width, H2=_flyCompCanvas.height;
      _flyCompCtx.fillStyle='#0a0e1a';
      _flyCompCtx.fillRect(0,0,W2,H2);
      // Mapa WebGL: desenhar escalado para resolução 2×
      const mapDiv=document.getElementById('_flyMapDiv');
      const mlCanvas=mapDiv?.querySelector('canvas');
      if(mlCanvas){
        try{
          _flyCompCtx.imageSmoothingEnabled=true;
          _flyCompCtx.imageSmoothingQuality='high';
          _flyCompCtx.drawImage(mlCanvas,0,0,W2,H2);
        }catch(e){}
      }
      // HUD já é 2× — copiar direto
      if(hudCanvas) _flyCompCtx.drawImage(hudCanvas,0,0,W2,H2);
      // ── Watermark no vídeo: canto inferior esquerdo, nítido ──────
      const FONT_WM='"SF Pro Display","Helvetica Neue",Arial,sans-serif';
      const fwm=Math.round(W2*0.026); // fonte maior
      _flyCompCtx.save();
      _flyCompCtx.textAlign='left';
      _flyCompCtx.font=`700 ${fwm}px ${FONT_WM}`;
      // Sombra forte para legibilidade sobre qualquer fundo
      _flyCompCtx.shadowColor='rgba(0,0,0,0.95)';
      _flyCompCtx.shadowBlur=8;
      _flyCompCtx.shadowOffsetX=1; _flyCompCtx.shadowOffsetY=1;
      const wxPad=Math.round(W2*0.032), wyPad=H2-Math.round(H2*0.022);
      // "GPX Analyzer" — laranja sólido
      _flyCompCtx.fillStyle='rgba(249,115,22,0.90)';
      _flyCompCtx.fillText('GPX Analyzer',wxPad,wyPad);
      const ww=_flyCompCtx.measureText('GPX Analyzer').width;
      // "by Fábio Gomes" — branco nítido
      _flyCompCtx.font=`600 ${Math.round(fwm*0.85)}px ${FONT_WM}`;
      _flyCompCtx.fillStyle='rgba(255,255,255,0.82)';
      _flyCompCtx.fillText(' by Fábio Gomes',wxPad+ww,wyPad);
      _flyCompCtx.shadowBlur=0; _flyCompCtx.shadowOffsetX=0; _flyCompCtx.shadowOffsetY=0;
      _flyCompCtx.restore();
    }

    _flyFrame++;

    // Terminar logo que o outro completa (outroFrac=1.0), sem esperar _flyTotalF
    const _outroDone = _flyOutroStart >= 0 &&
      (_flyFrame - _flyOutroStart) >= OUTRO_FRAMES;

    if(_outroDone || _flyFrame > _flyTotalF){
      _flyActive=false;
      if(_flyRec&&_flyRec.state!=='inactive') _flyRec.stop();
      _flyRecording=false;
      // Sem setTimeout — cleanup imediato para não haver ecrã preto extra
      _cleanupFlyover(); if(_flyAct?.onDone) _flyAct.onDone();
    } else {
      _flyRAF=requestAnimationFrame(_flyLoop);
    }
  }

  async function startFlyover(opts={}){
    if(!_trackPoints||_trackPoints.length<2) return;
    if(_flyActive) stopFlyover();

    const dur   =(opts.duration||20)*1000;
    const zoom  =opts.zoom||14;
    const speed =Math.max(0.05,opts.speed||0.25);
    const onD   =opts.onDone||(()=>{});
    const act   =opts.activity||null;
    const tileKey=_currentTile;

    _flyActive=true; _flyPaused=false; _flyFrame=0; _flyRecording=false;
    // Inicializa câmara suavizada com o PRIMEIRO ponto da rota (não [0,0])
    // Evita que a câmara voe do oceano para a rota no arranque
    const _firstPt = _trackPoints[0];
    _flySmLat=_firstPt.lat; _flySmLon=_firstPt.lon;
    _flyOutroStart=-1; _flyTimeAcc=0; _flyLastT=0; _flyRouteF=0;
    _flySlowingDown=false; _flySpeedBeforeOutro=speed;
    window._flyPtsRef=_trackPoints; // acesso pelo _drawHUD para sparklines
    _flySpeed=speed; _flyZoom=zoom; _flyPts=_trackPoints; _flySmBear=0;
    // _flyRouteF: frames para percorrer a rota (= duração configurada)
    // _flyTotalF: total incluindo 8s de margem para o outro correr DEPOIS da rota
    _flyRouteF=Math.round((dur/1000)*120);
    _flyTotalF=_flyRouteF + Math.round(120*8); _flyAct={...act,onDone:onD};

    // ── Cria overlay fullscreen ─────────────────────────────────────
    const ov=_buildFlyoverUI(act);

    // Dimensões viewport
    const W=window.innerWidth,H=window.innerHeight;
    // Escala 2× para gravação em alta resolução (mantém CSS em 1×)
    const REC_SCALE = 2;
    const RW = W*REC_SCALE, RH = H*REC_SCALE;

    // ── Canvas HUD — resolução 2× para nitidez ────────────────────
    const hudCanvas=document.getElementById('_flyHudCanvas');
    if(hudCanvas){
      hudCanvas.width=RW; hudCanvas.height=RH;
      // Escalar via CSS para continuar a ocupar o ecrã todo
      hudCanvas.style.width='100%'; hudCanvas.style.height='100%';
    }

    // ── Canvas composto 2× (para gravação em alta resolução) ──────
    _flyCompCanvas=document.createElement('canvas');
    _flyCompCanvas.width=RW; _flyCompCanvas.height=RH;
    _flyCompCtx=_flyCompCanvas.getContext('2d',{willReadFrequently:false,alpha:false});

    // ── Configura speed slider com valor inicial ──────────────────
    const sl=document.getElementById('_flySpeedSlider');
    const speeds=[0.05,0.1,0.15,0.25,0.5,0.75,1,1.5,2,3,5];
    const sIdx=speeds.findIndex(s=>Math.abs(s-speed)<0.01);
    if(sl) sl.value=sIdx>=0?sIdx+1:4;
    const lbl=document.getElementById('_flySpeedLbl');
    if(lbl) lbl.textContent=speed+'×';
    const zsl=document.getElementById('_flyZoomSlider');
    if(zsl){ zsl.value=zoom; }
    const zlbl=document.getElementById('_flyZoomLbl');
    if(zlbl) zlbl.textContent=String(zoom).replace('.0','');

    // ── Inicia mapa MapLibre ───────────────────────────────────────
    _flyMap=_createFlyMap('_flyMapDiv',tileKey);
    _flyHasML=_flyMap!==null;

    if(opts.onPreload) opts.onPreload('⏳ A carregar mapa satélite…');

    if(_flyHasML){
      const firstPt=_flyPts[0];

      await new Promise(res=>{
        _flyMap.once('load', ()=>{
          // Posiciona no início da rota logo que mapa carregar
          _flyMap.jumpTo({
            center:[firstPt.lon, firstPt.lat],
            zoom:_flyZoom,
            bearing:0,
            pitch:55,
          });
          console.log('[Flyover] Mapa carregado, posicionado em início da rota');
          res();
        });
        // Timeout de segurança: 10s
        setTimeout(()=>{ console.warn('[Flyover] timeout 10s'); res(); }, 10000);
      });

      // ── Pré-calcular min/max de FC e altimetria para cor do rastro ─
      // Prioridade: FC → altimetria → laranja fixo
      const _hrs  = _flyPts.map(p=>p.hr>0?p.hr:null).filter(Boolean);
      const _eles = _flyPts.map(p=>p.ele!=null?p.ele:null).filter(v=>v!=null);
      const _hasHR  = _hrs.length > _flyPts.length*0.3; // pelo menos 30% dos pts com FC
      const _hasEle = !_hasHR && _eles.length>0 && (Math.max(..._eles)-Math.min(..._eles))>5;

      // Zonas FC (% da FCmax estimada em 190bpm por defeito, ou real dos dados)
      const _hrMin = _hasHR ? Math.max(40,  Math.min(..._hrs)-5)  : 0;
      const _hrMax = _hasHR ? Math.min(220, Math.max(..._hrs)+5)  : 220;
      const _hrRange = Math.max(_hrMax-_hrMin, 1);

      // Escala cor: FC ou elevação → azul/verde/amarelo/laranja/vermelho
      // Stops: [threshold_0to1, [R,G,B]]
      const _colorStops = [
        [0.00, [56,189,248]],  // azul  — zona 1 (muito baixa)
        [0.30, [34,211,238]],  // ciano — zona 2
        [0.50, [74,222,128]],  // verde — zona 3 (aeróbico)
        [0.70, [250,204,21]],  // amarelo — zona 4
        [0.85, [249,115,22]],  // laranja — zona 5
        [1.00, [239,68,68]],   // vermelho — zona 5+ / FC máx
      ];
      function _interpColor(t){
        t=Math.max(0,Math.min(1,t));
        let s0=_colorStops[0],s1=_colorStops[_colorStops.length-1];
        for(let i=0;i<_colorStops.length-1;i++){
          if(t>=_colorStops[i][0]&&t<=_colorStops[i+1][0]){s0=_colorStops[i];s1=_colorStops[i+1];break;}
        }
        const u=(t-s0[0])/Math.max(s1[0]-s0[0],0.001);
        const r=Math.round(s0[1][0]+(s1[1][0]-s0[1][0])*u);
        const g=Math.round(s0[1][1]+(s1[1][1]-s0[1][1])*u);
        const b=Math.round(s0[1][2]+(s1[1][2]-s0[1][2])*u);
        return `rgb(${r},${g},${b})`;
      }

      // Altimetria como fallback
      const _eleMin = _eles.length?Math.min(..._eles):0;
      const _eleMax = _eles.length?Math.max(..._eles):1;
      const _eleRange = Math.max(_eleMax-_eleMin,1);

      function _segColor(pt){
        if(_hasHR && pt.hr>0) return _interpColor((pt.hr-_hrMin)/_hrRange);
        if(_hasEle && pt.ele!=null) return _interpColor((pt.ele-_eleMin)/_eleRange);
        return '#f97316'; // laranja fixo
      }

      // Expor para o loop
      _flyMap._segColor=_segColor;
      _flyMap._hasHR=_hasHR; _flyMap._hasEle=_hasEle;
      console.log('[Flyover] Cor rastro:', _hasHR?'FC':'altimetria', '| FC pts:', _hrs.length, '| hrMin:', _hrMin, 'hrMax:', _hrMax);

      // ── Rota guia (fundo) cinza subtil ───────────────────────────
      const fullCoords=_flyPts.map(p=>[p.lon,p.lat]);
      try {
        _flyMap.addSource('route-full',{type:'geojson',data:{type:'Feature',geometry:{type:'LineString',coordinates:fullCoords}}});
        _flyMap.addLayer({id:'route-full-line',type:'line',source:'route-full',
          layout:{'line-cap':'round','line-join':'round'},
          paint:{'line-color':'rgba(255,255,255,0.12)','line-width':2.5}});
      } catch(e){}

      // ── Rastro dinâmico: FeatureCollection de segmentos coloridos ─
      const emptyFC={type:'FeatureCollection',features:[]};
      try {
        _flyMap.addSource('route-trail',{type:'geojson',data:emptyFC});
        // Sombra
        _flyMap.addLayer({id:'route-trail-shadow',type:'line',source:'route-trail',
          layout:{'line-cap':'round','line-join':'round'},
          paint:{'line-color':'rgba(0,0,0,0.55)','line-width':10,'line-blur':3}});
        // Linha colorida
        _flyMap.addLayer({id:'route-trail-line',type:'line',source:'route-trail',
          layout:{'line-cap':'round','line-join':'round'},
          paint:{'line-color':['get','color'],'line-width':5}});
        // Brilho
        _flyMap.addLayer({id:'route-trail-glow',type:'line',source:'route-trail',
          layout:{'line-cap':'round','line-join':'round'},
          paint:{'line-color':['get','color'],'line-width':12,'line-blur':8,'line-opacity':0.3}});
      } catch(e){ console.warn('[Flyover] trail:',e); }

      // ── Ponto atual ───────────────────────────────────────────────
      try {
        _flyMap.addSource('pos-dot',{type:'geojson',data:{type:'Feature',geometry:{type:'Point',coordinates:[_flyPts[0].lon,_flyPts[0].lat]}}});
        _flyMap.addLayer({id:'pos-dot-pulse',type:'circle',source:'pos-dot',paint:{
          'circle-radius':8,'circle-color':'rgba(255,255,255,0.15)','circle-stroke-width':0,'circle-blur':0.6}}); 
        _flyMap.addLayer({id:'pos-dot-inner',type:'circle',source:'pos-dot',paint:{
          'circle-radius':5,'circle-color':'#ffffff',
          'circle-stroke-color':'#f97316','circle-stroke-width':2,
          'circle-pitch-alignment':'map'}});
      } catch(e){}

      // (cor do rastro já configurada acima)
    }

    if(opts.onPreload) opts.onPreload(null);

    _flyLastT=0;
    // Auto-hide: mostrar controles no início e ocultar após 3.5s
    setTimeout(()=>{ _flyShowControls(); }, 800);
    _flyRAF=requestAnimationFrame(_flyLoop);
  }

  // ── Ponto seguidor pulsante no centro do ecrã ────────────────────────
  function _drawPositionDot(ctx,W,H,ts){
    const cx=W/2, cy=H*0.58; // ligeiramente abaixo do centro
    const pulse=(Math.sin((ts||0)*0.004)*0.5+0.5); // 0→1 oscilação

    // Anel exterior pulsante
    const r1=18+pulse*8;
    ctx.beginPath();
    ctx.arc(cx,cy,r1,0,Math.PI*2);
    ctx.fillStyle=`rgba(249,115,22,${0.15+pulse*0.1})`;
    ctx.fill();

    // Anel médio
    ctx.beginPath();
    ctx.arc(cx,cy,12,0,Math.PI*2);
    ctx.fillStyle='rgba(249,115,22,0.35)';
    ctx.fill();

    // Círculo branco central com borda laranja
    ctx.beginPath();
    ctx.arc(cx,cy,8,0,Math.PI*2);
    ctx.fillStyle='#fff';
    ctx.shadowColor='#f97316';
    ctx.shadowBlur=12;
    ctx.fill();
    ctx.shadowBlur=0;

    // Borda laranja
    ctx.beginPath();
    ctx.arc(cx,cy,8,0,Math.PI*2);
    ctx.strokeStyle='#f97316';
    ctx.lineWidth=2.5;
    ctx.stroke();
  }

  function _drawHUD(ctx,W,H,pt,frac,activity,ts){
    if(!pt) return;

    const FONT = '"SF Pro Display","Helvetica Neue",system-ui,Arial,sans-serif';
    const t_sec = (ts||0)/1000;

    // ── Dados ──────────────────────────────────────────────────────
    const spd = pt.speed!=null  ? parseFloat(pt.speed.toFixed(1)) : null;
    const ele = pt.ele!=null    ? Math.round(pt.ele)              : null;
    const hr  = pt.hr>0         ? pt.hr                           : null;

    // ── Pré-calcular ranges globais (do _flyPtsRef) ────────────────
    const allPts = window._flyPtsRef || [];
    let spdMax=40, hrMin=50, hrMax=200, eleMin=0, eleMax=500;
    if(allPts.length>0){
      const spds=allPts.map(p=>p.speed||0); spdMax=Math.max(Math.max(...spds),1);
      const hrs=allPts.filter(p=>p.hr>0).map(p=>p.hr);
      if(hrs.length){ hrMin=Math.max(40,Math.min(...hrs)-5); hrMax=Math.min(220,Math.max(...hrs)+5); }
      const eles=allPts.filter(p=>p.ele!=null).map(p=>p.ele);
      if(eles.length){ eleMin=Math.min(...eles); eleMax=Math.max(Math.max(...eles),eleMin+1); }
    }

    // ── Função interpolar cor por valor normalizado ─────────────────
    // Paleta: azul→ciano→verde→amarelo→laranja→vermelho
    function interpColor(t, alpha){
      t=Math.max(0,Math.min(1,t));
      const stops=[
        [0.00,[56,189,248]],[0.25,[34,211,238]],[0.50,[74,222,128]],
        [0.70,[250,204,21]],[0.85,[249,115,22]],[1.00,[239,68,68]]
      ];
      let s0=stops[0],s1=stops[stops.length-1];
      for(let i=0;i<stops.length-1;i++){if(t>=stops[i][0]&&t<=stops[i+1][0]){s0=stops[i];s1=stops[i+1];break;}}
      const u=(t-s0[0])/Math.max(s1[0]-s0[0],0.001);
      const r=Math.round(s0[1][0]+(s1[1][0]-s0[1][0])*u);
      const g=Math.round(s0[1][1]+(s1[1][1]-s0[1][1])*u);
      const b=Math.round(s0[1][2]+(s1[1][2]-s0[1][2])*u);
      return alpha!=null?`rgba(${r},${g},${b},${alpha})`:`rgb(${r},${g},${b})`;
    }

    // ── Dimensões dos cards ────────────────────────────────────────
    const CARD_R  = Math.round(Math.min(W,H)*0.088); // menor para 4 cards
    const RING_W  = Math.round(CARD_R*0.22);
    const GAP     = Math.round(W*0.022);
    const totalW  = 4*(CARD_R*2)+3*GAP;
    // Centrado horizontalmente, nunca cortado
    const startX  = Math.max(GAP, (W-totalW)/2);
    // Centro vertical dos cards: 8% de H + raio — garante que o topo não corta
    const cardY   = Math.round(H*0.08) + CARD_R;

    // Centros dos 4 cards (espaçamento uniforme a partir do startX)
    const cx1 = startX + CARD_R;
    const cx2 = cx1 + CARD_R*2 + GAP;
    const cx3 = cx2 + CARD_R*2 + GAP;
    const cx4 = cx3 + CARD_R*2 + GAP;
    const cy  = cardY;

    // ── Função desenhar um card circular ──────────────────────────
    // cx,cy: centro | R: raio ext | rw: ring width
    // val: valor actual | valStr: texto | unit: unidade | label: topo
    // t: 0-1 para cor e anel | beat: pulsação (0-1) | icon: 'heart'|null
    function drawCard(cx,cy,R,rw, valStr,unit,label, t, beat, icon, zone){
      const Ri  = R-rw;
      const Rm  = R-rw/2;
      const col = interpColor(t);
      const colA= interpColor(t, 0.25);
      const colB= interpColor(t, 0.55);

      // ── Camada 1: glow externo (isolado — sem shadow leak) ─────────
      ctx.save();
      ctx.globalCompositeOperation='source-over';
      const glowR=R+(beat||0)*8;
      const glow=ctx.createRadialGradient(cx,cy,Ri*0.8,cx,cy,glowR+14);
      glow.addColorStop(0, colA);
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.beginPath(); ctx.arc(cx,cy,glowR+14,0,Math.PI*2);
      ctx.fillStyle=glow; ctx.fill();
      ctx.restore();

      // ── Camada 2: fundo do card (clip ao círculo exato) ─────────────
      ctx.save();
      ctx.beginPath(); ctx.arc(cx,cy,R+4,0,Math.PI*2); ctx.clip();
      ctx.fillStyle='rgba(4,6,16,0.58)';
      ctx.fillRect(cx-R-5, cy-R-5, (R+5)*2, (R+5)*2);
      ctx.restore();

      // ── Camada 3: anel track ─────────────────────────────────────────
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx,cy,Rm, -Math.PI*0.5+Math.PI*0.1, Math.PI*1.5-Math.PI*0.1);
      ctx.strokeStyle='rgba(255,255,255,0.08)';
      ctx.lineWidth=rw; ctx.lineCap='round'; ctx.stroke();
      ctx.restore();

      // ── Camada 4: anel de valor + dot (shadow isolado) ───────────────
      {
        const startA = -Math.PI*0.5 + Math.PI*0.1;
        const sweepMax= Math.PI*1.8;
        const endA  = startA + sweepMax * Math.max(0.02, t);

        ctx.save();
        ctx.shadowColor=col; ctx.shadowBlur=12+(beat||0)*8;
        const gRing=ctx.createLinearGradient(cx-R,cy,cx+R,cy);
        gRing.addColorStop(0, interpColor(Math.max(0,t-0.3), 0.9));
        gRing.addColorStop(1, interpColor(t, 1.0));
        ctx.beginPath(); ctx.arc(cx,cy,Rm, startA, endA);
        ctx.strokeStyle=gRing; ctx.lineWidth=rw; ctx.lineCap='round'; ctx.stroke();
        ctx.restore(); // shadow limpa aqui — não vaza para fora

        // Dot na ponta (shadow próprio, isolado)
        const dotX=cx+Rm*Math.cos(endA);
        const dotY=cy+Rm*Math.sin(endA);
        ctx.save();
        ctx.shadowColor=col; ctx.shadowBlur=8;
        ctx.beginPath(); ctx.arc(dotX,dotY,rw*0.38,0,Math.PI*2);
        ctx.fillStyle='#fff'; ctx.fill();
        ctx.restore();
      }

      // ── Camada 5: texto (sem shadow de cor — só drop-shadow neutro) ──
      ctx.save();
      ctx.textAlign='center';

      // Label topo
      const fLbl=Math.round(R*0.22);
      ctx.font=`600 ${fLbl}px ${FONT}`;
      ctx.fillStyle=colB;
      ctx.fillText(label, cx, cy-R*0.38);

      // Valor central
      const fVal=Math.round(R*(valStr.length>3?0.42:0.50));
      ctx.font=`800 ${fVal}px ${FONT}`;
      ctx.fillStyle=col;
      ctx.shadowColor='rgba(0,0,0,0.7)'; ctx.shadowBlur=4;

      if(icon==='heart'){
        const beat2=(beat||0);
        const hs=fVal*0.38*(1+beat2*0.15);
        // mede largura ANTES de alterar estado de save
        const tw=ctx.measureText(valStr).width;
        const hx=cx - tw/2 - hs*0.6;
        const hy=cy+R*0.04;
        ctx.save();
        ctx.shadowColor='rgba(239,68,68,0.8)'; ctx.shadowBlur=4*beat2;
        ctx.translate(hx, hy-hs*0.1);
        ctx.scale(hs/10, hs/10);
        ctx.beginPath();
        ctx.moveTo(0,-3);
        ctx.bezierCurveTo(0,-6,-5,-6,-5,-3);
        ctx.bezierCurveTo(-5,1,0,5,0,6);
        ctx.bezierCurveTo(0,5,5,1,5,-3);
        ctx.bezierCurveTo(5,-6,0,-6,0,-3);
        ctx.closePath();
        ctx.fillStyle=`rgba(248,113,113,${0.8+beat2*0.2})`;
        ctx.fill();
        ctx.restore();
        // repor shadow neutro para o valor
        ctx.shadowColor='rgba(0,0,0,0.7)'; ctx.shadowBlur=4;
      }

      ctx.fillText(valStr, cx, cy+R*0.08);

      // Unidade
      const fUnt=Math.round(R*0.18);
      ctx.font=`500 ${fUnt}px ${FONT}`;
      ctx.fillStyle='rgba(255,255,255,0.38)';
      ctx.shadowBlur=0;
      ctx.fillText(unit, cx, cy+R*0.28);

      // Zona
      if(zone){
        ctx.shadowBlur=0;
        ctx.strokeStyle=interpColor(t,0.18);
        ctx.lineWidth=1;
        ctx.beginPath();
        ctx.moveTo(cx-R*0.45, cy+R*0.42);
        ctx.lineTo(cx+R*0.45, cy+R*0.42);
        ctx.stroke();

        let fZone=Math.round(R*0.20);
        ctx.font=`700 ${fZone}px ${FONT}`;
        const tw2=ctx.measureText(zone).width;
        const maxW=Ri*1.8;
        if(tw2>maxW) fZone=Math.round(fZone*maxW/tw2);
        ctx.font=`700 ${fZone}px ${FONT}`;
        ctx.fillStyle=interpColor(t,0.90);
        ctx.shadowColor='rgba(0,0,0,0.85)'; ctx.shadowBlur=4;
        ctx.fillText(zone, cx, cy+R*0.64);
      }

      ctx.restore();
      return {};
    }

    // ── Calcular valores normalizados e zonas ───────────────────────
    const tSpd = spd!=null ? Math.min(1, spd/spdMax)                 : 0;
    const tHr  = hr!=null  ? Math.min(1,(hr-hrMin)/Math.max(hrMax-hrMin,1)) : 0;
    const tEle = ele!=null ? Math.min(1,(ele-eleMin)/Math.max(eleMax-eleMin,1)) : 0;

    // Beat do coração sincronizado com FC (~60-180bpm)
    const bpm     = hr||70;
    const beatHz  = bpm/60;
    const beatRaw = Math.sin(t_sec*beatHz*Math.PI*2)*0.5+0.5;
    const beat    = beatRaw;

    // Zona de velocidade
    function spdZone(v){ if(!v)return'PARADO'; if(v<15)return'LENTO'; if(v<25)return'MODERADO'; if(v<38)return'RÁPIDO'; return'SPRINT'; }
    function hrZone(v,mn,mx){ const t=(v-mn)/(mx-mn); if(t<0.6)return'ZONA 2'; if(t<0.75)return'ZONA 3'; if(t<0.87)return'ZONA 4'; if(t<0.95)return'ZONA 5'; return'MÁXIMO'; }
    function eleZone(v){ if(v==null)return'---'; if(v<50)return'PLANÍCIE'; if(v<200)return'COLINA'; if(v<500)return'MONTANHA'; return'ALTITUDE'; }
    function distZone(v){ if(!v||v<1)return'INÍCIO'; if(v<10)return'AQUECENDO'; if(v<25)return'EM RITMO'; if(v<50)return'LONGA'; return'ÉPICO'; }

    const spdStr  = spd!=null  ? spd.toFixed(0)  : '--';
    const hrStr   = hr!=null   ? String(hr)      : '--';
    const eleStr  = ele!=null  ? String(ele)     : '--';
    const dist    = pt.distFromStart!=null ? pt.distFromStart/1000 : null;
    const distMax = allPts.length>0 ? (allPts[allPts.length-1].distFromStart||0)/1000 : 1;
    const distStr = dist!=null ? dist.toFixed(1) : '--';
    const tDist   = dist!=null ? Math.min(1, dist/Math.max(distMax,1)) : 0;

    // ── Desenhar os 4 cards ────────────────────────────────────────
    // Reset de shadow antes de cada card — evita herança entre cards
    ctx.save();
    ctx.shadowBlur=0; ctx.shadowColor='transparent';
    ctx.shadowOffsetX=0; ctx.shadowOffsetY=0;
    // Card 1: Velocidade
    drawCard(cx1,cy,CARD_R,RING_W, spdStr,'km/h','VEL', tSpd, 0, null, spdZone(spd));
    ctx.shadowBlur=0; ctx.shadowColor='transparent';
    // Card 2: FC
    drawCard(cx2,cy,CARD_R,RING_W, hrStr,'bpm','FC', tHr, beat, 'heart', hr?hrZone(hr,hrMin,hrMax):'---');
    ctx.shadowBlur=0; ctx.shadowColor='transparent';
    // Card 3: Altimetria
    drawCard(cx3,cy,CARD_R,RING_W, eleStr,'m','ALT', tEle, 0, null, eleZone(ele));
    ctx.shadowBlur=0; ctx.shadowColor='transparent';
    // Card 4: Distância total
    drawCard(cx4,cy,CARD_R,RING_W, distStr,'km','KM', tDist, 0, null, distZone(dist));
    ctx.restore();
  }

  // ── Encerramento cinematográfico ─────────────────────────────────
  function _drawOutro(ctx, W, H, f, ts, activity, pts){
    // f = 0→1 ao longo de 6 segundos
    // ── Isolar TUDO num save global — nenhum estado vaza para fora ──
    ctx.save();
    ctx.shadowBlur=0; ctx.shadowColor='transparent';
    ctx.shadowOffsetX=0; ctx.shadowOffsetY=0;

    const FONT  = '"SF Pro Display","Helvetica Neue",system-ui,Arial,sans-serif';
    const ease3 = t => 1-Math.pow(1-Math.max(0,Math.min(1,t)),3);
    const ease2 = t => 1-Math.pow(1-Math.max(0,Math.min(1,t)),2);
    const phase = (from,to) => Math.max(0,Math.min(1,(f-from)/(to-from)));

    // ─ Pré-calcular stats ──────────────────────────────────────────
    let totalKm='--', elevGain='--', elevLoss='--', avgSpd='--', maxSpd='--';
    let avgHR='--', maxHR='--', duration='--', calories='--';
    if(pts && pts.length>0){
      const last=pts[pts.length-1];
      // Distância
      if(last.distFromStart!=null) totalKm=(last.distFromStart/1000).toFixed(1);
      // Altimetria
      const eles=pts.filter(p=>p.ele!=null).map(p=>p.ele);
      if(eles.length>1){
        let gain=0, loss=0;
        for(let i=1;i<eles.length;i++){
          const d=eles[i]-eles[i-1];
          if(d>0) gain+=d; else loss+=Math.abs(d);
        }
        elevGain='+'+Math.round(gain);
        elevLoss='-'+Math.round(loss);
      }
      // Velocidade
      const spds=pts.map(p=>p.speed).filter(Boolean);
      if(spds.length){
        avgSpd=(spds.reduce((a,b)=>a+b)/spds.length).toFixed(0);
        maxSpd=Math.max(...spds).toFixed(0);
      }
      // FC
      const hrs=pts.filter(p=>p.hr>0).map(p=>p.hr);
      if(hrs.length){
        avgHR=Math.round(hrs.reduce((a,b)=>a+b)/hrs.length);
        maxHR=Math.max(...hrs);
      }
      // Duração (tempo real entre primeiro e último ponto com timestamp)
      const tpts=pts.filter(p=>p.time!=null);
      if(tpts.length>1){
        const secs=Math.round((new Date(tpts[tpts.length-1].time)-new Date(tpts[0].time))/1000);
        const hh=Math.floor(secs/3600), mm=Math.floor((secs%3600)/60), ss=secs%60;
        duration = hh>0 ? `${hh}h${String(mm).padStart(2,'0')}` : `${mm}m${String(ss).padStart(2,'0')}s`;
      }
      // Calorias estimadas: 0.175 × peso(75kg assumido) × distKm  (aprox MET 6)
      // Se FC disponível usa fórmula mais precisa
      if(last.distFromStart!=null){
        const distKm=last.distFromStart/1000;
        if(hrs.length && tpts.length>1){
          const secs=Math.round((new Date(tpts[tpts.length-1].time)-new Date(tpts[0].time))/1000);
          const hrAvgN=hrs.reduce((a,b)=>a+b)/hrs.length;
          // Keytel formula (homem 75kg 35 anos)
          calories=Math.round(((hrAvgN*0.6309 - 55.0969 + 75*0.1988 + 35*0.2017) / 4.184) * (secs/60));
        } else {
          calories=Math.round(distKm * 40); // fallback ~40kcal/km ciclismo
        }
        if(calories<0) calories='--';
      }
    }

    // ── FASE 1 (0.00→0.18): Vignette — escurece bordos suavemente ──
    {
      const vf=ease2(phase(0.00,0.18));
      const radG=ctx.createRadialGradient(W/2,H/2,H*0.15,W/2,H/2,H*0.75);
      radG.addColorStop(0,'rgba(0,0,0,0)');
      radG.addColorStop(1,`rgba(0,0,0,${vf*0.55})`);
      ctx.fillStyle=radG; ctx.fillRect(0,0,W,H);
    }

    // ── FASE 2 (0.10→0.30): Relâmpago da rota — linha branca pulsante
    if(f>0.10 && f<0.42 && pts && pts.length>1){
      const rf=phase(0.10,0.30);
      const pulse=Math.sin(rf*Math.PI*4)*0.5+0.5;
      if(pulse>0.1){
        ctx.save();
        const lats=pts.map(p=>p.lat),lons=pts.map(p=>p.lon);
        const mnLa=Math.min(...lats),mxLa=Math.max(...lats);
        const mnLo=Math.min(...lons),mxLo=Math.max(...lons);
        const pad=W*0.10;
        const sx=(mxLo-mnLo)>0?(W-pad*2)/(mxLo-mnLo):1;
        const sy=(mxLa-mnLa)>0?(H*0.45-pad*2)/(mxLa-mnLa):1;
        const sc2=Math.min(sx,sy);
        const ox=W/2-(mnLo+(mxLo-mnLo)/2)*sc2;
        const oy=H*0.38-(mnLa+(mxLa-mnLa)/2)*(-sc2);
        const toX=lo=>ox+lo*sc2;
        const toY=la=>oy+la*(-sc2);
        ctx.shadowColor='rgba(255,255,255,0.9)'; ctx.shadowBlur=12*pulse;
        ctx.beginPath();
        ctx.strokeStyle=`rgba(255,255,255,${pulse*0.9})`;
        ctx.lineWidth=3; ctx.lineJoin='round'; ctx.lineCap='round';
        pts.forEach((p,i)=>{ i===0?ctx.moveTo(toX(p.lon),toY(p.lat)):ctx.lineTo(toX(p.lon),toY(p.lat)); });
        ctx.stroke();
        ctx.shadowBlur=0;
        ctx.restore();
      }
    }

    // ── FASE 3 (0.25→0.45): Fundo escurece para revelar stats ──────
    {
      const df=ease2(phase(0.25,0.45));
      ctx.fillStyle=`rgba(0,0,0,${df*0.78})`;
      ctx.fillRect(0,0,W,H);
    }

    // ── FASE 4 (0.28→0.50): Partículas laranja sobem ──────────────
    if(f>0.28){
      const pf=phase(0.28,0.52);
      ctx.save();
      const N=18;
      for(let i=0;i<N;i++){
        const seed=i*137.508;
        const px=(Math.sin(seed)*0.5+0.5)*W;
        const lifeT=(pf+(i/N)*0.4)%1;
        const py=H*(1-lifeT*1.1)-Math.sin(lifeT*Math.PI)*H*0.06;
        const alpha=Math.sin(lifeT*Math.PI)*0.7;
        const radius=Math.round(W*0.008)*(1-lifeT*0.5);
        if(alpha>0.05){
          ctx.beginPath();
          ctx.arc(px,py,radius,0,Math.PI*2);
          const t=i/N;
          const r=Math.round(249+(239-249)*t), g=Math.round(115+(68-115)*t);
          ctx.fillStyle=`rgba(${r},${g},22,${alpha})`;
          ctx.shadowColor=`rgba(249,115,22,${alpha*0.6})`; ctx.shadowBlur=8;
          ctx.fill();
        }
      }
      ctx.shadowBlur=0;
      ctx.restore();
    }

    // ── Layout vertical centralizado — 8 métricas em 4×2 ───────────
    // Fonte adaptativa para caber em mobile e desktop
    const fName = Math.round(W*0.060);   // título menor para dar espaço
    const fVal  = Math.round(W*0.042);   // valor da métrica
    const fLbl  = Math.round(W*0.018);   // label/unidade
    const fBr   = Math.round(W*0.028);   // marca
    const rowH  = fVal*2.0;              // altura de cada linha
    // 4 linhas de stats (2 cols × 4 rows)
    const blockH= fName*1.1
                + fName*0.22
                + rowH*4
                + fBr*2.4;
    const baseY = H/2 - blockH/2 + fName*0.9;

    const titleY  = baseY;
    const lineY   = baseY + fName*0.28;
    const statsY  = lineY + fName*0.38;
    const marcaY  = statsY + rowH*4 + fBr*1.1;

    // ── FASE 5 (0.42→0.60): Título type-on ──────────────────────────
    if(f>0.42){
      const tf=ease3(phase(0.42,0.60));
      const actName=(activity?.name||'Percurso').toUpperCase();
      const chars=Math.ceil(actName.length*tf);
      const partial=actName.slice(0,chars);
      ctx.save();
      ctx.textAlign='center';
      ctx.font=`800 ${fName}px ${FONT}`;
      ctx.fillStyle='rgba(255,255,255,0.97)';
      ctx.shadowColor='rgba(249,115,22,0.5)'; ctx.shadowBlur=20;
      ctx.fillText(partial+(tf<1?'|':''), W/2, titleY);
      ctx.shadowBlur=0;
      if(tf>0.3){
        const lf=ease3((tf-0.3)/0.7);
        const lW=W*0.60*lf;
        const lg=ctx.createLinearGradient(W/2-lW/2,0,W/2+lW/2,0);
        lg.addColorStop(0,'rgba(249,115,22,0)');
        lg.addColorStop(0.15,'rgba(249,115,22,1)');
        lg.addColorStop(0.85,'rgba(249,115,22,1)');
        lg.addColorStop(1,'rgba(249,115,22,0)');
        ctx.strokeStyle=lg; ctx.lineWidth=2;
        ctx.beginPath(); ctx.moveTo(W/2-lW/2,lineY); ctx.lineTo(W/2+lW/2,lineY); ctx.stroke();
      }
      ctx.restore();
    }

    // ── FASE 6 (0.54→0.84): Stats — 2 colunas × 4 linhas ────────────
    // Linha 1: Distância | Duração
    // Linha 2: Vel. Média | Vel. Máx
    // Linha 3: Desnível ↑ | Desnível ↓
    // Linha 4: FC Média | FC Máx  (ou Calorias se sem FC)
    if(f>0.54){
      const hasHRData = avgHR !== '--';
      const stats=[
        // row 0
        {val:totalKm+' km',  lbl:'DISTÂNCIA',   icon:'◈', c:'rgba(125,211,252,1)'},
        {val:duration,        lbl:'DURAÇÃO',      icon:'⏱', c:'rgba(167,139,250,1)'},
        // row 1
        {val:avgSpd+' km/h', lbl:'VEL. MÉDIA',  icon:'⬡', c:'rgba(249,115,22,1)'},
        {val:maxSpd+' km/h', lbl:'VEL. MÁX',   icon:'◆', c:'rgba(248,113,113,1)'},
        // row 2
        {val:elevGain+' m',  lbl:'SUBIDA',      icon:'△', c:'rgba(134,239,172,1)'},
        {val:elevLoss+' m',  lbl:'DESCIDA',     icon:'▽', c:'rgba(94,234,212,1)'},
        // row 3
        {val: hasHRData ? avgHR+' bpm' : calories+' kcal',
         lbl: hasHRData ? 'FC MÉDIA' : 'CALORIAS', icon: hasHRData ? '♥' : '🔥',
         c:'rgba(251,146,60,1)'},
        {val: hasHRData ? maxHR+' bpm' : '--',
         lbl: hasHRData ? 'FC MÁX' : '',           icon: hasHRData ? '♥' : '',
         c:'rgba(248,113,113,1)'},
      ];
      // 2 colunas: esq em W*0.27, dir em W*0.73
      const colCX = [W*0.27, W*0.73];
      const fIco  = Math.round(W*0.020);

      ctx.save();
      stats.forEach((s,i)=>{
        if(!s.val||s.val==='--'&&!s.lbl) return;
        const delay = 0.54 + (i*0.036);
        const sf = ease3(phase(delay, delay+0.09));
        if(sf<=0) return;
        const col=i%2, row=Math.floor(i/2);
        const cy2 = statsY + row*rowH;
        const slideOff=(1-sf)*W*0.07*(col===0?-1:1);
        const cx2=colCX[col]+slideOff;

        // Separador horizontal subtil entre grupos (após linha 1 e linha 3)
        if(col===0 && (row===2) && sf>0.5){
          ctx.save();
          const sepY=cy2 - rowH*0.38;
          const sepAlpha=sf*0.18;
          ctx.strokeStyle=`rgba(249,115,22,${sepAlpha})`;
          ctx.lineWidth=0.5;
          ctx.beginPath(); ctx.moveTo(W*0.08,sepY); ctx.lineTo(W*0.92,sepY); ctx.stroke();
          ctx.restore();
        }

        ctx.textAlign='center';
        ctx.font=`700 ${fVal}px ${FONT}`;
        const valW=ctx.measureText(s.val).width;
        ctx.font=`600 ${fIco}px ${FONT}`;
        const icoW=ctx.measureText(s.icon).width;
        const totalLineW=icoW + fIco*0.4 + valW;
        const lineStartX=cx2 - totalLineW/2;

        // Ícone colorido
        ctx.fillStyle=s.c.replace(',1)',`,${sf*0.85})`);
        ctx.fillText(s.icon, lineStartX + icoW/2, cy2+fVal*0.65);

        // Valor branco
        ctx.font=`700 ${fVal}px ${FONT}`;
        ctx.fillStyle=`rgba(255,255,255,${sf*0.97})`;
        ctx.shadowColor='rgba(0,0,0,0.9)'; ctx.shadowBlur=5;
        ctx.textAlign='left';
        ctx.fillText(s.val, lineStartX + icoW + fIco*0.4, cy2+fVal*0.65);

        // Label
        ctx.font=`500 ${fLbl}px ${FONT}`;
        ctx.fillStyle=`rgba(255,255,255,${sf*0.40})`;
        ctx.shadowBlur=0;
        ctx.textAlign='center';
        ctx.fillText(s.lbl, cx2, cy2+fVal*0.65+fLbl*1.5);
      });
      ctx.restore();
    }

    // ── FASE 7 (0.84→0.93): Marca GPX Analyzer centrada ─────────────
    if(f>0.84){
      const bf=ease3(phase(0.84,0.93));
      ctx.save();
      ctx.textAlign='center';
      const pulse=0.85+Math.sin(ts*0.003)*0.12;
      ctx.font=`700 ${fBr}px ${FONT}`;
      ctx.fillStyle=`rgba(249,115,22,${bf*0.85*pulse})`;
      ctx.shadowColor='rgba(249,115,22,0.4)'; ctx.shadowBlur=bf*16;
      ctx.fillText('GPX Analyzer', W/2, marcaY);
      ctx.font=`400 ${Math.round(fBr*0.70)}px ${FONT}`;
      ctx.fillStyle=`rgba(255,255,255,${bf*0.42})`;
      ctx.shadowBlur=0;
      ctx.fillText('by Fábio Gomes', W/2, marcaY+fBr*1.15);
      ctx.restore();
    }

    // ── FASE FINAL (0.93→1.00): Fade simples para preto ──────────
    {
      const ff=ease2(phase(0.93,1.00));
      ctx.shadowBlur=0; ctx.shadowColor='transparent';
      ctx.fillStyle=`rgba(0,0,0,${ff})`;
      ctx.fillRect(0,0,W,H);
    }

    // Fecha o save() global
    ctx.restore();
  }

  function _drawMiniMap(ctx,W,H,pts,frac){
    if(!pts||pts.length<2) return;
    const mW=Math.round(W*0.28),mH=Math.round(mW*0.68);
    const mX=W-mW-12,mY=12,r=8;

    ctx.save();
    // Fundo
    ctx.beginPath();
    ctx.moveTo(mX+r,mY);ctx.lineTo(mX+mW-r,mY);ctx.arcTo(mX+mW,mY,mX+mW,mY+r,r);
    ctx.lineTo(mX+mW,mY+mH-r);ctx.arcTo(mX+mW,mY+mH,mX+mW-r,mY+mH,r);
    ctx.lineTo(mX+r,mY+mH);ctx.arcTo(mX,mY+mH,mX,mY+mH-r,r);
    ctx.lineTo(mX,mY+r);ctx.arcTo(mX,mY,mX+r,mY,r);ctx.closePath();
    ctx.fillStyle='rgba(4,6,16,0.8)';ctx.fill();
    ctx.strokeStyle='rgba(249,115,22,0.25)';ctx.lineWidth=1;ctx.stroke();
    ctx.clip();

    const lats=pts.map(p=>p.lat),lons=pts.map(p=>p.lon);
    const mnLa=Math.min(...lats),mxLa=Math.max(...lats),mnLo=Math.min(...lons),mxLo=Math.max(...lons);
    const pad=8,sX=(mW-pad*2)/Math.max(mxLo-mnLo,1e-5),sY=(mH-pad*2)/Math.max(mxLa-mnLa,1e-5);
    const toM=(la,lo)=>({x:mX+pad+(lo-mnLo)*sX,y:mY+mH-pad-(la-mnLa)*sY});

    // Rota completa
    ctx.beginPath();ctx.strokeStyle='rgba(255,255,255,0.12)';ctx.lineWidth=1.5;
    pts.forEach((p,i)=>{const{x,y}=toM(p.lat,p.lon);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);});ctx.stroke();

    // Parte percorrida
    const done=Math.min(Math.floor(frac*pts.length),pts.length-1);
    if(done>0){
      ctx.beginPath();ctx.strokeStyle='#f97316';ctx.lineWidth=2.5;
      for(let i=0;i<=done;i++){const{x,y}=toM(pts[i].lat,pts[i].lon);i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);}
      ctx.stroke();
    }

    // Ponto atual
    const cur=pts[done];const{x,y}=toM(cur.lat,cur.lon);
    ctx.beginPath();ctx.arc(x,y,5,0,Math.PI*2);
    ctx.fillStyle='#fff';ctx.shadowColor='#f97316';ctx.shadowBlur=6;ctx.fill();
    ctx.shadowBlur=0;

    ctx.restore();
  }

  function _cleanupFlyover(){
    window._flyPtsRef=null;
    _flyActive=false;_flyPaused=false;_flyRecording=false;
    if(_flyRAF){cancelAnimationFrame(_flyRAF);_flyRAF=null;}
    if(_flyMap){try{_flyMap.remove();}catch(e){}  _flyMap=null;}
    if(_flyOverlay&&_flyOverlay.parentNode){_flyOverlay.parentNode.removeChild(_flyOverlay);_flyOverlay=null;}
    _flyCompCanvas=null;_flyCompCtx=null;
    if(_trackPoints&&map){
      try{map.fitBounds(L.latLngBounds(_trackPoints.map(p=>[p.lat,p.lon])),{padding:[40,40]});}catch(e){}
    }
    removePositionMarker();
  }

  function stopFlyover(){
    if(_flyRec&&_flyRec.state!=='inactive') _flyRec.stop();
    _cleanupFlyover();
  }

  return{init,drawRoute,setColorMode,setTileStyle,updatePositionMarker,removePositionMarker,invalidate,fitRoute,startFlyover,stopFlyover};
})();

if(typeof module!=='undefined')module.exports=GPXMap;
