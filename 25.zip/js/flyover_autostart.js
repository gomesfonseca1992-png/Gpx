// ── Auto-arrancar flyover via ?flyover=1 ─────────────────────────────
// Colar este bloco no analysis.html, DENTRO da função renderAnalysis(),
// logo APÓS a linha onde o mapa já está pronto e os dados carregados.
// Exemplo de onde colar:
//   await renderAnalysis(data);   ← já existe
//   _checkFlyoverAutostart();     ← adicionar esta chamada
//
// E adicionar a função abaixo fora do renderAnalysis (nível global do script):

function _checkFlyoverAutostart() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('flyover') !== '1') return;

  // Pequeno delay para o mapa terminar de renderizar
  setTimeout(() => {
    // Procurar o botão de flyover e clicar, OU chamar diretamente
    const flyBtn = document.getElementById('btnFlyover')
                || document.querySelector('[onclick*="flyover"]')
                || document.querySelector('[onclick*="Flyover"]');
    if (flyBtn) {
      flyBtn.click();
    } else if (window.MapModule && window.MapModule.startFlyover) {
      // Chamar diretamente se o botão não existir
      window.MapModule.startFlyover({
        activity: window.activityData || {},
        duration: 20,
        speed: 1,
        zoom: 14,
      });
    }
  }, 1200);
}
