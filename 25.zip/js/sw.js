/* =====================================================================
   GPX Analyzer — Service Worker
   Estratégia:
   - Cache-first para assets estáticos (CSS, JS, HTML, ícones)
   - Network-first para Firebase / APIs externas
   - Offline fallback para páginas HTML
   ===================================================================== */

const SW_VERSION   = 'v1.2.0';
const CACHE_STATIC = `gpxa-static-${SW_VERSION}`;
const CACHE_PAGES  = `gpxa-pages-${SW_VERSION}`;

// Assets que ficam em cache imediatamente ao instalar
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/auth.html',
  '/history.html',
  '/analysis.html',
  '/compare.html',
  '/igpsport-import.html',
  '/training-plan.html',
  '/my-plan.html',
  '/recovery-plan.html',
  '/flyover.html',
  '/upload.html',
  '/css/main.css',
  '/js/firebase-config.js',
  '/js/gpx-parser.js',
  '/js/stats.js',
  '/js/gpx-upload.js',
  '/js/charts.js',
  '/js/auth.js',
  '/js/map.js',
  '/js/pwa.js',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

// Domínios que sempre vão à rede (Firebase, CDNs críticos)
const NETWORK_ONLY_PATTERNS = [
  /firestore\.googleapis\.com/,
  /firebase\.googleapis\.com/,
  /identitytoolkit\.googleapis\.com/,
  /securetoken\.googleapis\.com/,
  /firebasestorage\.googleapis\.com/,
];

// CDNs que fazem cache depois do primeiro carregamento
const CDN_CACHE_PATTERNS = [
  /unpkg\.com/,
  /gstatic\.com\/firebasejs/,
  /cdnjs\.cloudflare\.com/,
  /cdn\.jsdelivr\.net/,
];

// CDNs WASM — nunca fazer cache (ficheiros grandes, podem causar problemas de memória)
const WASM_PATTERNS = [
  /ffmpeg-core\.wasm/,
  /ffmpeg-core\.js/,
];

// ── Install: pré-cache dos assets essenciais ──────────────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_STATIC).then(cache => {
      return cache.addAll(PRECACHE_ASSETS).catch(err => {
        // Não falha o install se algum asset não estiver disponível
        console.warn('[SW] Alguns assets não foram pre-cached:', err);
      });
    }).then(() => self.skipWaiting())
  );
});

// ── Activate: limpa caches antigas ────────────────────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_STATIC && k !== CACHE_PAGES)
            .map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

// ── Fetch: estratégia de resposta ──────────────────────────────────────────
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // Ignora requisições não-GET e chrome-extension
  if (request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;

  // Firebase / APIs → sempre rede (sem cache)
  if (NETWORK_ONLY_PATTERNS.some(p => p.test(request.url))) {
    return; // deixa o browser tratar normalmente
  }

  // WASM pesado (FFmpeg) → sempre rede, nunca cache (evita OOM no SW)
  if (WASM_PATTERNS.some(p => p.test(request.url))) {
    return;
  }

  // CDNs externos → cache depois da primeira visita (stale-while-revalidate)
  if (CDN_CACHE_PATTERNS.some(p => p.test(request.url))) {
    event.respondWith(staleWhileRevalidate(CACHE_STATIC, request));
    return;
  }

  // Assets locais (CSS, JS, imagens) → cache-first
  if (
    url.pathname.match(/\.(css|js|png|jpg|jpeg|svg|webp|ico|woff2?)$/) ||
    url.pathname.startsWith('/icons/')
  ) {
    event.respondWith(cacheFirst(CACHE_STATIC, request));
    return;
  }

  // Páginas HTML → network-first com fallback para cache
  if (
    request.headers.get('Accept')?.includes('text/html') ||
    url.pathname.endsWith('.html') ||
    url.pathname === '/'
  ) {
    event.respondWith(networkFirstWithFallback(CACHE_PAGES, request));
    return;
  }

  // Resto → stale-while-revalidate
  event.respondWith(staleWhileRevalidate(CACHE_STATIC, request));
});

// ── Estratégias de cache ───────────────────────────────────────────────────

async function cacheFirst(cacheName, request) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return new Response('Conteúdo não disponível offline', {
      status: 503,
      headers: { 'Content-Type': 'text/plain;charset=utf-8' }
    });
  }
}

async function networkFirstWithFallback(cacheName, request) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cached = await caches.match(request);
    if (cached) return cached;

    // Fallback para index.html se for navegação
    const indexCache = await caches.match('/index.html');
    if (indexCache) return indexCache;

    return new Response(offlinePage(), {
      status: 503,
      headers: { 'Content-Type': 'text/html;charset=utf-8' }
    });
  }
}

async function staleWhileRevalidate(cacheName, request) {
  const cache  = await caches.open(cacheName);
  const cached = await cache.match(request);

  const fetchPromise = fetch(request).then(response => {
    if (response.ok) cache.put(request, response.clone());
    return response;
  }).catch(() => null);

  return cached || fetchPromise;
}

// ── Página de erro offline ─────────────────────────────────────────────────
function offlinePage() {
  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>GPX Analyzer — Offline</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      background: #0f1117;
      color: #e2e8f0;
      font-family: system-ui, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      text-align: center;
      padding: 2rem;
    }
    .icon { font-size: 4rem; margin-bottom: 1.5rem; }
    h1 { font-size: 1.8rem; font-weight: 700; margin-bottom: 0.75rem; color: #f97316; }
    p { color: #94a3b8; line-height: 1.6; max-width: 360px; margin-bottom: 2rem; }
    a {
      background: #f97316;
      color: #fff;
      padding: 0.75rem 2rem;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
    }
  </style>
</head>
<body>
  <div class="icon">📡</div>
  <h1>Sem ligação</h1>
  <p>Parece que estás offline. Verifica a tua ligação à internet e tenta novamente.</p>
  <a href="/">Tentar outra vez</a>
</body>
</html>`;
}
