/**
 * coaching.js — Módulo de Coaching Determinístico
 * GPX Analyzer · Ciclo Fechado: Sugestão → Execução → Upload → Reanálise
 *
 * Dependências: Firebase (db + auth), stats.js (TRIMP_BANDS)
 * Sem IA — toda lógica é determinística e auditável
 */

const DeterministicCoach = (() => {

  // ─── Constantes do modelo Banister ───────────────────────────────────────────
  const K_CTL = 1 - Math.exp(-1 / 42);
  const K_ATL = 1 - Math.exp(-1 / 7);

  // ─── Tipos de sessão (espelho do training-plan.html) ─────────────────────────
  const SESSION_TYPES = {
    rest:     { label: 'Descanso',            icon: '😴', col: '#475569', trimpH: 0,  distH: 0,   elevH: 0   },
    z1:       { label: 'Z1 Recuperação',      icon: '🟢', col: '#94a3b8', trimpH: 20, distH: 22,  elevH: 80  },
    z2:       { label: 'Z2 Base Aeróbica',    icon: '🔵', col: '#38bdf8', trimpH: 35, distH: 26,  elevH: 120 },
    z2long:   { label: 'Z2 Longa',            icon: '🔵', col: '#3b82f6', trimpH: 33, distH: 25,  elevH: 110 },
    z3:       { label: 'Z3 Aeróbico',         icon: '🟡', col: '#22c55e', trimpH: 55, distH: 28,  elevH: 150 },
    tempo:    { label: 'Tempo Z3-Z4',         icon: '🟠', col: '#f59e0b', trimpH: 75, distH: 30,  elevH: 200 },
    interval: { label: 'Intervalos Z4-Z5',    icon: '🔴', col: '#f97316', trimpH: 90, distH: 28,  elevH: 180 },
    climb:    { label: 'Trabalho de Subida',  icon: '🏔️', col: '#a855f7', trimpH: 85, distH: 18,  elevH: 500 },
  };

  // ─── 1. SIMULADOR DE PROJEÇÃO TSB (14 dias) ──────────────────────────────────
  // Dado CTL/ATL atuais e TRIMP do treino proposto (dia 1),
  // projeta CTL/ATL/TSB para os próximos 14 dias (com descanso nos restantes)
  function projectTSB(currentCTL, currentATL, proposedTrimp, restDaysAfter = 13) {
    let CTL = currentCTL;
    let ATL = currentATL;
    const points = [];

    for (let day = 0; day < 14; day++) {
      const trimp = day === 0 ? proposedTrimp : 0;
      CTL += K_CTL * (trimp - CTL);
      ATL += K_ATL * (trimp - ATL);
      points.push({
        day: day + 1,
        CTL: Math.round(CTL * 10) / 10,
        ATL: Math.round(ATL * 10) / 10,
        TSB: Math.round((CTL - ATL) * 10) / 10,
        trimp,
      });
    }
    return points;
  }

  // ─── 2. VERIFICAÇÃO DE SEGURANÇA (anti-overtraining) ─────────────────────────
  // Retorna { safe: bool, reason: string, minTSB: number }
  function isSafeToTrain(projectionPoints, proposedTrimp) {
    const minTSB = Math.min(...projectionPoints.map(p => p.TSB));
    const day1TSB = projectionPoints[0]?.TSB ?? 0;

    if (minTSB < -20) {
      return {
        safe: false,
        reason: `TSB projetado mínimo é ${minTSB.toFixed(1)} — risco de overtraining. O sistema recomenda recuperação.`,
        minTSB,
      };
    }
    if (proposedTrimp > 500) {
      return {
        safe: false,
        reason: `Carga proposta (TRIMP ${proposedTrimp}) é extrema. Divide em 2 sessões ou reduz a intensidade.`,
        minTSB,
      };
    }
    return { safe: true, reason: null, minTSB };
  }

  // ─── 3. AJUSTE BIOFEEDBACK (sono + sensação) ─────────────────────────────────
  // Retorna fator entre 0.28 e 1.32 que escala o TRIMP base
  function bioFeedbackFactor(sleep, feeling) {
    const s = Math.max(1, Math.min(10, sleep || 5));
    const f = Math.max(1, Math.min(10, feeling || 5));
    // fator_bio = (sono + sensação) / 20  → 0.1 a 1.0
    // TRIMP_ajustado = TRIMP_base × (0.6 + fator_bio × 0.8)  → 0.68 a 1.40
    const factor = ((s + f) / 20);
    return Math.round((0.6 + factor * 0.8) * 100) / 100;
  }

  // ─── 4. PRESCRITOR DE TRIMP ───────────────────────────────────────────────────
  // Decide o TRIMP alvo baseado no estado PMC + biofeedback
  // Retorna { trimpBase, sessType, rationale }
  function prescribeTrimp(currentCTL, currentATL, currentTSB, sleep, feeling) {
    const bio = bioFeedbackFactor(sleep, feeling);
    const bioScore = (sleep + feeling) / 2; // 1–10

    let trimpBase, sessType, rationale;

    // ── Decisão pelo TSB ──────────────────────────────────────────────────────
    if (bioScore <= 4) {
      // Mal-estar / sono péssimo — forçar recuperação independentemente do TSB
      trimpBase = Math.round(currentCTL * 0.4);
      sessType  = 'z1';
      rationale = `Biofeedback baixo (sono ${sleep}/10, sensação ${feeling}/10). Recuperação ativa.`;
    } else if (currentTSB < -15) {
      // Muito cansada
      trimpBase = Math.round(currentCTL * 0.5);
      sessType  = 'z1';
      rationale = `TSB ${currentTSB.toFixed(1)} — acúmulo de fadiga. Sessão leve para recuperar.`;
    } else if (currentTSB < -5) {
      // Ligeiramente fatigada
      trimpBase = Math.round(currentCTL * 0.75);
      sessType  = 'z2';
      rationale = `TSB ${currentTSB.toFixed(1)} — fadiga moderada. Base aeróbica Z2 para manter sem acumular.`;
    } else if (currentTSB >= -5 && currentTSB < 5) {
      // Forma neutra
      trimpBase = Math.round(currentCTL * 1.0);
      sessType  = 'z2';
      rationale = `TSB neutro (${currentTSB.toFixed(1)}). Sessão Z2 de desenvolvimento base.`;
    } else if (currentTSB >= 5 && currentTSB < 15) {
      // Boa forma
      trimpBase = Math.round(currentCTL * 1.2);
      sessType  = bioScore >= 7 ? 'z3' : 'z2';
      rationale = `TSB positivo (${currentTSB.toFixed(1)}) — boa forma. ${bioScore >= 7 ? 'Z3 aeróbico.' : 'Z2 longa para consolidar.'}`;
    } else {
      // TSB > 15 — muito descansada, janela de qualidade
      trimpBase = Math.round(currentCTL * 1.4);
      sessType  = bioScore >= 7 ? 'interval' : 'tempo';
      rationale = `TSB elevado (${currentTSB.toFixed(1)}) — janela de qualidade. ${bioScore >= 7 ? 'Intervalos Z4-Z5.' : 'Tempo Z3-Z4.'}`;
    }

    // Aplica fator biofeedback
    const trimpAjustado = Math.max(20, Math.round(trimpBase * bio));

    // Garante mínimo sensato
    const trimpFinal = Math.max(30, Math.min(500, trimpAjustado));

    return {
      trimpBase,
      trimpFinal,
      bio,
      sessType,
      rationale,
      bioScore,
    };
  }

  // ─── 5. CONVERSOR TRIMP → especificação do treino ────────────────────────────
  // Estima km, altimetria e zonas com base no TRIMP alvo e no histórico calibrado
  function trimpToWorkoutSpec(trimp, sessType, trimpPerKm, trimpPerElev) {
    const st = SESSION_TYPES[sessType] || SESSION_TYPES.z2;

    // Duração estimada em horas
    const hoursEst = st.trimpH > 0 ? trimp / st.trimpH : 1.5;

    // km e desnível estimados
    const distEst = Math.round(st.distH * hoursEst * 10) / 10;
    const elevEst = Math.round(st.elevH * hoursEst);

    // Zonas de treino sugeridas
    const zonaMap = {
      rest:     [],
      z1:       ['Z1'],
      z2:       ['Z2'],
      z2long:   ['Z2'],
      z3:       ['Z2', 'Z3'],
      tempo:    ['Z3', 'Z4'],
      interval: ['Z4', 'Z5'],
      climb:    ['Z3', 'Z4'],
    };

    return {
      hoursEst: Math.round(hoursEst * 10) / 10,
      distEst,
      elevEst,
      zonas: zonaMap[sessType] || ['Z2'],
      label: st.label,
      icon: st.icon,
      col: st.col,
    };
  }

  // ─── 6. BUSCA DE ATIVIDADE SIMILAR (histórico Firebase) ──────────────────────
  // Retorna a atividade mais próxima do TRIMP alvo (dentro de ±tolerância)
  function findSimilarActivity(activities, targetTrimp, tolerance = 0.25) {
    if (!activities || activities.length === 0) return null;

    const withTrimp = activities.filter(a => a.trimp > 0 && a.chartData?.elevation?.length > 10);
    if (withTrimp.length === 0) return null;

    const lower = targetTrimp * (1 - tolerance);
    const upper = targetTrimp * (1 + tolerance);

    // Filtra dentro da tolerância e ordena pela proximidade ao TRIMP alvo
    const candidates = withTrimp
      .filter(a => a.trimp >= lower && a.trimp <= upper)
      .sort((a, b) => Math.abs(a.trimp - targetTrimp) - Math.abs(b.trimp - targetTrimp));

    return candidates[0] || null;
  }

  // ─── 7. ESTADO DO CICLO FECHADO (Firebase) ───────────────────────────────────

  // Lê o estado atual do coaching (treino_pendente, sugestão, etc.)
  async function loadCoachingState(db, uid) {
    try {
      const doc = await db.collection('users').doc(uid)
        .collection('coaching').doc('state').get();
      return doc.exists ? doc.data() : { treino_pendente: false, suggestion: null };
    } catch (e) {
      console.error('[Coaching] Erro ao carregar estado:', e);
      return { treino_pendente: false, suggestion: null };
    }
  }

  // Salva uma nova sugestão e ativa a trava
  async function saveSuggestion(db, uid, suggestion) {
    const state = {
      treino_pendente: true,
      suggestion: {
        ...suggestion,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      },
      lastUpdated: firebase.firestore.FieldValue.serverTimestamp(),
    };
    await db.collection('users').doc(uid)
      .collection('coaching').doc('state').set(state, { merge: true });
    return state;
  }

  // Salva bem-estar diário (sono + sensação) para histórico
  async function saveDailyWellness(db, uid, sleep, feeling, notes = '') {
    const today = new Date().toISOString().slice(0, 10);
    await db.collection('users').doc(uid)
      .collection('wellness').doc(today).set({
        date: today,
        sleep: Math.round(sleep),
        feeling: Math.round(feeling),
        notes,
        savedAt: firebase.firestore.FieldValue.serverTimestamp(),
      });
  }

  // Carrega histórico de bem-estar (últimos N dias)
  async function loadWellnessHistory(db, uid, days = 30) {
    try {
      const snap = await db.collection('users').doc(uid)
        .collection('wellness')
        .orderBy('date', 'desc')
        .limit(days)
        .get();
      return snap.docs.map(d => d.data());
    } catch (e) {
      return [];
    }
  }

  // Confirma treino executado e liberta a trava
  async function confirmWorkout(db, uid, activityId) {
    await db.collection('users').doc(uid)
      .collection('coaching').doc('state').set({
        treino_pendente: false,
        lastConfirmedAt: firebase.firestore.FieldValue.serverTimestamp(),
        lastConfirmedActivityId: activityId,
        suggestion: null,
      }, { merge: true });
  }

  // ─── 8. FUNÇÃO PRINCIPAL: gera sugestão completa ─────────────────────────────
  // Orquestra todos os passos e retorna o objeto de sugestão completo
  function generateSuggestion(currentCTL, currentATL, currentTSB, sleep, feeling, activities, trimpPerKm, trimpPerElev) {
    // Passo 1: prescrição
    const prescription = prescribeTrimp(currentCTL, currentATL, currentTSB, sleep, feeling);

    // Passo 2: especificação do treino
    const spec = trimpToWorkoutSpec(prescription.trimpFinal, prescription.sessType, trimpPerKm, trimpPerElev);

    // Passo 3: projeção TSB 14 dias
    const projection = projectTSB(currentCTL, currentATL, prescription.trimpFinal);

    // Passo 4: verificação de segurança
    const safety = isSafeToTrain(projection, prescription.trimpFinal);

    // Se não for seguro, reduz para Z1 recuperação
    let finalPrescription = prescription;
    let finalSpec = spec;
    let finalProjection = projection;

    if (!safety.safe) {
      finalPrescription = {
        ...prescription,
        trimpFinal: Math.round(currentCTL * 0.3),
        sessType: 'z1',
        rationale: `⚠️ ${safety.reason}`,
        forced: true,
      };
      finalSpec = trimpToWorkoutSpec(finalPrescription.trimpFinal, 'z1', trimpPerKm, trimpPerElev);
      finalProjection = projectTSB(currentCTL, currentATL, finalPrescription.trimpFinal);
    }

    // Passo 5: atividade histórica similar
    const similar = findSimilarActivity(activities, finalPrescription.trimpFinal);

    // Passo 6: data do treino (hoje)
    const today = new Date().toISOString().slice(0, 10);

    return {
      date: today,
      trimpAlvo: finalPrescription.trimpFinal,
      trimpBase: finalPrescription.trimpBase,
      bio: finalPrescription.bio,
      bioScore: finalPrescription.bioScore,
      sessType: finalPrescription.sessType,
      rationale: finalPrescription.rationale,
      forced: finalPrescription.forced || false,
      spec: finalSpec,
      projection: finalProjection,
      safety,
      similar: similar ? {
        id: similar.id,
        name: similar.name || 'Atividade sem nome',
        trimp: similar.trimp,
        distanceKm: similar.distanceKm,
        elevGain: similar.elevGain,
        date: similar.date,
        hasRoute: !!(similar.chartData?.elevation?.length > 0),
      } : null,
      // Inputs biofeedback para guardar
      sleep,
      feeling,
    };
  }

  // ─── Exporta API pública ──────────────────────────────────────────────────────
  return {
    projectTSB,
    isSafeToTrain,
    bioFeedbackFactor,
    prescribeTrimp,
    trimpToWorkoutSpec,
    findSimilarActivity,
    generateSuggestion,
    loadCoachingState,
    saveSuggestion,
    saveDailyWellness,
    loadWellnessHistory,
    confirmWorkout,
    SESSION_TYPES,
  };

})();

if (typeof module !== 'undefined') module.exports = DeterministicCoach;
