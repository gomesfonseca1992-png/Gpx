/**
 * GPX Upload — guarda atividade no Firestore (sem Firebase Storage)
 * Versão adaptada para plano Spark (sem Storage)
 *
 * Fluxo:
 *   1. Parse GPX no browser
 *   2. Calcula stats
 *   3. Guarda tudo no Firestore (sem upload de ficheiro)
 *   4. Retorna activityId para redirecionar para analysis.html
 */

const GPXUpload = (() => {

  // ─── Gera ID de sessão anónima (persiste no localStorage) ───────────────────
  function getSessionId() {
    let sid = localStorage.getItem('gpx_session_id');
    if (!sid) {
      sid = 'anon_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9);
      localStorage.setItem('gpx_session_id', sid);
    }
    return sid;
  }

  // ─── Salva atividade no Firestore (sem Storage) ──────────────────────────────
  async function saveActivity({ stats, fileName, trackPoints }) {
    const db      = firebase.firestore();
    const auth    = firebase.auth();
    const user    = auth.currentUser;
    const uid     = user ? user.uid : null;
    const session = user ? null     : getSessionId();

    const activityRef = db.collection('activities').doc();
    const activityId  = activityRef.id;

    // Guarda trackpoints compactos para o mapa (max 800 pontos)
    const total = trackPoints.length;
    const step  = total <= 800 ? 1 : Math.floor(total / 800);
    const compactTrack = [];
    for (let i = 0; i < total; i += step) {
      const p = trackPoints[i];
      const pt = {
        a: Math.round(p.lat * 100000) / 100000,
        o: Math.round(p.lon * 100000) / 100000,
        e: p.ele     !== null ? Math.round(p.ele) : null,
        s: p.speed   !== null ? Math.round(p.speed * 10) / 10 : null,
        d: Math.round(p.distFromStart),
        t: p.time    ?? null,   // timestamp — necessário para calcHRZones/TRIMP
      };
      if (p.hr      !== null && p.hr      !== undefined) pt.h = p.hr;
      if (p.cadence !== null && p.cadence !== undefined) pt.c = p.cadence;
      if (p.power   !== null && p.power   !== undefined) pt.p = p.power;
      if (p.temp    !== null && p.temp    !== undefined) pt.tmp = Math.round(p.temp*10)/10;
      compactTrack.push(pt);
    }

    const doc = {
      activityId,
      userId:    uid,
      sessionId: session,
      fileName:  fileName || 'atividade.gpx',

      name:       stats.name,
      sport:      stats.sport,
      date:       stats.date
        ? firebase.firestore.Timestamp.fromDate(new Date(stats.date))
        : firebase.firestore.FieldValue.serverTimestamp(),
      difficulty: stats.difficulty,

      distanceKm:        stats.distanceKm,
      distanceM:         stats.distanceM,
      durationTotal:     stats.durationTotal,
      durationMoving:    stats.durationMoving,
      durationStopped:   stats.durationStopped,
      durationFormatted: stats.durationFormatted,

      avgSpeedKmh: stats.avgSpeedKmh,
      maxSpeedKmh: stats.maxSpeedKmh,
      p95SpeedKmh: stats.p95SpeedKmh,
      avgPace:     stats.avgPace,
      avgPaceRaw:  stats.avgPaceRaw,

      elevGain:     stats.elevGain,
      elevLoss:     stats.elevLoss,
      maxElevation: stats.maxElevation,
      minElevation: stats.minElevation,
      elevRange:    stats.elevRange,

      pointCount: stats.pointCount,

      // FC / Cadência / Potência
      hasHR:       stats.hasHR      || false,
      hasCadence:  stats.hasCadence || false,
      hasPower:    stats.hasPower   || false,
      avgHR:       stats.avgHR      || null,
      maxHR:       stats.maxHR      || null,
      avgCadence:  stats.avgCadence || null,
      maxCadence:  stats.maxCadence  || null,
      avgPower:    stats.avgPower   || null,

      // Esforço / Recuperação
      trimp:         stats.trimp         || null,
      recoveryHours: stats.recoveryHours || null,

      // Sem Storage
      gpxStoragePath: null,
      gpxDownloadUrl: null,

      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
    };

    // Guarda documento principal
    await activityRef.set(doc);

    // Guarda chartData + trackpoints compactos em subcoleção
    if (stats.chartData) {
      await activityRef.collection('chartData').doc('main').set({
        elevation:    stats.chartData.elevation    || [],
        speed:        stats.chartData.speed        || [],
        hr:           stats.chartData.hr           || [],
        cadence:      stats.chartData.cadence      || [],
        power:        stats.chartData.power        || [],
        temperature:  stats.chartData.temperature  || [],
        splits:       stats.splits              || [],
        compactTrack,
        savedAt: firebase.firestore.FieldValue.serverTimestamp(),
      });
    }

    // Se user autenticado, regista na subcoleção do utilizador
    if (uid) {
      await db.collection('users').doc(uid)
        .collection('activities').doc(activityId)
        .set({
          activityId,
          name:              stats.name,
          sport:             stats.sport,
          date:              doc.date,
          distanceKm:        stats.distanceKm,
          durationFormatted: stats.durationFormatted,
          durationMoving:    stats.durationMoving    || null,
          durationTotal:     stats.durationTotal     || null,
          elevGain:          stats.elevGain          || null,
          elevLoss:          stats.elevLoss          || null,
          maxElevation:      stats.maxElevation      || null,
          avgSpeedKmh:       stats.avgSpeedKmh       || null,
          maxSpeedKmh:       stats.maxSpeedKmh       || null,
          avgPaceRaw:        stats.avgPaceRaw        || null,
          hasHR:             stats.hasHR             || false,
          hasCadence:        stats.hasCadence        || false,
          hasTemp:           stats.hasTemp           || false,
          avgHR:             stats.avgHR             || null,
          maxHR:             stats.maxHR             || null,
          avgCadence:        stats.avgCadence        || null,
          maxCadence:        stats.maxCadence        || null,
          avgTemp:           stats.avgTemp           || null,
          minTemp:           stats.minTemp           || null,
          maxTemp:           stats.maxTemp           || null,
          difficulty:        stats.difficulty        || null,
          trimp:             stats.trimp             || null,
          recoveryHours:     stats.recoveryHours     || null,
          createdAt:         firebase.firestore.FieldValue.serverTimestamp(),
        });
    }

    return activityId;
  }

  // ─── Processo completo: parse → stats → save Firestore ──────────────────────
  async function processAndUpload(file, { onProgress, onStatus } = {}) {
    const status = msg => { if (onStatus) onStatus(msg); };

    try {
      // 1. Parse GPX
      status('A ler ficheiro...');
      if (onProgress) onProgress(15);
      const parsed = await GPXParser.parseFile(file);

      // 2. Calcular stats
      status('A calcular estatísticas...');
      if (onProgress) onProgress(40);
      const stats = GPXStats.calculate(parsed);

      // Calcular zonas FC / recuperação
      if (stats.hasHR && parsed.trackPoints?.length) {
        try {
          const _hz = GPXStats.calcHRZones(parsed.trackPoints);
          if (_hz) {
            stats.recoveryHours = _hz.recoveryHours ?? _hz.effortLevel?.rec ?? null;
            stats.trimp         = _hz.trimp ? Math.round(_hz.trimp) : null;
            if (!stats.difficulty && _hz.effortLevel) stats.difficulty = _hz.effortLevel;
          }
        } catch(e) { console.warn('hrZones no upload:', e); }
      }

      // Refina sport pela velocidade se desconhecido
      if (stats.sport === 'unknown' && stats.avgSpeedKmh) {
        const s = stats.avgSpeedKmh;
        parsed.metadata.sport = stats.sport =
          s > 15 ? 'cycling' : s > 7 ? 'running' : 'hiking';
      }

      // 3. Guarda no Firestore
      status('A guardar atividade...');
      if (onProgress) onProgress(70);

      const activityId = await saveActivity({
        stats,
        fileName:    file.name,
        trackPoints: parsed.trackPoints,
      });

      // ── Coaching: verifica trava pendente e confirma se TRIMP bate ──────────
      try {
        const user = firebase.auth().currentUser;
        if (user && typeof DeterministicCoach !== 'undefined') {
          const db           = firebase.firestore();
          const coachState   = await DeterministicCoach.loadCoachingState(db, user.uid);
          if (coachState?.treino_pendente && coachState?.suggestion) {
            const targetTrimp  = coachState.suggestion.trimpAlvo || 0;
            const actualTrimp  = stats.trimp || 0;
            // Confirma se TRIMP real está dentro de ±35% do alvo (margem generosa)
            const diff = targetTrimp > 0
              ? Math.abs(actualTrimp - targetTrimp) / targetTrimp
              : 1;
            if (diff <= 0.35) {
              await DeterministicCoach.confirmWorkout(db, user.uid, activityId);
              status('Treino confirmado! Ciclo fechado ✅');
              // Sinaliza para a UI mostrar a mensagem de confirmação
              if (typeof window !== 'undefined') {
                window._coachingConfirmed = {
                  activityId,
                  trimpAlvo:  targetTrimp,
                  trimpReal:  actualTrimp,
                  sessType:   coachState.suggestion.sessType,
                };
              }
            }
            // Se TRIMP muito diferente, não confirma automaticamente — deixa o utilizador decidir
          }
        }
      } catch (coachErr) {
        // Não bloqueia o upload por erro no coaching
        console.warn('[GPXUpload] Coaching hook falhou (não crítico):', coachErr);
      }

      if (onProgress) onProgress(100);
      status('Concluído!');

      return { activityId, stats, parsed };

    } catch (err) {
      console.error('[GPXUpload] Erro:', err);
      throw err;
    }
  }

  // ─── Carrega atividade do Firestore por ID ───────────────────────────────────
  async function loadActivity(activityId) {
    if (!activityId) throw new Error('ID de atividade em falta.');

    const db  = firebase.firestore();
    const ref = db.collection('activities').doc(activityId);

    let docSnap, chartSnap;
    try {
      [docSnap, chartSnap] = await Promise.all([
        ref.get(),
        ref.collection('chartData').doc('main').get(),
      ]);
    } catch (err) {
      if (err.code === 'permission-denied') {
        throw new Error('Sem permissão. Verifica as Firestore Rules no Firebase Console.');
      }
      if (err.code === 'unavailable') {
        throw new Error('Sem ligação à internet. Tenta novamente.');
      }
      throw new Error('Erro ao carregar: ' + err.message);
    }

    if (!docSnap.exists) {
      throw new Error('Atividade não encontrada (ID: ' + activityId.slice(0,12) + '...).');
    }

    const data = docSnap.data();

    // Reconstrói trackPoints com todos os campos (HR, cadência, potência)
    let trackPoints = null;
    if (chartSnap.exists && chartSnap.data().compactTrack) {
      trackPoints = chartSnap.data().compactTrack.map(p => ({
        lat:           p.a,
        lon:           p.o,
        ele:           p.e   ?? null,
        speed:         p.s   ?? null,
        distFromStart: p.d   ?? 0,
        hr:            p.h   ?? null,
        cadence:       p.c   ?? null,
        power:         p.p   ?? null,
        time:          p.t   ?? null,
      }));
    }

    return {
      ...data,
      chartData:   chartSnap.exists ? chartSnap.data() : null,
      trackPoints,
    };
  }

  // ─── Lista atividades do utilizador atual ────────────────────────────────────
  async function listUserActivities(limit = 20) {
    const db   = firebase.firestore();
    const auth = firebase.auth();
    const user = auth.currentUser;

    let query;

    if (user) {
      query = db.collection('users').doc(user.uid)
        .collection('activities')
        .orderBy('date', 'desc')
        .limit(limit);
    } else {
      const session = getSessionId();
      query = db.collection('activities')
        .where('sessionId', '==', session)
        .orderBy('date', 'desc')
        .limit(limit);
    }

    const snap = await query.get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  }

  // ─── Apaga atividade ─────────────────────────────────────────────────────────
  // Actualiza campos de uma atividade existente
  async function updateActivity(activityId, fields) {
    if (!activityId) throw new Error('ID em falta');
    const db  = firebase.firestore();
    const ref = db.collection('activities').doc(activityId);
    await ref.update({ ...fields, updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
  }

  async function deleteActivity(activityId) {
    const db   = firebase.firestore();
    const auth = firebase.auth();
    const user = auth.currentUser;
    const ref  = db.collection('activities').doc(activityId);
    const doc  = await ref.get();

    if (!doc.exists) throw new Error('Atividade não encontrada.');

    const data    = doc.data();
    const isOwner = user
      ? data.userId === user.uid
      : data.sessionId === getSessionId();

    if (!isOwner) throw new Error('Sem permissão para apagar esta atividade.');

    // ── 1. Apagar chartData e documento principal ───────────────────────────
    await ref.collection('chartData').doc('main').delete().catch(() => {});
    await ref.delete();

    // ── 2. Apagar referência na subcoleção do utilizador ────────────────────
    if (user) {
      await db.collection('users').doc(user.uid)
        .collection('activities').doc(activityId)
        .delete().catch(() => {});
    }

    // ── 3. Cascata: remover tentativas desta atividade dos segmentos ────────
    // Os segmentos ficam no banco (são persistentes), mas as tentativas
    // associadas a esta atividade têm de ser removidas e o ranking recalculado.
    if (user) {
      try {
        const segsSnap = await db.collection('users').doc(user.uid)
          .collection('segments').get();

        const batch = db.batch();
        let hasChanges = false;

        segsSnap.docs.forEach(segDoc => {
          const seg = segDoc.data();
          const attempts = seg.attempts || [];
          // Filtrar fora a tentativa desta atividade
          const filtered = attempts.filter(a => a.activityId !== activityId);
          // Só atualizar se houve mudança
          if (filtered.length !== attempts.length) {
            batch.update(segDoc.ref, { attempts: filtered });
            hasChanges = true;
          }
        });

        if (hasChanges) await batch.commit();
      } catch(e) {
        // Não falhar o delete principal por causa dos segmentos
        console.warn('[deleteActivity] Erro ao limpar segmentos:', e);
      }
    }

    return true;
  }

  return {
    processAndUpload,
    loadActivity,
    listUserActivities,
    deleteActivity,
    updateActivity,
    getSessionId,
  };
})();

if (typeof module !== 'undefined') module.exports = GPXUpload;
