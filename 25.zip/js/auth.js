/**
 * auth.js — Lógica de autenticação Firebase
 * Fase 4 — GPX Analyzer Platform
 *
 * Funcionalidades:
 *  - Login com Google (popup)
 *  - Login com Email/Password
 *  - Registo com Email/Password
 *  - Logout
 *  - Reset de password
 *  - Migração de atividades anónimas para conta
 *  - onAuthStateChanged global
 */

const GPXAuth = (() => {

  const auth = () => firebase.auth();
  const db   = () => firebase.firestore();

  // ─── Google Login ──────────────────────────────────────────────────────
  async function loginWithGoogle() {
    const provider = new firebase.auth.GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const result = await auth().signInWithPopup(provider);
    await ensureUserProfile(result.user);
    await migrateAnonymousActivities(result.user);
    return result.user;
  }

  // ─── Email/Password ────────────────────────────────────────────────────
  async function loginWithEmail(email, password) {
    const result = await auth().signInWithEmailAndPassword(email, password);
    await migrateAnonymousActivities(result.user);
    return result.user;
  }

  async function registerWithEmail(email, password, displayName) {
    const result = await auth().createUserWithEmailAndPassword(email, password);
    if (displayName) {
      await result.user.updateProfile({ displayName });
    }
    await ensureUserProfile(result.user, displayName);
    await migrateAnonymousActivities(result.user);
    return result.user;
  }

  async function logout() {
    await auth().signOut();
  }

  async function resetPassword(email) {
    await auth().sendPasswordResetEmail(email);
  }

  // ─── Cria perfil no Firestore se não existir ───────────────────────────
  async function ensureUserProfile(user, displayName) {
    const ref = db().collection('users').doc(user.uid);
    const doc = await ref.get();
    if (!doc.exists) {
      await ref.set({
        uid:         user.uid,
        displayName: displayName || user.displayName || '',
        email:       user.email,
        photoURL:    user.photoURL || null,
        createdAt:   firebase.firestore.FieldValue.serverTimestamp(),
        updatedAt:   firebase.firestore.FieldValue.serverTimestamp(),
      });
    }
  }

  // ─── Migra atividades anónimas (sessionId) para o uid da conta ─────────
  async function migrateAnonymousActivities(user) {
    const sessionId = localStorage.getItem('gpx_session_id');
    if (!sessionId) return;

    try {
      const snap = await db().collection('activities')
        .where('sessionId', '==', sessionId)
        .where('userId', '==', null)
        .limit(50)
        .get();

      if (snap.empty) return;

      const batch = db().batch();

      snap.docs.forEach(doc => {
        // Atualiza userId no documento principal
        batch.update(doc.ref, {
          userId:    user.uid,
          sessionId: null,
          updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
        });

        // Cria referência na subcoleção do utilizador
        const data = doc.data();
        const userActivityRef = db()
          .collection('users').doc(user.uid)
          .collection('activities').doc(doc.id);

        batch.set(userActivityRef, {
          activityId:        doc.id,
          name:              data.name || 'Atividade',
          sport:             data.sport || 'unknown',
          date:              data.date || null,
          distanceKm:        data.distanceKm || null,
          durationFormatted: data.durationFormatted || null,
          elevGain:          data.elevGain || null,
          createdAt:         data.createdAt || firebase.firestore.FieldValue.serverTimestamp(),
        });
      });

      await batch.commit();
      console.log(`[Auth] ${snap.size} atividade(s) migrada(s) para conta.`);

    } catch (err) {
      console.warn('[Auth] Erro na migração:', err);
    }
  }

  // ─── Observador de estado ──────────────────────────────────────────────
  function onAuthChange(callback) {
    return auth().onAuthStateChanged(callback);
  }

  // ─── Utilizador atual ──────────────────────────────────────────────────
  function currentUser() {
    return auth().currentUser;
  }

  // ─── Mensagens de erro Firebase → português ────────────────────────────
  function translateError(code) {
    const map = {
      'auth/user-not-found':        'Utilizador não encontrado.',
      'auth/wrong-password':        'Password incorreta.',
      'auth/email-already-in-use':  'Este email já está registado.',
      'auth/weak-password':         'Password demasiado fraca (mínimo 6 caracteres).',
      'auth/invalid-email':         'Email inválido.',
      'auth/too-many-requests':     'Demasiadas tentativas. Tenta mais tarde.',
      'auth/popup-closed-by-user':  'Login cancelado.',
      'auth/network-request-failed':'Erro de rede. Verifica a ligação.',
      'auth/invalid-credential':    'Credenciais inválidas.',
    };
    return map[code] || 'Ocorreu um erro. Tenta novamente.';
  }

  return {
    loginWithGoogle,
    loginWithEmail,
    registerWithEmail,
    logout,
    resetPassword,
    onAuthChange,
    currentUser,
    translateError,
    ensureUserProfile,
  };
})();

if (typeof module !== 'undefined') module.exports = GPXAuth;
