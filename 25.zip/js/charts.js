/**
 * charts.js v7 — Professional Sport Analytics
 * Inspiração visual: Garmin Connect, WHOOP, Intervals.icu
 *
 * Princípios implementados:
 * 1. Gráficos com maior altura (240px) → mais resolução visual para ler dados
 * 2. Gradientes com profundidade real (3 color stops)
 * 3. Linhas mais finas e precisas (borderWidth: 1.5) → estilo data-viz profissional
 * 4. Grid horizontal sutil — remove grid vertical (ruído visual)
 * 5. Tooltips com contexto completo: distância, valor, delta em relação à média
 * 6. Eixo X sem labels intermediários desnecessários (maxTicksLimit: 5)
 * 7. Padding interno adequado → dados não cortam nos bordos
 * 8. Crosshair vertical no hover (plugin custom)
 * 9. Zona de gradiente colorida proporcional (fill com opacidade)
 * 10. Splits: barras com rounded top, cor contínua (não binária)
 */
const GPXCharts = (() => {

  // ─── Defaults globais ─────────────────────────────────────────────────────
  function applyDarkDefaults() {
    Chart.defaults.color             = '#64748b';
    Chart.defaults.borderColor       = 'rgba(255,255,255,0.04)';
    Chart.defaults.font.family       = "'Inter', sans-serif";
    Chart.defaults.font.size         = 11;
    Chart.defaults.plugins.legend.display = false;

    // Tooltip profissional
    Chart.defaults.plugins.tooltip.enabled         = true;
    Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(6,9,18,0.96)';
    Chart.defaults.plugins.tooltip.borderColor     = 'rgba(255,255,255,0.08)';
    Chart.defaults.plugins.tooltip.borderWidth     = 1;
    Chart.defaults.plugins.tooltip.titleColor      = '#e2e8f0';
    Chart.defaults.plugins.tooltip.bodyColor       = '#94a3b8';
    Chart.defaults.plugins.tooltip.padding         = { x: 14, y: 10 };
    Chart.defaults.plugins.tooltip.cornerRadius    = 8;
    Chart.defaults.plugins.tooltip.caretSize       = 5;
    Chart.defaults.plugins.tooltip.displayColors   = true;
    Chart.defaults.plugins.tooltip.boxWidth        = 8;
    Chart.defaults.plugins.tooltip.boxHeight       = 8;
    Chart.defaults.plugins.tooltip.boxPadding      = 4;
  }

  let elevChart=null, speedChart=null, hrChart=null, cadChart=null, splitsChart=null;
  function destroy(c){ if(c){try{c.destroy();}catch(e){}} return null; }

  // Subsample inteligente — preserva picos e vales
  function sub(arr, n=400){
    if(!arr||arr.length<=n) return arr;
    const step = arr.length/n;
    const out  = Array.from({length:n}, (_,i) => arr[Math.floor(i*step)]);
    out.push(arr[arr.length-1]);
    return out;
  }

  // ─── Gradiente profundo com 3 stops ──────────────────────────────────────
  function makeGrad(ctx, chart, c0, c1, c2='rgba(0,0,0,0)'){
    const a = chart.chartArea;
    if(!a) return c0;
    const g = ctx.createLinearGradient(0, a.top, 0, a.bottom);
    g.addColorStop(0,    c0);
    g.addColorStop(0.45, c1);
    g.addColorStop(1,    c2);
    return g;
  }

  // ─── Plugin: crosshair vertical no hover ──────────────────────────────────
  const crosshairPlugin = {
    id: 'crosshair',
    afterDatasetsDraw(chart) {
      const { ctx, chartArea, tooltip } = chart;
      if (!tooltip || !tooltip._active || !tooltip._active.length) return;
      const x = tooltip._active[0].element.x;
      if (!chartArea || x < chartArea.left || x > chartArea.right) return;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(x, chartArea.top);
      ctx.lineTo(x, chartArea.bottom);
      ctx.strokeStyle = 'rgba(255,255,255,0.12)';
      ctx.lineWidth   = 1;
      ctx.setLineDash([3, 3]);
      ctx.stroke();
      ctx.restore();
    }
  };

  // ─── Plugin: bandas de zona coloridas ────────────────────────────────────
  function bgZonePlugin(zones, yAxisId='y'){
    return {
      id: 'bgZones',
      beforeDatasetsDraw(chart){
        const { ctx, chartArea, scales } = chart;
        if(!chartArea) return;
        const ysc = scales[yAxisId];
        if(!ysc) return;
        zones.forEach(z => {
          const y1 = ysc.getPixelForValue(z.max);
          const y2 = ysc.getPixelForValue(z.min);
          ctx.save();
          // Gradiente diagonal suave para zona
          const grad = ctx.createLinearGradient(chartArea.left, 0, chartArea.right, 0);
          grad.addColorStop(0,   z.color + '10');
          grad.addColorStop(0.5, z.color + '1a');
          grad.addColorStop(1,   z.color + '08');
          ctx.fillStyle = grad;
          ctx.fillRect(chartArea.left, Math.min(y1, chartArea.top), chartArea.width, Math.abs(y2 - y1));
          // Linha tênue no limite superior de cada zona
          ctx.strokeStyle = z.color + '22';
          ctx.lineWidth   = 0.5;
          ctx.beginPath();
          ctx.moveTo(chartArea.left,  Math.min(y1, y2));
          ctx.lineTo(chartArea.right, Math.min(y1, y2));
          ctx.stroke();
          ctx.restore();
        });
      }
    };
  }

  // ─── Plugin: linha horizontal de referência ───────────────────────────────
  function hLinePlugin(lines){
    return {
      id: 'hLines',
      afterDatasetsDraw(chart){
        const { ctx, chartArea, scales } = chart;
        if(!chartArea || !scales.y) return;
        lines.forEach(l => {
          const y = scales.y.getPixelForValue(l.value);
          if(y < chartArea.top || y > chartArea.bottom) return;
          ctx.save();
          ctx.strokeStyle = l.color || 'rgba(249,115,22,0.45)';
          ctx.lineWidth   = l.width  || 1;
          ctx.setLineDash(l.dash    || [5, 4]);
          ctx.beginPath();
          ctx.moveTo(chartArea.left,  y);
          ctx.lineTo(chartArea.right, y);
          ctx.stroke();
          if(l.label){
            // Label com fundo arredondado
            ctx.setLineDash([]);
            const tw = ctx.measureText(l.label).width + 8;
            const tx = chartArea.right - tw - 4;
            const ty = y - 14;
            ctx.fillStyle = 'rgba(6,9,18,0.85)';
            ctx.beginPath();
            ctx.roundRect(tx, ty, tw, 13, 3);
            ctx.fill();
            ctx.fillStyle   = l.color || '#f97316';
            ctx.font        = '500 9px Inter, sans-serif';
            ctx.textAlign   = 'right';
            ctx.fillText(l.label, chartArea.right - 8, y - 5);
          }
          ctx.restore();
        });
      }
    };
  }

  // ─── Eixo X padrão ───────────────────────────────────────────────────────
  function xAxis(){
    return {
      type: 'linear',
      grid: { color:'rgba(255,255,255,0.03)', drawBorder:false, tickLength:0 },
      border: { display:false },
      ticks: {
        maxTicksLimit: 6,
        color: '#475569',
        font: { size:9, family:'Inter, sans-serif' },
        padding: 6,
        callback: v => `${Math.round(v*10)/10} km`
      },
    };
  }

  // ─── ALTITUDE ─────────────────────────────────────────────────────────────
  function createElevationChart(canvasId, chartData, onHover) {
    elevChart = destroy(elevChart);
    const canvas = document.getElementById(canvasId);
    if(!canvas || !chartData?.elevation?.length) return;

    const raw  = sub(chartData.elevation);
    const elevPts = raw.map(p => ({x:p.d, y:p.e}));
    const elev    = raw.map(p => p.e);
    const minE    = Math.min(...elev);
    const maxE    = Math.max(...elev);
    const midE    = Math.round((minE + maxE) / 2);

    // Velocidade sobreposta por distância
    const hasSp = chartData.speed?.length > 1;
    let spPts = [], hasSpData = false, maxS = null;
    if(hasSp){
      const spSub = sub(chartData.speed);
      const spMap = new Map(spSub.map(p => [Math.round(p.d*100), p.s]));
      spPts = raw.map(p => {
        const k = Math.round(p.d*100);
        const v = spMap.get(k) ?? spMap.get(k-1) ?? spMap.get(k+1) ?? null;
        return {x:p.d, y:v};
      });
      hasSpData = spPts.some(p => p.y != null);
      if(hasSpData) maxS = Math.max(...spPts.map(p=>p.y).filter(Boolean));
    }

    const datasets = [{
      label: 'Altitude', yAxisID:'y',
      data: elevPts,
      borderColor: '#22c55e',
      borderWidth: 1.5,
      pointRadius: 0, pointHoverRadius: 4,
      fill: true,
      backgroundColor: ctx => makeGrad(
        ctx.chart.ctx, ctx.chart,
        'rgba(34,197,94,0.28)',
        'rgba(34,197,94,0.06)',
        'rgba(34,197,94,0.00)'
      ),
      tension: 0.35, order:1,
    }];

    if(hasSpData) datasets.push({
      label: 'Velocidade', yAxisID:'y2',
      data: spPts,
      borderColor: 'rgba(56,189,248,0.5)',
      borderWidth: 1,
      pointRadius: 0, pointHoverRadius: 3,
      fill: false, tension:0.3, order:2,
    });

    elevChart = new Chart(canvas, {
      type: 'line',
      data: { datasets },
      plugins: [
        crosshairPlugin,
        hLinePlugin([
          { value:midE, color:'rgba(34,197,94,0.3)', label:`${midE}m méd`, dash:[4,4], width:0.8 }
        ])
      ],
      options:{
        responsive:true, maintainAspectRatio:false,
        animation: { duration:600, easing:'easeOutQuart' },
        interaction:{ mode:'index', intersect:false },
        onHover:(e,els)=>{ if(els.length && onHover) onHover(els[0].index); },
        layout: { padding: { top:8, right:12, bottom:0, left:0 } },
        plugins:{
          legend:{ display:hasSpData, position:'top', align:'end',
            labels:{ color:'#64748b', font:{size:9}, boxWidth:16, boxHeight:2, padding:12,
              generateLabels: chart => chart.data.datasets.map((ds,i) => ({
                text: ds.label, fillStyle: ds.borderColor,
                strokeStyle: ds.borderColor, lineWidth:0, hidden:false, index:i,
              }))
            }
          },
          tooltip:{ callbacks:{
            title: i => { const x=i[0]?.parsed?.x??i[0]?.raw?.x??0; return `📍 ${(+x).toFixed(2)} km`; },
            label: i => {
              if(i.dataset.yAxisID==='y2') return `  Vel  ${(i.raw.y||0).toFixed(1)} km/h`;
              return `  Alt  ${Math.round(i.raw.y||0)} m`;
            },
          }},
        },
        scales:{
          x: xAxis(),
          y:{
            min: Math.max(0, minE - 20),
            max: maxE + 25,
            grid:{ color:'rgba(255,255,255,0.035)', drawBorder:false, tickLength:0 },
            border:{ display:false },
            ticks:{ maxTicksLimit:5, color:'#475569', font:{size:9}, padding:8, callback:v=>`${v}m` },
          },
          ...(hasSpData?{y2:{
            position:'right',
            min:0, max: Math.round((maxS||60)*1.2),
            grid:{ display:false }, border:{ display:false },
            ticks:{ maxTicksLimit:4, color:'rgba(56,189,248,0.4)', font:{size:8}, padding:6, callback:v=>`${v}` },
          }}:{})
        }
      }
    });
    return elevChart;
  }

  // ─── VELOCIDADE ───────────────────────────────────────────────────────────
  function createSpeedChart(canvasId, chartData, avgSpeed, onHover) {
    speedChart = destroy(speedChart);
    const canvas = document.getElementById(canvasId);
    if(!canvas || !chartData?.speed?.length) return;

    const raw  = sub(chartData.speed);
    const vals = raw.map(p => p.s);

    // Filtrar outliers: usar p95 como teto (GPS spikes causam 72+ km/h falsos)
    const sorted = [...vals].filter(v=>v!=null&&v>0).sort((a,b)=>a-b);
    const p95    = sorted[Math.floor(sorted.length*0.95)] || 60;
    const cap    = p95 * 1.1; // aceita até 10% acima do p95

    // Suavização média móvel 5 pontos — elimina spikes sem distorcer a curva
    function smooth5(arr){
      return arr.map((v,i)=>{
        const slice = arr.slice(Math.max(0,i-2), Math.min(arr.length,i+3));
        const clean = slice.filter(x=>x!=null&&x>=0);
        return clean.length ? clean.reduce((a,b)=>a+b,0)/clean.length : 0;
      });
    }
    const smoothVals = smooth5(vals.map(v => v!=null ? Math.min(v, cap) : 0));
    const spdPts     = raw.map((p,i) => ({x:p.d, y:smoothVals[i]}));
    const avg        = Math.round((avgSpeed||0)*10)/10;
    const maxY       = Math.round(p95 * 1.18);

    // Cor por velocidade relativa ao perfil da sessão (breaks dinâmicos)
    const zColors = ['#38bdf8','#22c55e','#f59e0b','#f97316','#ef4444'];
    const zBreaks = [p95*0.28, p95*0.50, p95*0.72, p95*0.88];
    function hexToRgb(h){ return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)]; }
    function lerp(a,b,t){ const [r1,g1,b1]=hexToRgb(a),[r2,g2,b2]=hexToRgb(b); return `rgb(${Math.round(r1+(r2-r1)*t)},${Math.round(g1+(g2-g1)*t)},${Math.round(b1+(b2-b1)*t)})`; }
    function zColor(v){
      const i=zBreaks.findIndex(b=>v<b);
      if(i===0) return zColors[0];
      if(i<0)   return zColors[4];
      const lo=i===0?0:zBreaks[i-1], hi=zBreaks[i];
      return lerp(zColors[i], zColors[Math.min(i+1,4)], Math.max(0,Math.min(1,(v-lo)/(hi-lo))));
    }

    const avgLine = raw.map(p => ({x:p.d, y:avg}));

    speedChart = new Chart(canvas, {
      type:'line',
      data:{ datasets:[
        {
          label:'Velocidade', yAxisID:'y',
          data: spdPts,
          borderColor:'#38bdf8', borderWidth:2,
          pointRadius:0, pointHoverRadius:4,
          fill:true,
          backgroundColor: ctx => makeGrad(ctx.chart.ctx,ctx.chart,'rgba(56,189,248,0.20)','rgba(56,189,248,0.04)','rgba(56,189,248,0.00)'),
          tension:0.25, order:1,
          segment:{ borderColor: ctx => zColor(smoothVals[ctx.p0DataIndex]||0) },
        },
        {
          label:'Média', yAxisID:'y',
          data: avgLine,
          borderColor:'rgba(249,115,22,0.45)', borderWidth:1.2, borderDash:[6,5],
          pointRadius:0, fill:false, tension:0, order:2,
        },
      ]},
      plugins:[ crosshairPlugin, hLinePlugin([
        {value:avg, color:'rgba(249,115,22,0.4)', label:`${avg} méd`, dash:[5,4], width:0.8}
      ])],
      options:{
        responsive:true, maintainAspectRatio:false,
        animation:{ duration:600, easing:'easeOutQuart' },
        interaction:{ mode:'index', intersect:false },
        onHover:(e,els)=>{ if(els.length&&onHover) onHover(els[0].index); },
        layout:{ padding:{ top:8, right:12, bottom:0, left:0 } },
        plugins:{
          legend:{ display:false },
          tooltip:{ callbacks:{
            title: i => { const x=i[0]?.parsed?.x??i[0]?.raw?.x??0; return `📍 ${(+x).toFixed(2)} km`; },
            label: i => {
              if(i.dataset.label==='Velocidade') return `  Vel  ${(i.raw.y||0).toFixed(1)} km/h`;
              return '';
            },
            afterBody: items => {
              const s = items.find(i=>i.dataset.label==='Velocidade');
              if(!s||avg<=0) return [`  Méd  ${avg} km/h`];
              const d = ((s.raw.y||0)-avg).toFixed(1);
              return [`  Méd  ${avg} km/h`, `  Δ  ${+d>=0?'+':''}${d}`];
            },
            filter: i => i.dataset.label !== 'Média',
          }},
        },
        scales:{
          x: xAxis(),
          y:{
            min:0, max:maxY,
            grid:{ color:'rgba(255,255,255,0.035)', drawBorder:false, tickLength:0 },
            border:{ display:false },
            ticks:{ maxTicksLimit:5, color:'#475569', font:{size:9}, padding:8, callback:v=>`${v}` },
          }
        }
      }
    });
    return speedChart;
  }

  // ─── FC ───────────────────────────────────────────────────────────────────
  function createHRChart(canvasId, chartData, onHover) {
    hrChart = destroy(hrChart);
    const canvas = document.getElementById(canvasId);
    if(!canvas || !chartData?.hr?.length) return;

    const raw   = sub(chartData.hr);
    const hrPts = raw.map(p => ({x:p.d, y:p.v}));
    const vals  = raw.map(p => p.v);
    const avgHR = Math.round(vals.reduce((a,b)=>a+b,0)/vals.length);
    const maxHR = Math.max(...vals);
    const minHR = Math.min(...vals);

    // Zonas HR com base no max detectado
    const fcMax = Math.round(maxHR * 1.05);
    const hrZones = [
      {min:0,           max:fcMax*0.60, color:'#94a3b8', label:'Z1'},
      {min:fcMax*0.60,  max:fcMax*0.70, color:'#38bdf8', label:'Z2'},
      {min:fcMax*0.70,  max:fcMax*0.80, color:'#22c55e', label:'Z3'},
      {min:fcMax*0.80,  max:fcMax*0.90, color:'#f97316', label:'Z4'},
      {min:fcMax*0.90,  max:fcMax,      color:'#ef4444', label:'Z5'},
    ].filter(z => z.max > minHR*0.9 && z.min < maxHR*1.05);

    const avgLine = raw.map(p => ({x:p.d, y:avgHR}));

    hrChart = new Chart(canvas, {
      type:'line',
      data:{ datasets:[
        {
          label:'FC', yAxisID:'y',
          data: hrPts,
          borderColor:'#ef4444', borderWidth:1.5,
          pointRadius:0, pointHoverRadius:4,
          fill:true,
          backgroundColor: ctx => makeGrad(
            ctx.chart.ctx, ctx.chart,
            'rgba(239,68,68,0.25)',
            'rgba(239,68,68,0.05)',
            'rgba(239,68,68,0.00)'
          ),
          tension:0.3,
        },
        {
          label:'Média', yAxisID:'y',
          data: avgLine,
          borderColor:'rgba(249,115,22,0.4)',
          borderWidth:1, borderDash:[5,4],
          pointRadius:0, fill:false, tension:0,
        },
      ]},
      plugins:[ crosshairPlugin, bgZonePlugin(hrZones,'y'), hLinePlugin([
        {value:avgHR, color:'rgba(249,115,22,0.4)', label:`${avgHR} méd`, dash:[5,4], width:0.8}
      ])],
      options:{
        responsive:true, maintainAspectRatio:false,
        animation:{ duration:600, easing:'easeOutQuart' },
        interaction:{ mode:'index', intersect:false },
        onHover:(e,els)=>{ if(els.length&&onHover) onHover(els[0].index); },
        layout:{ padding:{ top:8, right:12, bottom:0, left:0 } },
        plugins:{
          legend:{ display:false },
          tooltip:{ callbacks:{
            title: i => { const x=i[0]?.parsed?.x??i[0]?.raw?.x??0; return `📍 ${(+x).toFixed(2)} km`; },
            label: i => {
              if(i.dataset.label==='FC') return `  FC  ${i.raw.y} bpm`;
              return '';
            },
            afterBody: items => {
              const hr = items.find(i=>i.dataset.label==='FC');
              if(!hr || avgHR<=0) return [`  Méd  ${avgHR} bpm`];
              const delta = Math.round((hr.raw.y||0) - avgHR);
              const sign  = delta >= 0 ? '+' : '';
              // Identifica zona
              const pct = (hr.raw.y||0)/fcMax;
              const zone = pct < 0.6?'Z1' : pct<0.7?'Z2' : pct<0.8?'Z3' : pct<0.9?'Z4' : 'Z5';
              return [`  Méd  ${avgHR} bpm`, `  Δ  ${sign}${delta} · ${zone}`];
            }
          }},
        },
        scales:{
          x: xAxis(),
          y:{
            min: Math.max(40, minHR - 12),
            max: maxHR + 12,
            grid:{ color:'rgba(255,255,255,0.035)', drawBorder:false, tickLength:0 },
            border:{ display:false },
            ticks:{ maxTicksLimit:5, color:'#475569', font:{size:9}, padding:8, callback:v=>`${v}` },
          }
        }
      }
    });
    return hrChart;
  }

  // ─── CADÊNCIA ─────────────────────────────────────────────────────────────
  function createCadenceChart(canvasId, chartData, onHover) {
    cadChart = destroy(cadChart);
    const canvas = document.getElementById(canvasId);
    if(!canvas || !chartData?.cadence?.length) return;

    const raw    = sub(chartData.cadence);
    const cadPts = raw.map(p => ({x:p.d, y:(p.v>0&&p.v<220)?p.v:null}));
    const clean  = cadPts.map(p=>p.y).filter(Boolean);
    const avgCad = clean.length ? Math.round(clean.reduce((a,b)=>a+b,0)/clean.length) : 80;
    const maxCad = clean.length ? Math.round(Math.max(...clean)) : 120;

    // Zonas cadência ciclismo
    const cadZones = [
      {min:0,   max:60,  color:'#94a3b8'},
      {min:60,  max:75,  color:'#38bdf8'},
      {min:75,  max:85,  color:'#22c55e'},
      {min:85,  max:100, color:'#f97316'},
      {min:100, max:220, color:'#ef4444'},
    ].filter(z=>z.min < (maxCad||120)+10);

    const optLine = raw.map(p=>({x:p.d, y:90}));
    const avgLine = raw.map(p=>({x:p.d, y:avgCad}));

    cadChart = new Chart(canvas, {
      type:'line',
      data:{ datasets:[
        {
          label:'Cadência',
          data: cadPts,
          borderColor:'#a78bfa', borderWidth:1.5,
          pointRadius:0, pointHoverRadius:4,
          fill:true,
          backgroundColor: ctx => makeGrad(
            ctx.chart.ctx, ctx.chart,
            'rgba(167,139,250,0.22)',
            'rgba(167,139,250,0.04)',
            'rgba(167,139,250,0.00)'
          ),
          tension:0.3, spanGaps:true,
        },
        {
          label:'Ótima',
          data: optLine,
          borderColor:'rgba(34,197,94,0.4)',
          borderWidth:1, borderDash:[5,4],
          pointRadius:0, fill:false, tension:0,
        },
        {
          label:'Média',
          data: avgLine,
          borderColor:'rgba(249,115,22,0.35)',
          borderWidth:1, borderDash:[3,4],
          pointRadius:0, fill:false, tension:0,
        },
      ]},
      plugins:[ crosshairPlugin, bgZonePlugin(cadZones,'y'), hLinePlugin([
        {value:90,     color:'rgba(34,197,94,0.4)',   label:'90 ótima', dash:[4,4], width:0.8},
        {value:avgCad, color:'rgba(249,115,22,0.35)', label:`${avgCad} méd`, dash:[3,4], width:0.8},
      ])],
      options:{
        responsive:true, maintainAspectRatio:false,
        animation:{ duration:600, easing:'easeOutQuart' },
        interaction:{ mode:'index', intersect:false },
        onHover:(e,els)=>{ if(els.length&&onHover) onHover(els[0].index); },
        layout:{ padding:{ top:8, right:12, bottom:0, left:0 } },
        plugins:{
          legend:{ display:true, position:'top', align:'end',
            labels:{ color:'#64748b', font:{size:9}, boxWidth:16, boxHeight:2, padding:12,
              filter: item => item.text === 'Ótima',
              generateLabels: chart => [{
                text:'90 rpm ótima', fillStyle:'rgba(34,197,94,0.5)',
                strokeStyle:'rgba(34,197,94,0.5)', lineWidth:0, hidden:false, index:0,
              }]
            }
          },
          tooltip:{ callbacks:{
            title: i => { const x=i[0]?.parsed?.x??i[0]?.raw?.x??0; return `📍 ${(+x).toFixed(2)} km`; },
            label: i => {
              if(i.dataset.label==='Cadência') return `  Cad  ${i.raw.y||'--'} rpm`;
              return '';
            },
            afterBody: items => {
              const cad = items.find(i=>i.dataset.label==='Cadência');
              if(!cad||!cad.raw.y) return [];
              const v = cad.raw.y;
              const zone = v<60?'Muito lenta':v<75?'Confortável':v<85?'Boa':v<100?'Ótima':'Alta';
              return [`  Méd  ${avgCad} rpm`, `  Zona  ${zone}`];
            }
          }},
        },
        scales:{
          x: xAxis(),
          y:{
            min:0, max:Math.max(maxCad||120, 110)+15,
            grid:{ color:'rgba(255,255,255,0.035)', drawBorder:false, tickLength:0 },
            border:{ display:false },
            ticks:{ maxTicksLimit:5, color:'#475569', font:{size:9}, padding:8, callback:v=>`${v}` },
          }
        }
      }
    });
    return cadChart;
  }

  // ─── SPLITS — barras com gradiente de performance ─────────────────────────
  function createSplitsChart(canvasId, splits) {
    splitsChart = destroy(splitsChart);
    const canvas = document.getElementById(canvasId);
    if(!canvas || !splits?.length) return;

    const avgSpd = splits.reduce((s,sp)=>s+(sp.avgSpeed||0),0)/splits.length;
    const maxSpd = Math.max(...splits.map(s=>s.avgSpeed||0));
    const minSpd = Math.min(...splits.map(s=>s.avgSpeed||0));
    const range  = maxSpd - minSpd || 1;

    // Cor contínua por performance relativa: vermelho=lento → verde=rápido
    function splitColor(spd, alpha='cc'){
      const t = (spd - minSpd) / range;
      const r = Math.round(239 + (34-239)*t);
      const g = Math.round(68  + (197-68)*t);
      const b = Math.round(68  + (94-68)*t);
      return `rgba(${r},${g},${b},0.8)`;
    }

    const speeds = splits.map(s=>s.avgSpeed);
    const colors = speeds.map(s=>splitColor(s));

    splitsChart = new Chart(canvas, {
      type: 'bar',
      data:{
        labels: splits.map((s,i)=>`${i+1}`),
        datasets:[{
          label:'Velocidade',
          data: speeds,
          backgroundColor: colors,
          borderColor: colors.map(c=>c.replace('0.8','1')),
          borderWidth: 0,
          borderRadius: { topLeft:3, topRight:3 },
          borderSkipped: 'bottom',
        }],
      },
      options:{
        responsive:true, maintainAspectRatio:false,
        animation:{ duration:500, easing:'easeOutQuart' },
        layout:{ padding:{ top:8, right:4, bottom:0, left:0 } },
        plugins:{
          legend:{ display:false },
          tooltip:{ callbacks:{
            title: i => `KM ${i[0].label}`,
            label: i => `  Vel  ${(i.raw||0).toFixed(1)} km/h`,
            afterLabel: i => {
              const delta = ((i.raw||0) - avgSpd).toFixed(1);
              const sign  = delta >= 0 ? '+' : '';
              return `  Δ  ${sign}${delta} vs média`;
            }
          }},
        },
        scales:{
          x:{
            grid:{ display:false },
            border:{ display:false },
            ticks:{ color:'#475569', font:{size:9}, padding:4 }
          },
          y:{
            min: Math.max(0, minSpd - (range*0.2)),
            max: maxSpd + (range*0.15),
            grid:{ color:'rgba(255,255,255,0.03)', drawBorder:false, tickLength:0 },
            border:{ display:false },
            ticks:{ maxTicksLimit:4, color:'#475569', font:{size:9}, padding:8, callback:v=>`${v}` },
          }
        }
      }
    });
    return splitsChart;
  }

  return { applyDarkDefaults, createElevationChart, createSpeedChart, createHRChart, createCadenceChart, createSplitsChart };
})();

if(typeof module !== 'undefined') module.exports = GPXCharts;
